1.Please run paper_v3.tex in XELATEX mode more than 2 times to make sure the refernces id are loaded in the paper，
2.paper_clean_revision.pdf is generated from paper_ve.tex