classdef LegendGrid < matlab.mixin.Copyable & handle
    properties
        nP
        nL
        pMax
        pGridMode
        pGridParameter
        L
        p
        s
        ddp
        d2dp2
        gamma
        ddpn
        d2dp2n
        L2D
        p2D
       matSize
        pBig
        ddpBigmat
        d2dp2Bigmat
        IBigmat
        stencil=5
        xi
        t
        gradient=4
        nt=5e3;
    end
    
    methods
        
        function o=LegendGrid(varargin)
            %LegendGrid(nP,nL,pMax,pGridMode,pGridParameter)
            o.nP=varargin{1};
            o.nL=varargin{2};
            o.pMax=varargin{3};
            o.pGridMode=varargin{4};
            o.pGridParameter=varargin{5};
            o.matSize=o.nP*o.nL;
            o.t=linspace(-1,1,o.nt);
            s=tanh(o.t*o.gradient);
            o.xi=s*1./s(end);
            o.initiate()
        end
        
        function initiate(o)
            nP=o.nP;
            
            o.L=0:o.nL-1;
            if o.pGridMode
                %A nonuniform grid.
                %Get a uniform grid on [0,1].
                [s,dds,d2ds2,ddsn,d2ds2n] = o.CreateuniformGrid(o.nP,0,1);
                switch o.pGridMode
                    case 1 %A grid with p = s^2 + pGridParameter*s
                        p = s.*s+o.pGridParameter*s;
                        dpds = 2*s+o.pGridParameter;
                        d2pds2 = 2*ones(size(s));
                    case 2 %A grid with p = s^3 + pGridParameter*s
                        p = s.^3+o.pGridParameter*s;
                        dpds = 3*s.^2+o.pGridParameter;
                        d2pds2 = 6*s;
                    case 3 %A grid with p = s^4 + pGridParameter*s
                        p = s.^4+o.pGridParameter*s;
                        dpds = 4*s.^3+o.pGridParameter;
                        d2pds2 = 12*s.^2;
                    otherwise
                        error('Invalid mode for the p grid.')
                end
                %Remap derivatives and quadrature weights
                ddp = spdiags(1./dpds,0,nP,nP)*dds;
                d2dp2 = -spdiags(d2pds2 ./ (dpds.^3),0,nP,nP) * dds ...
                    + spdiags((1./dpds).^2,0,nP,nP)*d2ds2;
                
                ddpn = spdiags(1./dpds,0,nP,nP)*ddsn;
                d2dp2n = -spdiags(d2pds2 ./ (dpds.^3),0,nP,nP) * ddsn ...
                    + spdiags((1./dpds).^2,0,nP,nP)*d2ds2n;
                
                scaleFactor = o.pMax/p(end);
                o.s=s;
                o.p = scaleFactor*p;
                o.ddp = ddp / scaleFactor;
                o.d2dp2 = d2dp2 / (scaleFactor*scaleFactor);
                o.gamma=sqrt(o.p.^2+1);
                
                o.ddpn = ddpn / scaleFactor;
                o.d2dp2n = d2dp2n / (scaleFactor*scaleFactor);
                
                [o.L2D,o.p2D] = meshgrid(o.L,o.p);
                eL=ones(o.nL);eP=ones(o.nP);
                
%                 o.PLxi=o.Legendre_test_num(o.L,o.xi);
                o.pBig = o.MapGridToBigVector(o.p2D);
                o.ddpBigmat=BuildBigMatrix(o,eL,o.ddpn,1,1);
                o.d2dp2Bigmat=BuildBigMatrix(o,eL,o.d2dp2n,1,2);
                o.IBigmat=sparse(kron(eL,eye(o.nP)));
            end
            
        end
        function    [x,ddx,d2dx2,ddxn,d2dx2n]=CreateuniformGrid(o,n,xMin,xMax)
            
            % Generates a uniform grid, Stencils with 3,5 or 7 points (giving 2nd, 4th or
            % 6th order finite differences) are available. Central
            % differences are used, except near the endpoints where a
            % gradual transition to one-sided differences is used to
            % maintain the discretization order.
            dx=(xMax-xMin)/(n-1);dx2=dx*dx;
            x0 = linspace(xMin,xMax,n)';x=x0+x0(2);
            o.stencil=5;
            switch o.stencil
                case 3
                    %%% ddx
                    % Set the interior points of the differentiation matrix
                    % using a central finite difference:
                    ddx = sparse( (  diag(ones(n-1,1),1) ...
                        - diag(ones(n-1,1),-1) )...
                        /(2*dx) );
                    
                    %Handle endpoints (one-sided differences):
                    
                    ddx(1,1) = -1.5/dx;
                    ddx(1,2) = 2/dx;
                    ddx(1,3) = -0.5/dx;
                    
                    ddx(end,end)   = 1.5/dx;
                    ddx(end,end-1) = -2/dx;
                    ddx(end,end-2) = 0.5/dx;
                    
                    %          ddx(end,end)   = 1.5/dx;
                    ddx(end,end-1) = -1/dx/2;
                    %         ddx(end,end-2) = 0.5/dx;
                    
                    %%% d2dx2
                    %Interior points
                    d2dx2 = sparse( ( - 2*diag(ones(n,1),0) ...
                        + diag(ones(n-1,1),1)...
                        + diag(ones(n-1,1),-1) )...
                        /dx2 );
                    
                    %Endpoints
                    d2dx2(1,1) = 1/dx2;
                    d2dx2(1,2) = -2/dx2;
                    d2dx2(1,3) = 1/dx2;
                    d2dx2(end,end)   = 1/dx2;
                    d2dx2(end,end-1) = -2/dx2;
                    d2dx2(end,end-2) = 1/dx2;
                    
                case 5
                    %Interior points
                    v1  = ones(n,1);
                    %         n=24;dx=1/12; v1  = ones(n,1);dx2=dx*dx;
                    ddx = (  - spdiags((1/6)*v1,2,n,n)...
                        + spdiags((4/3)*v1,1,n,n)...
                        - spdiags((4/3)*v1,-1,n,n)...
                        + spdiags((1/6)*v1,-2,n,n) )...
                        /(2*dx);
                    
                    %Endpoints
                    %ddx=0 Neumann boundary condition
                    u0=1/25*[ 48 -36 16 -3 ];
                    %         u0=[1 0 0 0 ];
                    F1=-3*u0+[ -10 18 -6 1 ];
                    F2=u0+[ -8 0 8 -1 ]     ;
                    %F=0 Dirchlet condition
                    Fn1([1 2 3 4])=[ -10 18 -6 1 ];
                    Fn2([1 2 3 4])=[ -8 0 8 -1 ]  ;
                    
                    %                     ddx(1,1) = -25/(12*dx);
                    %                     ddx(1,2) = 4/(dx);
                    %                     ddx(1,3) = -3/dx;
                    %                     ddx(1,4) = 4/(3*dx);
                    %                     ddx(1,5) = -1/(4*dx);
                    
                    ddx(1,1) =F1(1)/(12*dx);
                    ddx(1,2) =F1(2)/(12*dx);
                    ddx(1,3) =F1(3)/(12*dx);
                    ddx(1,4) =F1(4)/(12*dx);
                    
                    ddx(2,1) =F2(1)/(12*dx);
                    ddx(2,2) =F2(2)/(12*dx);
                    ddx(2,3) =F2(3)/(12*dx);
                    ddx(2,4) =F2(4)/(12*dx);
                    
                    %         ddx(end,end)   = 10/(12*dx);
                    %         ddx(end,end-1) = -18/(12*dx);
                    %         ddx(end,end-2) = 6/(12*dx);
                    %         ddx(end,end-3) = -1/(12*dx);
                    %
                    %         ddx(end-1,end)   = 8/(12*dx);
                    %         ddx(end-1,end-1) = 0;
                    %         ddx(end-1,end-2) = -8/(12*dx);
                    %         ddx(end-1,end-3) = 1/(12*dx);
                    
                    
                    ddxn=ddx;
                    ddxn(1,[1 2 3 4])=Fn1/(12*dx);
                    ddxn(2,[1 2 3 4])=Fn2/(12*dx);
                    
                    %                     ddx(2,1) = -1/(4*dx);
                    %                     ddx(2,2) = -5/(6*dx);
                    %                     ddx(2,3) = 3/(2*dx);
                    %                     ddx(2,4) = -1/(2*dx);
                    %                     ddx(2,5) = 1/(12*dx);
                    
                    ddx(end,end)   = 25/(12*dx);
                    ddx(end,end-1) = -4/(dx);
                    ddx(end,end-2) = 3/dx;
                    ddx(end,end-3) = -4/(3*dx);
                    ddx(end,end-4) = 1/(4*dx);
                    
                    ddx(end-1,end)   = 1/(4*dx);
                    ddx(end-1,end-1) = 5/(6*dx);
                    ddx(end-1,end-2) = -3/(2*dx);
                    ddx(end-1,end-3) = 1/(2*dx);
                    ddx(end-1,end-4) = -1/(12*dx);
                    
                    %%% d2dx2
                    %Interior points
                    d2dx2 = (   - spdiags((1/12)*v1,2,n,n)...
                        + spdiags((4/3)*v1,1,n,n)...
                        + spdiags((-5/2)*v1,0,n,n)...
                        + spdiags((4/3)*v1,-1,n,n) ...
                        - spdiags((1/12)*v1,-2,n,n) )...
                        /(dx2);
                    
                    %Endpoints
                    %                     d2dx2(1,1) = 35/(12*dx2);
                    %                     d2dx2(1,2) = -26/(3*dx2);
                    %                     d2dx2(1,3) = 19/(2*dx2);
                    %                     d2dx2(1,4) = -14/(3*dx2);
                    %                     d2dx2(1,5) = 11/(12*dx2);
                    %         u2=1/35*[26*4 -19*6 14*4 -11];
                    FF1=11*u0+[-20 6 4 -1];
                    FF2=-1*u0+[16 -30 16 -1];
                    
                    FFn1=[-20 6 4 -1];
                    FFn2=[16 -30 16 -1];
                    
                    
                    d2dx2(1,1) = FF1(1)/(12*dx2);
                    d2dx2(1,2) = FF1(2)/(12*dx2);
                    d2dx2(1,3) =  FF1(3)/(12*dx2);
                    d2dx2(1,4) =  FF1(4)/(12*dx2);
                    
                    d2dx2(2,1) = FF2(1)/(12*dx2);
                    d2dx2(2,2) = FF2(2)/(12*dx2);
                    d2dx2(2,3) = FF2(3)/(12*dx2);
                    d2dx2(2,4) = FF2(4)/(12*dx2);
                    
                    %                     d2dx2(2,1) = 11/(12*dx2);
                    %                     d2dx2(2,2) = -5/(3*dx2);
                    %                     d2dx2(2,3) = 1/(2*dx2);
                    %                     d2dx2(2,4) = 1/(3*dx2);
                    %                     d2dx2(2,5) = -1/(12*dx2);
                    
                    d2dx2(end,end)   = 35/(12*dx2);
                    d2dx2(end,end-1) = -26/(3*dx2);
                    d2dx2(end,end-2) = 19/(2*dx2);
                    d2dx2(end,end-3) = -14/(3*dx2);
                    d2dx2(end,end-4) = 11/(12*dx2);
                    
                    d2dx2(end-1,end-0) = 11/(12*dx2);
                    d2dx2(end-1,end-1) = -5/(3*dx2);
                    d2dx2(end-1,end-2) = 1/(2*dx2);
                    d2dx2(end-1,end-3) = 1/(3*dx2);
                    d2dx2(end-1,end-4) = -1/(12*dx2);
                    %         d2dx2(end-1,[end-3 end-2 end-1 end ])=[ -1/(12*dx2) 4/(3*dx2)  -5/(2*dx2) 4/(3*dx2) ];
                    %         d2dx2(end,[end end-1 end-2 end-3 ])=[-5/(3*dx2) 1/(2*dx2) 1/(3*dx2)  -1/(12*dx2)];
                    ddxn=ddx;
                    ddxn(1,[1 2 3 4])=Fn1/(12*dx);
                    ddxn(2,[1 2 3 4])=Fn2/(12*dx);
                    d2dx2n=d2dx2;
                    d2dx2n(1,[1 2 3 4])=FFn1/(12*dx2);
                    d2dx2n(2,[1 2 3 4])=FFn2/(12*dx2);
            end
            
        end

        function v=MapGridToBigVector(o,f2D)
            % Reshapes a function given on the 2D grid to a vector
            % representation.
            %
            % Usage:
            %   fV = MapGridToBigVector(f2D)
            
            v = reshape(f2D,o.matSize,1);
        end
        
        function f2D=MapVectorToGrid(o,v)
            % Reshapes a function given on the 2D grid to a vector
            % representation.
            %
            % Usage:
            %   fV = MapGridToBigVector(f2D)
            
            f2Drev = reshape(v,o.nP,o.nL);
            f2D=f2Drev';
        end
        
        function Mat=BuildBigMatrix(o,FA,FB,doP0Dependence,derivative)
            % Construct a matrix that can be used for operating on a
            % function on the grid (in its vector representation).
            % msn = sparse(o.matSize,o.matSize);
            if  doP0Dependence
                Mat= kron(FA,FB);
                %m=0's dependence on o.ddp;
                if derivative==1
                    ms1 = kron(FA,o.ddp);
                    Mat(1:end,1:o.nP)=ms1(1:end,1:o.nP);
                elseif derivative==2
                    ms2= kron(FA,o.d2dp2);
                    Mat(1:end,1:o.nP)=ms2(1:end,1:o.nP);
                end
            else
                Mat= kron(FB,FA);
            end
            
        end
    end
end