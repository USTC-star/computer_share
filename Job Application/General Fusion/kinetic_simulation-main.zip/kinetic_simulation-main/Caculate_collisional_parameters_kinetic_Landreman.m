classdef  Caculate_collisional_parameters_kinetic_Landreman  <handle
    
    %reference:动力学模拟笔记
    %Numerical calculation of the runaway electron distribution function
    %and associated synchrotron emission
    %xxh ，20220812
    properties
        kinetic
        Z
        kec
        delta
        p   
    end
    
    methods
        function o=Caculate_collisional_parameters_kinetic_Landreman(varargin)
%             if isa(varargin{1},'KINETIC_ANOMALOUS_CODE2')||isa(varargin{1},'KINETIC_ANOMALOUS_CODE3')||isa(varargin{1},'KINETIC_ANOMALOUS_CODE2_1')||isa(varargin{1},'KINETIC_ANOMALOUS_CODE6')||isa(varargin{1},'KINETIC_CODE')
                if nargin==1
                o.kinetic = varargin{1};
                o.kec  = o.kinetic.kec ;
                o.p    = o.kinetic.grid.p ;
                o.delta= o.kinetic.delta ;
                o.Z    = o.kinetic.Z ;
                else
                  o.kinetic = varargin{1};
                o.kec  = 1 ;
                o.p    = o.kinetic.grid.p ;
                o.delta= o.kinetic.delta ;
                o.Z    = o.kinetic.Z ;
                end
                    
%             else
%                 error('The first argument must be a KINETIC_ANOMALOUS_CODE object.');
%             end
            o.Get_collisional_coefficient()
        end
        
    end
    
    properties
        coeff_cnm3
        coeff_cnm1
        coeff_cnm2
    end
    
    methods
        function Get_collisional_coefficient(o)
            global Z delta kc
            kc=o.kec;
            Z=o.Z;
            delta=o.delta;
            
            o.coeff_cnm1=Coefficient_collision_1(o.p);
            o.coeff_cnm2=Coefficient_collision_2(o.p);
            o.coeff_cnm3=Coefficient_collision_3(o.p);
            
            
            function coeff_cnm3=Coefficient_collision_3(y)
                coeff_cnm3 = -1*3*pi^(1/2)./(8*xf(y).*y.^2).*(Z+phi(y)-fPhi(y)+(delta^4*xf(y).^2)/2)*kc*delta^2;
            end
            
            function coeff_cnm1=Coefficient_collision_1(y)
                coeff_cnm1 = -1*3*pi^(1/2)/4*fPhi(y)./xf(y)*kc*delta^2  ;
            end
            
            function coeff_cnm2=Coefficient_collision_2(y)
                coeff_cnm2 = -1*3*pi^(1/2)/2*kc*delta*fPhi(y);
            end
            
            
            function Phi=fPhi(y)
                syms x
                Phir= 1/(2*x.^2).*(erf(x)-x.*diff(erf(x)));
                fPhi1=inline(Phir);
                x=y./(sqrt(1+y.^2))/delta;
                Phi=fPhi1(x);
            end
            
            
            function x=xf(y)
                x=y./sqrt(1+y.^2)/delta;
            end
            
            function phi1=phi(y)
                x=y./sqrt(1+(y).^2)/delta;
                phi1=erf(x);
            end
        end
    end
end