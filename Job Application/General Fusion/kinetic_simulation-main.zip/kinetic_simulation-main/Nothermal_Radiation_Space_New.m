classdef Nothermal_Radiation_Space_New < matlab.mixin.Copyable & handle
    %20230806 simplfy the input parameters
    properties
        %plasma parameters
        ne0
        B0
        Te0
        wavetype     % X/O or Bernstein
        f            %momentum distribution where p is normalized to mec
        m            %resonant number
        m0=2         %veiw number
        omegas
        xs
        %Grid setup
        nP
        nXi
        nL
        pMax
        pGridMode
        xiGridMode
        pGridParameter
        grid
        a=0.45;%min radius
        Ns=90 % numbers of  ray coordinate
        theta=90 %receive angle between vector k and B direction [degree]
        direction='L'
    end
    
    properties (Constant) %%%   Physical constants    %%%
        constants = struct('c',   2.997925e8,...
            'e',   1.602176e-19,...
            'm',   9.109380e-31,...
            'eps0',8.854188e-12);
    end
    
    methods
        function o=Nothermal_Radiation_Space_New(varargin)
            switch nargin
                case 0
                    o.grid=Grid_ECEI();
                case {5}
                    o.SetParameters(varargin{1:end});                   
                    o.PerformCalculation();
                    o.Caculate_I_distribution();
                otherwise
                    error('Wrong number of input arguments');                    
            end
        end
        
        function SetParameters(o,omegas,m,wavetype,p,tc)
            
            o.ne0=p.ne(tc);
            o.B0 =p.B;           
            o.omegas=omegas;
            o.f =p.f;            
            o.Te0=p.Te;
            o.nP=p.grid.nP;
            o.nXi=p.grid.nXi;
            o.pMax=p.grid.pMax;
            o.m=m;            
            o.nL=p.nL;
            o.wavetype=wavetype;
            o.pGridMode=p.pGridMode;
            o.xiGridMode=p.xiGridMode;
            o.pGridParameter=p.pGridParameter;
            o.grid = Grid_ECEI(o.nP,o.nXi,o.pMax,o.pGridMode,o.xiGridMode,o.pGridParameter);
            o.BuildMappingMatrices();
        end
        
        function PerformCalculation(o)
            o.Calculate_Common_Parameters()
            o.Js=zeros(o.Ns,length(o.omegas));
            o.alphas=zeros(o.Ns,length(o.omegas));            
            m=o.m  ;
            t=linspace(1e-4,1,o.Ns);
            o.xs=cell(1,length(o.omegas));
                    %%%  calcauate  dfdxi and dfdp %%%%
                    fK=o.f;
                    fpxiBigK=o.MapLegModesToBigVector(fK) ;
                    f2DK=o.MapVectorToGrid(fpxiBigK)      ;
                    dfdxiBigK=o.grid.ddxiMat* fpxiBigK    ;
                    dfdxi2DK =o.MapVectorToGrid(dfdxiBigK);
                    dfdpBigK=o.grid.ddpMat* fpxiBigK      ;
                    dfdp2DK =o.MapVectorToGrid(dfdpBigK)  ;
                    %%%%%%%%

            
            for jj=1:length(o.omegas)
                disp(jj)
                omega=o.omegas(jj);
                e=o.constants.e   ;
                eps0=o.constants.eps0;
                me=o.constants.m;
                c=o.constants.c ;
                coeff_absorption=-8*pi^3*c^2/(me*c^2*omega^2) ;
                x_start=o.omegatoradius(omega);x_end=-o.a;
                if x_start>o.a
                    x_start=o.a;
                    o.xs{jj}=(x_end-x_start)*t+x_start;
                elseif x_start<o.a&&x_start>-o.a
                    o.xs{jj}=(x_end-x_start)*t.^2+x_start;
                else
                    o.xs{jj}=nan(1,o.Ns)  ;
                    o.Js(:,jj)=nan(1,o.Ns);
                o.alphas(:,jj)=nan(1,o.Ns);
                    %                     error(['Too high frequency,the resonant position is outside of tokamak! ','x_start=',num2str(x_start)])
                    continue
                end
                
                for kk=1:length(o.xs{jj})
%                     m=o.m;
                    %%%    calculate the dfdp in delta function   %%%
                    e=o.constants.e ;
                    me=o.constants.m;
                    eps0=o.constants.eps0;
                    c=o.constants.c;
                    ne=o.ne_profile(o.xs{jj}(kk)) ;
                    B =o.B_profile(o.xs{jj}(kk))  ;
                    
                    %%%%%
                    wce0=e*B/me;
                    coeff_emission=e^2*omega.^2/8/pi.^2/eps0/c/wce0;
                    w=omega/wce0;
                    if w<m
                        p=sqrt((m/w).^2-1);
                        npc=50*ceil(p/2);
                        xic=linspace(-0.999,0.999,npc);
                        pc=ones(1,npc)*p;
                    else
                        npc=50;
                        xic=nan(1,npc);pc=nan(1,npc);
                    end
                    
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    if abs(o.xs{jj}(kk))<o.a/300000                  
                       f2D=f2DK;
                       dfdxi2D =dfdxi2DK;
                       dfdp2D =dfdp2DK;
                    else
                    Te=o.Te_profile(o.xs{jj}(kk)) ;
                    fT=o.Theraml_Legmode_distribution(Te);
                    fpxiBig=o.MapLegModesToBigVector(fT) ;
                    f2D=o.MapVectorToGrid(fpxiBig)      ;
                    dfdxiBig=o.grid.ddxiMat* fpxiBig   ;
                    dfdxi2D =o.MapVectorToGrid(dfdxiBig);
                    dfdpBig=o.grid.ddpMat* fpxiBig      ;
                    dfdp2D =o.MapVectorToGrid(dfdpBig)  ;
                    end
                                              
                    gammac=sqrt(1+pc.^2);
                    beta_perp=pc./gammac.*sqrt(1-xic.^2);
                    beta_para=pc./gammac.*xic;
                    xi_spark=omega/wce0.*gammac.*beta_perp.*sind(o.theta);
                    xi_spark(xi_spark==0)=realmin;
                    %%%   calculate the dJmdxi and Jm      %%%
                    Jm_xi_spark=o.Jm(xi_spark);
                    dJmdxi_spark=o.dJmdx(xi_spark);
                    %%%    calculate resonant parameterms    %%%%%%
%                     m=o.m;
                    theta=o.theta ;
                    gam2D=o.grid.gamma2D;
                    p2D=o.grid.p2D      ;
                    xi2D=o.grid.xi2D    ;
                    ddeltadp=o.dfdp_delta(pc);
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    f_resonant=interp2( xi2D,p2D,f2D,xic,pc);
                    dfdp_resonant=interp2(xi2D,p2D,dfdp2D,xic,pc);
                    dfdxi_resonant=interp2(xi2D,p2D,dfdxi2D,xic,pc);
                    %%% o.Calculate_emission_absorption_coefficient()%%%%
                    Common_part=1./pc.*dfdxi_resonant.*cosd(theta)...
                        +sqrt(1+pc.^2)./pc.*dfdp_resonant...
                        -xic.*sqrt(1+pc.^2)./pc.^2.*dfdxi_resonant;
                    switch o.wavetype
                        case 'X'
                            Ay=beta_perp.*dJmdxi_spark;
                            etay_resonant=coeff_emission*Ay.^2;
                            Jy_xi=etay_resonant.*2*pi.*pc.^2*ne./abs(ddeltadp);
                            alpha_xi=coeff_absorption*Jy_xi.*Common_part;
                            J(kk)=trapz(xic,Jy_xi.*f_resonant);
                            alpha(kk)=trapz(xic,alpha_xi);
                        case 'O'
                            Az=(cosd(o.theta)-beta_para).*Jm_xi_spark;
                            etaz_resonant=coeff_emission*Az.^2;
                            
                            Jz_xi=etaz_resonant.*2*pi.*pc.^2*ne./abs(ddeltadp);
                            alpha_xi=coeff_absorption*Jz_xi.*Common_part;
                            J(kk)=trapz(xic,Jz_xi.*f_resonant);
                            alpha(kk)=trapz(xic,alpha_xi);
                        case 'Bernstein'
                            Ax=cosd(o.theta)/sind(o.theta).*(cosd(o.theta)-beta_para).*Jm_xi_spark;
                            etax_resonant=coeff_emission*Ax.^2;
                            
                            Jx_xi=etax_resonant.*2*pi.*pc.^2*ne./abs(ddeltadp);
                            alpha_xi=coeff_absorption*Jx_xi.*Common_part;
                            J(kk)=trapz(xic,Jx_xi.*f_resonant);
                            alpha(kk)=trapz(xic,alpha_xi);
                        otherwise
                            error('Wrong wavetype ,please check whether wavetpye is X / O or Bernstein');
                    end
                end
                o.Js(:,jj)=J;
                o.alphas(:,jj)=alpha;
            end
        end
    end
    
    properties %Commonly used variables
        dfdp_delta
        beta
        Jm
        dJmdx
        I_ece
        x_ece
        tau
    end
    
    
    properties     %Special parameters
        Js
        alphas
        Pinitial
    end
    
    
    methods %%%prepare some necessary parameters
        function Calculate_Common_Parameters(o)
%             gamma2D=o.grid.gamma2D;
%             o.beta.abso2D=sqrt(gamma2D.^2-1)./gamma2D;
%             o.beta.Para2D=o.beta.abso2D.*o.grid.xi2D;
%             o.beta.Perp2D=o.beta.abso2D.*sqrt(1-o.grid.xi2D.^2);
            %%%  calculate the dJmdxi and Jm  %%%
            syms x
            Jmf=besselj(o.m,x);
            o.Jm=matlabFunction(Jmf);
            dJmdxf=(besselj(o.m-1,x)-besselj(o.m+1,x))/2;
            o.dJmdx=matlabFunction(dJmdxf);
            syms p xi  wn
            gam=sqrt(1+p.^2);
            deltaf=(1-p./gam.*xi*cosd(o.theta))*wn-o.m./gam;
            dfdpf=diff(deltaf,p);
            o.dfdp_delta =matlabFunction(dfdpf);
        end
        
        
        function ne=ne_profile(o,x)
            a=0.45;
            nr=x/a;
            if x<a&&x>-a
                ne=o.ne0*(1-nr.^2).^2;
                ne=max(1,ne);
            else
                ne=0;
            end
        end
        
        function B=B_profile(o,x)
            Rc=1.85;R=x+Rc;
            B=o.B0*Rc./R;
        end
        
        function te=Te_profile(o,x)
            a=0.45;
            nr=x/a;
%             if x<a&&x>-a
                te=o.Te0*(1-nr.^2).^2;
                te=max(1e1,te);
%             else
%                 te=realmin;
%             end
        end
        
        
        function x=omegatoradius(o,omega)
            %omega:rad/s
            e =o.constants.e;
            me=o.constants.m;
            Rc=1.85;
            B =omega*me/e/o.m0;
            x =o.B0*Rc./B-Rc;
        end
        
        
        
        function f=Theraml_Legmode_distribution(o,Te)
            %thermal distribution in legendre mode
            e=o.constants.e;
            me=o.constants.m;
            c=o.constants.c;
            o.Pinitial=sqrt(2*e*Te/me/c^2);
            f0=@(y)(pi*o.Pinitial^2).^(-3/2)*exp(-y.^2/o.Pinitial^2);
            fls=zeros(1,o.nL*o.nP);
            fls(1:o.nP)=f0(o.grid.p);
            f(:,1)=fls;
        end
    end
    
    
    properties
        legModesToBigVectorMap
        bigVectorToLegModeMap
    end
    
    methods %%% Mapping to Legendre modes %%%
        function BuildMappingMatrices(o)
            % Constructs matrices for mapping between the 2D
            % finite-difference grid and finite-difference--Legendre-mode
            % representations.
            %
            % Usage:
            %   BuildMappingMatrices()
            %
            
            nP  = o.grid.nP ;
            nXi = o.grid.nXi;
            
            %%%Build a matrix describing the mapping from a Legendre-mode
            %%%vector to a vector on the 2D finite-difference grid
            mapMat = sparse(nP*nXi, nP*o.nL);
            cellOfRowBlocks = cell(nXi,1);
            
            %Make a (nP-1)x(nP) block with ones on the first upper
            %diagonal, which we will then duplicate horizontally, weighted
            %by P_l, to form a "row block". Row block i gives the mapping
            %to f(p,xi_i).
            identityBlock = speye(nP);
            
            Pls = o.LegendrePolynomials(o.nL-1,o.grid.xi');
            for iXi = 1:nXi
                PlsAtXi = Pls(:,iXi)';
                cellOfRowBlocks{iXi} = kron(PlsAtXi,identityBlock);
            end
            
            mapMat = cell2mat(cellOfRowBlocks);
            o.legModesToBigVectorMap = mapMat;
            
            
            %%%Invert the matrix to get the inverse mapping from the
            %%%2D finite-difference grid
            %%%vector to Legendre modes
            %This should give accuracy to machine precision. The matrix is
            %rectangular, so we need to use the pseudo inverse. The
            %following is equivalent to pinv(full(mapMat)), but works for
            %sparse matrices (and the result is pretty sparse, so storing
            %is not an issue):
            r = qr(mapMat,0);
            o.bigVectorToLegModeMap = r\(r'\mapMat');
        end
        
        function fls = MapBigVectorToLegModes(o,f)
            % Maps a quantity defined on the 2D finite-difference grid to
            % the finite-difference--Legendre-mode space
            %
            % Usage:
            %   fls = MapBigVectorToLegModes(f)
            
            fls = o.bigVectorToLegModeMap*f;
        end
        
        function f = MapLegModesToBigVector(o,fls)
            % Maps a quantity in the finite-difference--Legendre-mode space
            % to the 2D finite-difference grid.
            %
            % Usage:
            %   f = MapLegModesToBigVector(fls)
            
            f = o.legModesToBigVectorMap*fls;
        end
        
        function f2D=MapVectorToGrid(o,f)
            f2D=reshape(f,[],o.grid.nXi);
        end
        
        function f=MapGridToVector(o,f2D)
            f=reshape(f2D,[],1);
        end
        
        function plot_alphas_distribution(o)
            Almax=max(max(o.alphas));
            for j=1:length(o.xs)
                plot(o.xs{j}./o.a,o.alphas(:,j)./Almax);
                line([max(o.xs{j}),max(o.xs{j})]./o.a,[0 1],'color','k','linestyle','--');
                hold on
            end
            hold off
            axis tight
            xlabel('\rho')
            ylabel('\alpha [a.u.]')
        end
        
        function plot_Js_distribution(o)
            Jmax=max(max(o.Js));
            for j=1:length(o.xs)
                h(j)=plot(o.xs{j}./o.a,o.Js(:,j)./Jmax);
                hold on
                h(j+1)=line([max(o.xs{j}),max(o.xs{j})]./o.a,[0 1],'color','k','linestyle','--');
                A{j}=[num2str(o.omegas(j)/2/pi/1e9),'Ghz'];
            end
            A{j+1}=['Cold Resonant'];         
%             legend([h(1),h(2),h(3),h(4)],char(A{1}),char(A{2}),char(A{3}),char(A{4}))
            hold off
            xlabel('\rho');
            ylabel('J [a.u.]');
            
        end
        
        function plot_tau_distribution(o)
%             opticalthickness2023_8(o.ne0/1e19,o.Te0/1e3,o.B0)
%             hold on
            plot(o.x_ece./o.a,o.tau,'*-')
            xlabel('\rho')
            ylabel('\tau')
%             legend('2x-Bornatic','2x-Trubnikov')
            
            
        end
        
        function plot_I_distribution(o)
            plot(o.x_ece./o.a,o.I_ece,'*-')
            xlabel('\rho')
            ylabel('Intensity[a.u.]')
        end
        
        function plot_Teff_distribution(o)
           c=o.constants.c;
           e=o.constants.e;
           coeff=o.omegas.^2/(8*pi^3*c^2)*e;
            xs=linspace(-o.a,o.a,100);
            Tr=o.I_ece./coeff/1E3;
            plot(xs/o.a,o.Te_profile(xs)/1E3,'-')           
            hold on;
            plot(o.x_ece/o.a,Tr,'*--')
            hold off
            
            xlabel('\rho')
            ylabel('Kev')
            b=legend('Thermal Te','Radiation T_r');
            set(b,'box','off')
        end
        
       function plot_Teff_modify_distribution(o)
           c=o.constants.c;
           e=o.constants.e;
           coeff=o.omegas.^2/(8*pi^3*c^2)*e;
            xs=linspace(-o.a,o.a,100);
            Tr=o.I_ece./coeff/1E3;
            plot(xs/o.a,o.Te_profile(xs)/1E3,'-')           
            hold on;
            plot(o.x_ece/o.a,Tr,'*--')
%           xlabel('r/m')
            r_modify=omega2rmodify(o,o.omegas,Tr);
            plot(r_modify/o.a,Tr,'sk-')
            xlabel('\rho')
            ylabel('Kev')
            b=legend('Thermal Te','Before-Modi T_r','After-Modi T_r');
            set(b,'box','off')
            axis tight
            hold off
%             grid on;set(gca,'GridLineStyle',':','GridColor','k','GridAlpha',1);
       end
       
       function plot_Relative_Error_distribution(o)
            c=o.constants.c;
           e=o.constants.e;
           coeff=o.omegas.^2/(8*pi^3*c^2)*e;
            Tr=o.I_ece./coeff/1E3;
            Te=o.Te_profile(o.x_ece)/1E3;
            r_modify=omega2rmodify(o,o.omegas,Tr);
            Tr_modiy=o.Te_profile(r_modify)/1E3;
            Error_before=abs(Tr-Te)./Te;
            Error_After=abs(Tr-Tr_modiy)./Tr_modiy;            
            plot(o.x_ece./o.a,Error_before*100,'*-')
            hold on
            plot(r_modify./o.a,Error_After*100,'sk-');
            b=legend('Before-Modi T_r','After-Modi T_r')
            set(b,'box','off')
            ylabel('Relative Error [%]')
            ylim([0 30])
            xlim([-1 1])
            xlabel('\phi')
            
            
            
       end
        
       function r_modify=omega2rmodify(o,omegas,Tr)
       %Tr:keV,omegas:rad/s;
       me=o.constants.m;c=o.constants.c;
%        omegas_real=omegas+1e3*o.constants.e*Tr/(me*c^2).*omegas;%俞老师诊断书
       omegas_real=omegas./(1-1e3*o.constants.e*Tr/(me*c^2));
       r_modify=omegatoradius(o,omegas_real);
       end
        
        
        function Caculate_I_distribution(o)
            switch o.direction
                case 'L'
                    for jj=1:length(o.xs)
                         if isempty(o.xs{jj})
                            o.x_ece(jj)=nan;
                            continue
                        end
                        J=o.Js(:,jj);
                        alpha=o.alphas(:,jj);
                        s=o.xs{jj};
                        [s,I]=sort(s);
                        J=J(I);alpha=alpha(I);
                        J(isnan(J))=0;
                        alpha(isnan(alpha))=0;
                        ds=diff(s);
                        Is(1)=0;

                        for kk=1:length(o.xs{jj})-1
                            Is(kk+1)=Is(kk)+(J(kk)-alpha(kk)*Is(kk))*ds(kk);
                        end
                        
                        o.tau(jj)=trapz(s,alpha);
                        o.I_ece(jj)=Is(end);
                        o.x_ece(jj)=s(end);
                        
                    end
                    
                case  'H'
                    for jj=1:length(o.xs)
                        J=o.Js(:,jj);
                        alpha=o.alphas(:,jj)
                        s=o.xs{jj};
                        J(isnan(J))=0;
                        alpha(isnan(alpha))=0;
                        ds=abs(diff(s));
                        Is(1)=0;
                        if isempty(s)
                            o.x_ece(jj)=nan;
                            continue
                        end
                        for kk=1:length(o.xs{jj})
                            Is(kk+1)=Is(kk)+(J(kk)-alpha(kk)*Is(kk))*ds(kk);
                        end
                        
                        o.tau(jj)=trapz(s,alpha);
                        o.I_ece(jj)=Is(end);
                        o.x_ece(jj)=s(end);
                        
                    end
                otherwise
                    error('unable to solve,please check whether the direction is L or H')
            end
        end
    end
    
    
    
    
    methods (Static) %   ...   %%%
        function outPls = LegendrePolynomials(l,x)
            % Calculates the legendre polynomials P_i(x) for i=0,1,...,l
            % using Bonnet's recursion formula:
            %   (n+1)*P_{n+1}(x) = (2n+1)*x*P_n(x) - n*P_{n-1}(x),
            % where P_0(x) = 1 and P_1(x) = x.
            %
            % Usage:
            %   pls = LegendrePolynomials(l,x)
            %
            % l is the (highest) mode number and x is the coordinate, which
            % must be a row vector (not a matrix). pls has the structure
            %   [ P_0(x) ]
            %   [ P_1(x) ]
            %   [   ...  ]
            %   [ P_l(x) ]
            %
            
            %Check input
            if ~(isscalar(l) && isnumeric(l) && isreal(l) && l>=0)
                error('Invalid mode number.');
            end
            if size(x,1) > 1
                error('The argument must be presented as a row vector.');
            end
            if any(x<(-1-eps)) || any(x>(1+eps))
                error('The argument is out of the range [-1,1].');
            end
            
            %Initialize the output and include the first two modes.
            outPls(l+1,numel(x)) = 0;
            outPls(1,:) = ones(size(x));
            if l>=1
                outPls(2,:) = x;
            end
            
            for n = 1:l-1
                %The index n reflects the n in Bonnet's formula, but the
                %corresponding row in the array is n+1. We start from n=1, since we
                %want to use the formula to compute n+1=2 (which goes on row n+2=3)
                outPls(n+2,:) = (2*n+1)/(n+1) * x.*outPls(n+1,:) ...
                    - n/(n+1) * outPls(n,:);
            end
            
        end
             
    end
end