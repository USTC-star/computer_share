%%% This script is an attempt to change the structures into object-oriented
%%% programming,including setting parameters
%%% Writen by Xu Xinhang ,2023，8月11日
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear              
clc                
close all
%% Resolution and parameters 
Z       = 1         ;      %Z_eff
B       = 2.4      ;      %T
ne      =1e19       ;      %m^{-3}
E       =-0.1       ;      %V/m    
Te      =10E3        ;      %eV
nP    =570        ;
nXi   =300        ;
nL    =40        ;
pMax  =10        ;           %mc
dt    =1e-3      ;
tMax  =0.1       ;
m     =2                     ;
wavetype= 'X'                ;
%% 主程序
tic
p= KINETIC_Code_Model_2(nP,pMax,nXi,nL,dt,tMax,Z,B,ne,E,Te);
toc
%% space distribution
x=linspace(-0.44,0.44,23)  ;%/m 空间采样位置
tpick=0                    ;%/s 选择时间点                   
omegas=2*radius2omega(x,B)   ;%rad/s计算对应位置的冷等离子电子回旋角频率
p.ne=TimeDependentParameter(1,ne);%TimeDependentParameter是一个插值函数，这里表示密度随时间是一个常数，为了方便后续函数调用采用了这种形式。
o=Nothermal_Radiation_Space_New(omegas,m,wavetype,p,tpick);
o.plot_Teff_distribution

%% time evolution
x=0.1                  ;%[m]. 选择某一个位置对应的冷等离子电子回旋频率辐射演化，注意x必须大于零。attention：x must be great than -3
omegas=2*radius2omega(x,B)   ;
p.ne=TimeDependentParameter(1,ne);
q=Nothermal_Radiation_Timeslice_second3(omegas,m,wavetype,p);
q.plot_Teff_envolution





                        
