classdef TimeDependentParameter
    % TIMEDEPENDENTPARAMETER -- Class for defining time-dependent 
    %                           parameters in NORSE. 
    %
    % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Copyright (C) 2016  Adam Stahl
    %
    % This file is part of NORSE.
    %
    % NORSE is free software: you can redistribute it and/or modify it
    % under the terms of the GNU General Public License as published by the
    % Free Software Foundation, either version 3 of the License, or (at
    % your option) any later version.
    %
    % NORSE is distributed in the hope that it will be useful, but WITHOUT
    % ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    % FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    % for more details.
    %
    % You should have received a copy of the GNU General Public License
    % along with NORSE. If not, see <http://www.gnu.org/licenses/>.
    % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %
    % %%%%%%%%%%%%%%%%%%%%%%%%%%%
    %   Description and usage: 
    % %%%%%%%%%%%%%%%%%%%%%%%%%%%
    %
    % Allows to specify the parameter values (f) at arbitrary time points
    % (t) and storing it in a spline, which can be evaluated in NORSE as
    % neeeded. f and t must be of the same size, and may be scalar.
    %
    % Usage:
    %   par = TimeDependentParameter(t,f); 
    %   par = TimeDependentParameter(t,f,isStepWiseConst,isConstOutsideRange); 
    %
    % The class supports simple indexing and many common operations: 
    %   par = TimeDependentParameter(t,f); 
    %   val = par(t1);    %Evaluates the spline at t=t1 
    %   par2 = par*par;   %par2 is a new TimeDependentParameter such that 
    %                     %par2(tt) = par(tt)*par(tt) at any time tt. 
    %    
    % If isStepWiseConst=1 is passed, f is treated as constant in between
    % the supplied data points. The result is a step-like behavior of f 
    % (not default). This also automatically sets isConstOutsideRange=1. f
    % will change value exactly at the specified times. 
    %   Example: 
    %       t=[0,1,2], f=[0,10,0] 
    %     will result in par(0.99)=0, par(1)=10, par(1.99)=10, par(>=2)=0.
    %       
    %
    % If isConstOutsideRange=1 is passed (default), the function is assumed 
    % constant outside the specified time interval:
    %   par(t0) == par(t(1)) 
    % for t0<t(1), and 
    %   par(t2) == par(t(end))
    % for t2>t(end). Otherwise, the spline is used for extrapolation.
    %
    %
    % The following calls are allowed:
    %   par(t) -- Evaluates the spline at the times in vector t
    %   par.MethodOrProperty()     -- Call class method or property
    %   par.MethodOrProperty(args) -- Call with arguments
    %   par.property.field         -- Access fields of a property struct
    % The following operations are supported (see the respective class
    % method for details):
    %   +, -, *, /, log, log10, power (^), sqrt, double & besselk.
    %
    % All other calls and operations are undefined and will produce an
    % error, however additional unary or binary operations can easily be
    % included by calling the class methods ApplyUnaryOperator(f) and
    % ApplyBinaryOperator(f,b).
    %
    % The boolean property isScalar specifies whether the
    % timeDependentParameter describes a constant or is time dependent.
    %    
    % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
    %%% Settings and interface methods %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    properties 
        isStepWiseConst = 0
        isConstantOutsideRange = 1
    end
    
    methods 
        function o = TimeDependentParameter(t,f,varargin)
            % Constructor. 
            %
            % Usage:
            %   par = TimeDependentParameter(t,f); 
            %   par = TimeDependentParameter(t,f,isStepWiseConst,isConstOutsideRange); 
            
            if ~all(size(t) == size(f)) || ~isvector(t) || ~isnumeric(t) || ~isnumeric(f)
                error('Invalid input argument dimenstions.');
            end
            if nargin >= 4  
                if isscalar(varargin{1}) && isnumeric(varargin{1}) ...
                        && isscalar(varargin{2}) && isnumeric(varargin{2}) 
                    o.isStepWiseConst = varargin{1};
                    if o.isStepWiseConst
                        o.isConstantOutsideRange = 1; 
                    else
                        o.isConstantOutsideRange = varargin{2}; 
                    end
                else
                    error('Invalid third or fourth input argument.'); 
                end
            end
            switch numel(t)
                case 0
                    o.isScalar = 1;
                    o.parameterSpline = 0;                    
                case 1
                    o.isScalar = 1;
                    o.parameterSpline = f; %Store the value directly
                    o.tMin = t;
                    o.tMax = t;
                otherwise                    
                    if o.isStepWiseConst
                        %Determine where f changes value and make a spline
                        %consisting of a series of constant polynomials 
                        %(steps).
                        breaks = find(diff(f)) + 1;
                        breaksWEdges = unique([1;breaks(:);numel(f)]);
                        fs = f(breaksWEdges);
                        o.parameterSpline = ppmak([t(breaksWEdges),t(end)+eps],fs);
                    else
                        %A continuous function -- use a spline or a pchip.
                        %The latter is better behaved since it is constant
                        %on intervals whose endpoints are the same.
                        o.parameterSpline = pchip(t,f); 
%                         o.parameterSpline = spline(t,f);                     
                    end 
                    o.tMin = t(1);
                    o.tMax = t(end);
            end
        end
        
        function val = Evaluate(o,t)
            % Returns the function value at the times specified by the
            % vector t.
            %
            % Usage:
            %   val = Evaulate(t)
            
            if o.isScalar
                 val = o.parameterSpline*ones(size(t));            
            else
                val = ppval(o.parameterSpline,t); %Evaluate the spline
                if o.isConstantOutsideRange
                    val(t<=o.tMin) = ppval(o.parameterSpline,o.tMin);                
                    val(t>=o.tMax) = ppval(o.parameterSpline,o.tMax);
                end
            end
        end
        
        function o = Rescale(o,tFac)
            % Rescales the time axis so that tNew = tFac*tOld.
            %
            % Usage:
            %   par = par.Rescale(tFac)
            
            if ~o.isScalar
                %Change the times at which the spline is defined
                breaks = tFac*o.parameterSpline.breaks;
                o.parameterSpline.breaks = breaks;
                o.tMin = breaks(1);
                o.tMax = breaks(end);
                
                %Change the polynomial coefficients to match the new times
                polynomialOrder = o.parameterSpline.order-1;
                scaleFacs = tFac.^(polynomialOrder:-1:0);
                o.parameterSpline.coefs = o.parameterSpline.coefs*diag(1./scaleFacs);                
            end            
        end
       
        function out = Visualize(o,varargin)
            % Plots the spline and marks the specified data points. The
            % optional argument specifies the figure in which to plot. If
            % the parameter is constant in time, information is instead
            % printed to the console.
            %
            % Usage:
            %   Visualize()
            %   Visualize(hFig)
            
            nPoints = 300; %to use for plotting the function value
            
            if o.isScalar
                 fprintf('The parameter is constant, with the value: %.5g.\n',o.parameterSpline);
                 out = []; %This is needed for handling the modified indexing
            else
                if nargin == 2
                    hFig = figure(varargin{1});
                else
                    hFig = figure(555);
                end                
                clf;
                
                dataPoints = o.parameterSpline.breaks; %Specified points
                pts = linspace(o.tMin,o.tMax,nPoints); 
                
                plot(pts,o.Evaluate(pts),'-k');
                hold on;
                plot(dataPoints,o.Evaluate(dataPoints),'*r');
                
                xlabel('Time');
                ylabel('Parameter value');
                xlim([o.tMin,o.tMax]);
                out = []; %This is needed for handling the modified indexing
            end            
        end        
    end
    
    %%% Internal properties and methods %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    properties 
        parameterSpline
        tMin = 0
        tMax = 0
        isScalar = 0         
    end
    
    methods %%% Utilities for indexing and overloaded operators %%% 
        function varargout = subsref(o,s)
            %Overload the standard Matlab array indexing to evaluate the
            %spline at the speficied time. This makes calls of the type 
            %par(t1) and par([t1,t2,...]) possible.
            %
            % Allowed calls:
            %   par(t) -- Evaluates the spline at the times in vector t
            %   par.MethodOrProperty()     -- Call class method or property
            %   par.MethodOrProperty(args) -- Call with arguments
            %   par.property.field     -- Access fields of a struct
            %
            % All other operations are undefined and will produce an error.
                        
            errT = 'Invalid indexing operation. TimeDependentParameter only supports limited indexing functionality.';

            switch s(1).type
                case '()' %Evaluate the spline at the provided times
                    if numel(s) == 1 && numel(s.subs) == 1 && ~isempty(s.subs{1})
                        t = s.subs{1};                
                        varargout{:} = o.Evaluate(t);
                    else
                        error(errT);
                    end
                case '.' %Access class methods and properties
                    switch numel(s)
                        case 1 %Method/property reference without arguments
                            varargout{:} = o.(s(1).subs);
                        case 2 
                            if strcmp(s(2).type,'()') %Reference with arguments to the method/property
                                varargout{:} = o.(s(1).subs)(s(2).subs{:});
                            elseif strcmp(s(2).type,'.') %Reference fields of a property that is a struct
                                varargout{:} = o.(s(1).subs).(s(2).subs);
                            else
                                error(errT); 
                            end
                        otherwise
                            error(errT);
                    end
                otherwise
                    error(errT);
            end
            
            %Only provide output if the user requests it
            if numel(varargout) == 1 && isempty(varargout{1})
                varargout = {}; 
            end
        end
        
        function val = ApplyUnaryOperator(o,f)
            % Applies a unary operator to a TimeDependentParameter. f must
            % be a function handle to a unary operator such as log or sin.
            %
            % Usage:
            %   val = ApplyUnaryOperator(f)
            
            if o.isScalar
                val = o;
                val.parameterSpline = f(val.parameterSpline);
            elseif o.isStepWiseConst %Change value at defined time points
                val = o;
                val.parameterSpline.coefs = f(val.parameterSpline.coefs);
            else %Smooth function -- make a new object
                breaks = o.parameterSpline.breaks;
                val = TimeDependentParameter(breaks,f(o.Evaluate(breaks)),...
                                o.isStepWiseConst,o.isConstantOutsideRange);
            end
        end
        
        function val = ApplyBinaryOperator(o,f,b)
            % Applies a binary operator to a TimeDependentParameter. f must
            % be a function handle to a binary operator (such as power)
            % which takes a second argument b.
            %
            % Usage:
            %   val = ApplyBinaryOperator(f,b)
            
            if o.isScalar
                val = o;
                val.parameterSpline = f(val.parameterSpline,b);
            elseif o.isStepWiseConst %Change value at defined time points
                val = o;
                val.parameterSpline.coefs = f(val.parameterSpline.coefs,b);
            else %Smooth function -- make a new object
                breaks = o.parameterSpline.breaks;
                val = TimeDependentParameter(breaks,f(o.Evaluate(breaks),b),...
                                o.isStepWiseConst,o.isConstantOutsideRange);
            end
        end        
    end
    
    methods %%% Overloaded operators %%%
        % The operations +, -, * and / are defined below.
        %
        % When operating on two TimeDependentParameters, the operation is
        % performed on the function values at all time points (for any
        % object) where the spline is specified. The result is a new
        % TimeDependentParameter, defined at all time points of either
        % initial object.
        %
        % Note that, in general, the operations do not commute since the
        % properties isStepWiseConst and isConstantOutsideRange are
        % inherited from the first non-constant object.
        function val = mrdivide(o,denom)
            % Defines the following division operations (s is a scalar and
            % par a TimeDependentParameter):
            %   par/s, s/par & par/par                        
            
            if isnumeric(o) && isscalar(o) %s/par
                %We have s/par, since we know that at least one of the
                %arguments must be the object.
                val = denom;
                if denom.isScalar                    
                    val.parameterSpline = o./val.parameterSpline;  
                elseif denom.isStepWiseConst                    
                    val.parameterSpline.coefs = o./val.parameterSpline.coefs;  
                else %Continuous function --  create a new object
                    breaks = val.parameterSpline.breaks;
                    val = TimeDependentParameter(breaks,o./val.Evaluate(breaks),...
                                val.isStepWiseConst,val.isConstantOutsideRange);                    
                end
            elseif isa(denom,'TimeDependentParameter') %par/par
                %Defines division between TimeDependentParameter objects
                if denom.isScalar
                    val = o/denom.parameterSpline; %Properties from o (not denom!) are inherited.                    
                elseif o.isScalar
                    val = o.parameterSpline/denom; %Properties from denom (not o!) are inherited.                    
                else
                    %Both are time-dependent -- create a new object defined
                    %at all the time points of the two input objects
                    oT = o.parameterSpline.breaks;
                    denomT = denom.parameterSpline.breaks;
                    times = unique(sort([oT,denomT]));
                    vals = o.Evaluate(times)./denom.Evaluate(times);
                    val = TimeDependentParameter(times,vals,...
                                o.isStepWiseConst,o.isConstantOutsideRange);
                end
            elseif isnumeric(denom) && isscalar(denom) %par/s
                val = o.ApplyBinaryOperator(@mrdivide,denom);                
            else
                error('Only division involving a scalar or another TimeDependentParameter object is defined.');                
            end
        end
        
        function val = mtimes(o,fact)
            % Defines the following multiplication operations (s is a
            % scalar and par a TimeDependentParameter):
            %   par*s=s*par & par1*par2
            
            if ~isa(o,'TimeDependentParameter')
                % This should correspond to s*par. Call the function again,
                % but switch the arguments.
                val = mtimes(fact,o);                 
            elseif isa(fact,'TimeDependentParameter')
                %Defines multiplication of TimeDependentParameter objects
                if fact.isScalar
                    val = o*fact.parameterSpline; %Properties from o (not fact!) are inherited.                    
                elseif o.isScalar
                    val = fact*o.parameterSpline; %Properties from fact (not o!) are inherited.                    
                else
                    %Both are time-dependent -- create a new object defined
                    %at all the time points of the two input objects
                    oT = o.parameterSpline.breaks;
                    factT = fact.parameterSpline.breaks;
                    times = unique(sort([oT,factT]));
                    vals = o.Evaluate(times).*fact.Evaluate(times);
                    val = TimeDependentParameter(times,vals,...
                                o.isStepWiseConst,o.isConstantOutsideRange);
                end
            elseif isnumeric(fact) && isscalar(fact)    
                val = o.ApplyBinaryOperator(@mtimes,fact);                
            else
                error('Only multiplication by a scalar or another TimeDependentParameter object is defined.');                
            end
        end
        
        function val = plus(o,scal)
            % Defines the following addition operations (s is a scalar and
            % par a TimeDependentParameter):
            %   par+s=s+par & par1+par2
                        
            if isnumeric(o) && isscalar(o)
                % This corresponds to s+par. Call the function again, but
                % switch the arguments.
                val = plus(scal,o); 
            elseif isa(scal,'TimeDependentParameter')
                %Defines addition of TimeDependentParameter objects
                if scal.isScalar
                    val = o+scal.parameterSpline; %Properties from o (not fact!) are inherited.                    
                elseif o.isScalar
                    val = scal+o.parameterSpline; %Properties from fact (not o!) are inherited.                    
                else
                    %Both are time-dependent -- create a new object defined
                    %at all the time points of the two input objects
                    oT = o.parameterSpline.breaks;
                    scalT = scal.parameterSpline.breaks;
                    times = unique(sort([oT,scalT]));
                    vals = o.Evaluate(times)+scal.Evaluate(times);
                    val = TimeDependentParameter(times,vals,...
                                o.isStepWiseConst,o.isConstantOutsideRange);
                end
            elseif isnumeric(scal) && isscalar(scal)    
                val = o.ApplyBinaryOperator(@plus,scal);                
            else
                error('Only addition of a scalar or another TimeDependentParameter object is defined.');
            end
        end
        
        function val = minus(o,scal)
            % Defines the following subtraction operations (s is a scalar
            % and par a TimeDependentParameter):
            %   par-s, s-par & par1-par2
            
            if isa(o,'TimeDependentParameter') && isa(scal,'TimeDependentParameter')
                %par-par; defines subtraction of TimeDependentParameter objects
                if scal.isScalar
                    val = o-scal.parameterSpline; %Properties from o (not fact!) are inherited.                    
                elseif o.isScalar
                    val = o.parameterSpline-scal; %Properties from fact (not o!) are inherited.                    
                else
                    %Both are time-dependent -- create a new object defined
                    %at all the time points of the two input objects
                    oT = o.parameterSpline.breaks;
                    scalT = scal.parameterSpline.breaks;
                    times = unique(sort([oT,scalT]));
                    vals = o.Evaluate(times)-scal.Evaluate(times);
                    val = TimeDependentParameter(times,vals,...
                                o.isStepWiseConst,o.isConstantOutsideRange);
                end
            elseif isa(o,'TimeDependentParameter')
                %par-s
                if isnumeric(scal) && isscalar(scal)
                    val = o.ApplyBinaryOperator(@minus,scal);
                else
                    error('This subtraction operation is not defined.');
                end
            else
                %s-par
                if isnumeric(o) && isscalar(o)                    
                    val = scal;
                    if val.isScalar
                        val.parameterSpline = o-val.parameterSpline;
                    elseif val.isStepWiseConst
                        val.parameterSpline.coefs = o-val.parameterSpline.coefs;
                    else
                        breaks = val.parameterSpline.breaks;
                        val = TimeDependentParameter(breaks,o-val.Evaluate(breaks),...
                                val.isStepWiseConst,val.isConstantOutsideRange);
                    end
                else
                    error('This subtraction operation is not defined.');
                end
            end
        end
        
        
        %Other unary or binary operators -- perform the corresponding
        %operation on the points where the spline is defined.
        function val = log(o)
            val = o.ApplyUnaryOperator(@log);
        end
        
        function val = log10(o)
            val = o.ApplyUnaryOperator(@log10);
        end        
        
        function val = power(o,xp)
            %Only supports scalar exponents
            
            if ~isa(o,'TimeDependentParameter') || ~isnumeric(xp) || ~isscalar(xp)
                error('The operation is not defined.');
            end
            val = o.ApplyBinaryOperator(@power,xp);
        end
        
        function val = sqrt(o)
            val = o.ApplyUnaryOperator(@sqrt);
        end        
        
        function val = double(o)
            %Only works on scalar objects
            
            if o.isScalar
                val = o.parameterSpline;
            else
                error('Conversion to double is only possible for scalar TimeDependentParameter objects.');
            end
        end
        
        function val = besselk(nu,o,varargin)
            if nargin == 3
                f = @(x) besselk(nu,x,varargin{1});
            else
                f = @(x) besselk(nu,x);
            end
            val = o.ApplyUnaryOperator(f);
        end
    end    
end
