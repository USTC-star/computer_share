%%% This script is an attempt to change the structures into object-oriented
%%% programming,including setting parameters
%%% Writen by Xu Xinhang ,2022
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear              
clc                
close all
%% Resolution and parameters 
Z       = 1         ;      %Z_eff
B       = 2.4      ;      %T
ne      =1e19       ;      %m^{-3}
E       =-0.1       ;      %V/m    
Te      =10E3        ;      %eV
nP    =570        ;
nXi   =300        ;
nL    =40        ;
pMax  =10        ;           %mc
dt    =1e-3      ;
tMax  =0.1       ;
m     =2                     ;
wavetype= 'X'                ;
tic
p= KINETIC_Code_Model_2(nP,pMax,nXi,nL,dt,tMax,Z,B,ne,E,Te);
toc

% p.plot_ne_evolution         
% p.plot_distribution_movie
% xlim([-1.5 1.5])
% ylim([0 1])
% close all  
% p.plot_perturbation_theory_vs_numerical
% p.plot_avalanche_distribution_movie
% p.plot_Temperature_fit
% hold on
% p.plot_Temperature_theory
% legend('Te-Effective ','Te-Fitting','Te-Theory')
% xlim([0 30])
% ylim([0.5 3.5])
% hold off
% legend('Landreman-model','Pike-model')
% hold off
%  p.plot_F1_distibution([0 1e-4 2E-4 3e-4 4e-4,1e-3,5e-3])
% xlim([0 0.2])
% ylim([0 800])
% p.fit__numrical_temperature
% p.Calculate_runaway_growthRate
% hold on
% p.Calculate_runaway_Ratio
% hold off


%% space distribution
x=linspace(-0.44,0.44,23)  ;
% x=0.1                  ;
% B       =1.2   ;     %T
omegas=2*radius2omega(x,B)   ;
% omegas=[143 131 121 113]*1e9*2*pi;
fs=omegas/2/pi/1e9           ;
omega0=2*radius2omega(0,B)   ;
pc=sqrt((omega0./omegas).^2-1);
p.ne=TimeDependentParameter(1,ne)
% o=Nothermal_Radiation_Timeslice_second(omegas,ne,B,Te,p,m,nP,nXi,pMax,nL,wavetype,p.pGridMode,p.xiGridMode,p.pGridParameter);
%   o=Nothermal_Radiation_Timeslice_second3(omegas,2,wavetype,p);
 o=Nothermal_Radiation_Space_New(omegas,m,wavetype,p,0);
% o=p.Anomalous;  
% toc
% p.plot_distribution_movie ()       
% o.plot_Teff_envolution
% o.plot_tau_distribution()

%%
 x=0.1                  ;
% B       =1.2   ;     %T
omegas=2*radius2omega(x,B)   ;
% omegas=[143 131 121 113]*1e9*2*pi;
fs=omegas/2/pi/1e9           ;
omega0=2*radius2omega(0,B)   ;
pc=sqrt((omega0./omegas).^2-1);
p.ne=TimeDependentParameter(1,ne)
% o=Nothermal_Radiation_Timeslice_second(omegas,ne,B,Te,p,m,nP,nXi,pMax,nL,wavetype,p.pGridMode,p.xiGridMode,p.pGridParameter);
%   o=Nothermal_Radiation_Timeslice_second3(omegas,2,wavetype,p);
 o=Nothermal_Radiation_Space_New(omegas,m,wavetype,p,0);
% o=p.Anomalous;  
% toc
% p.plot_distribution_movie ()       
% o.plot_Teff_envolution
% o.plot_tau_distribution()

%% 
subplot(1,2,2)
% o.plot_Teff_modify_distribution 
plot_Relative_Error_distribution(o)
Position=[0.04,0.9];
text('string','(b)','FontSize',14,'Units','normalized','Position',Position,'FontWeight','bold','FontName',...
'Times New Roman')
subplot(1,2,1)
% o.plot_tau_distribution()
o.plot_Teff_modify_distribution 
Position=[0.04,0.9];
text('string','(a)','FontSize',14,'Units','normalized','Position',Position,'FontWeight','bold','FontName',...
'Times New Roman')
xlim([-1,1]);


                        
