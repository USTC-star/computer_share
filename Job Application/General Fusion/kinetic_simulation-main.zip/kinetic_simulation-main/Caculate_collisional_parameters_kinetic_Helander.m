classdef Caculate_collisional_parameters_kinetic_Helander<handle
%reference:
%1.Kinetic modeling of runaway-electron dynamics in partially ionized plasmas
%2.Book,Collisional Transport in Magnetized Plasmas,Per Helander.
    properties
        coeff_cnm3
        coeff_cnm1
        coeff_cnm21
        coeff_cnm22
        THETA0
        Zeff
        lnA0
        nL
        Psi_0_num
        Psi_1_num
        method
        nusee
        pGridParameter
    end
    properties (Constant) %%% Physical constants %%%
        constants = struct('c',   2.997925e8,...
            'e',   1.602176e-19,...
            'm',   9.109380e-31,...
            'eps0',8.854188e-12);
    end
    
    methods
        function o=Caculate_collisional_parameters_kinetic_Helander(varargin)
            %             e = o.constants.e;
            %             me = o.constants.m;
            %             c = o.constants.c;
            %             eps0=o.constants.eps0;
            o.Zeff=varargin{1};
            o.THETA0=varargin{2};
            o.lnA0=varargin{3}  ;
            p=varargin{4};
            s=varargin{5};
            o.nL=varargin{6};
            o.method=varargin{7};
            o.pGridParameter=varargin{8};
            o.Psi_0_num=o.Psi_0(p,o.THETA0);
            o.Psi_1_num=o.Psi_1(p,o.THETA0);
            coeff_cnm3=o.Coefficient_collision_3(p)*(-1/2);
            coeff_cnm1=o.Coefficient_collision_1(p)*(-1);
            coeff_cnm21=o.Coefficient_collision_21(s,p)*(-1);
            coeff_cnm22=o.Coefficient_collision_22(s,p)*(-1);
            o.coeff_cnm3=kron(ones(o.nL,1),coeff_cnm3);
            o.coeff_cnm1=kron(ones(o.nL,1),coeff_cnm1);
            o.coeff_cnm21=kron(ones(o.nL,1),coeff_cnm21);
            o.coeff_cnm22=kron(ones(o.nL,1),coeff_cnm22);
            o.nusee= o.nu_see(p);    
        end
        
        function coeff_cnm3=Coefficient_collision_3(o,y)
            coeff_cnm3=(o.nu_dee(y)+o.nu_dei(y));
        end
        
        function coeff_cnm1=Coefficient_collision_1(o,y)
            coeff_cnm1=1/2.*y.^4.*o.nu_parall(y)*1./y.^2;
        end
        
        function coeff_cnm21=Coefficient_collision_21(o,s,y)
            coeff_cnm21_1=y.^3.*o.nu_see(y);
            coeff_cnm21_rev=o.dss004_nolinear_kinetic(y',coeff_cnm21_1',s');
            coeff_cnm21=coeff_cnm21_rev'*1./y.^2;
            
        end
        
        function coeff_cnm22=Coefficient_collision_22(o,s,y)
            f1=1/2*y.^4.*o.nu_parall(y);
            df1=o.dss004_nolinear_kinetic(y',f1',s');
            coeff_cnm22=(df1'+y.^3.*o.nu_see(y))*1./y.^2;
        end
        
        function nus=nu_see(o,y)
            
            lnAee=o.LnA_ee(y);
            PSI_S=o.Psi_S(y) ;
            nus=1./y.*lnAee./o.lnA0.*PSI_S;
        end
        
        function nu_p=nu_parall(o,y)
            gama=sqrt(1+y.^2);
            nu_p=2*gama.*o.THETA0./y.^3.*o.Psi_S(y);
        end
        
        function nu_de=nu_dee(o,y)
            nu_de=2./y.^2.*o.LnA_ee(y)./o.lnA0.*o.Psi_D(y);
        end
        
        function nu_di=nu_dei(o,y)
            
            gama=sqrt(1+y.^2);
            nu_di=gama./y.^3.*o.LnA_ei(y)./o.lnA0.*o.Zeff;
        end
        
        function LnAee=LnA_ee(o,y)
            
            ga=sqrt(1+y.^2);
            pTe=sqrt(2*o.THETA0);
            ln1=(2*(ga-1)/pTe.^2).^(5/2);
            LnAee=o.lnA0+1/5*log(1+ln1);
        end
        
        function LnAei=LnA_ei(o,y)
            
            %         ga=sqrt(1+y.^2);
            pTe=sqrt(2*o.THETA0);
            ln1=(2*y/pTe).^5;
            LnAei=o.lnA0+1/5*log(1+ln1);
            
        end
        
        function PsiD=Psi_D(o,y)
            gam=sqrt(1+y.^2);
            f1=(y.^2.*gam.^2+o.THETA0.^2).*o.Psi_0_num+o.THETA0.*(2.*y.^4-1).*o.Psi_1_num;
            f2=gam*o.THETA0.*(1+o.THETA0*(2*y.^2-1)).*y.*exp(-gam./o.THETA0);
            f3=2*gam.*y.^3*besselk(2,1/o.THETA0);
            PsiD=(f1+f2)./f3;
        end
        
        function PsiS=Psi_S(o,y)
            gam=sqrt(1+y.^2);
            f1=gam.^2.*o.Psi_1_num -o.THETA0.*o.Psi_0_num+(o.THETA0.*gam-1).*y.*exp(-gam./o.THETA0);
            f2=y.^2.*besselk(2,1/o.THETA0);
            PsiS=f1./f2;
        end
        
        function Psi0=Psi_0(o,y,THETA)
            
            ps0= @(s) 1./sqrt(1+s.^2).*exp(-1*sqrt(1+s.^2)/THETA);
            Psi0=zeros(size(y));
            parfor i=1:length(y)
                Psi0(i)=integral(ps0,0,y(i));
            end
        end
        
        function Psi1=Psi_1(~,y,THETA)
            
            ps1=@(s) exp(-1*sqrt(1+s.^2)/THETA);
            Psi1=zeros(size(y));
            parfor i=1:length(y)
                Psi1(i)=integral(ps1,0,y(i));
            end
            
        end
        
        function [dfdx]=dss004_nolinear_kinetic(o,x,fx,t)
            %nolinear four-order derivate
            %stencil method
            %x:nolinear grid
            %t:linear grid
            %fx:dependent value 
            o.method=4;
            if nargin<5
                h=1;
            end
            if nargin<4
                t=linspace(0,1,length(x));
            end
            if o.method==1
                %s=tanh(t)
              s = t.*t+o.pGridParameter*t;
              dsdt = 2*t+o.pGridParameter;
            elseif o.method==2
                s = t.^3+o.pGridParameter*t;
                dsdt = 3*t.^2+o.pGridParameter;
            elseif o.method==3
                %s=t^3;
                s=t.^4+o.pGridParameter*t;
                dsdt=4*t.^3+o.pGridParameter;
            elseif o.method==4
                dsdt=dss004(t(1),t(end),length(t),x);
            end
            dfdt=dss004(t(1),t(end),length(t),fx);
            dfdx=dfdt./dsdt;
        end
        
    end
end