classdef Gmres <handle
    properties
        Q
        U
        L
        P
       
    end
%     properties
%         rhs
%         matrix
%     end
    methods
        function q=Gmres(matrix,rhs)
         [q.L,q.U,q.P,q.Q] = lu(matrix);
%          q.rhs=rhs;
        end

function  f=PreconditionerFunc(q,rhs)
            % Efficiently computes the preconditioner used in the iterative
            % time advance schemes. Significantly speeds up the computation,
            % compared to supplying the L & U matrices directly.
            %
            % Usage: 
            % f = PreconditionerFunc(rhs)            
            f = q.Q*(q.U\(q.L\(q.P*rhs)));
end  
    end
end