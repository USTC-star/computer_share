classdef Grid_ECEI < matlab.mixin.Copyable
    % GRID_ECEI -- Class that describes the finite-difference grid in
    %         Nonthermal emission  (the coordinate of grid refers to (p,xi ))
    %         calculation, and associated quantities such as
    %         finite-difference derivatives. Also contains various methods
    %         for manipulating the grid.
    %
    % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %
    % %%%%%%%%%%%%%%%%%%%%%%%%%%%
    %   Usage: 
    % %%%%%%%%%%%%%%%%%%%%%%%%%%%
    %
    % Initialize an empty object:
    %   Grid() -- Specify settings and then call InitializeGrid() to
    %             construct the grid.
    %
    % Initialize a grid with given parameters and standard settings:
    %   Grid(nP,nXi,pMax,pGridMode,xiGridMode) 
    %   Grid(nP,nXi,pMax,pGridMode,xiGridMode,pGridParameter)
    %
    %
    % %%%%%%%%%%%%%%%%%%%%%%%%%%%
    %   Settings: 
    % %%%%%%%%%%%%%%%%%%%%%%%%%%%
    %
    % nP             -- Number of points in the p grid.
    % pMax           -- Maximum value of the p grid (p = gamma*v/c).
    % pGridMode      -- Setting for how the nP points between 0 and pMax 
    %                   are chosen. Default: 1
    %                    0: Uniform
    %                    1: Approximately quadratic increase with p 
    %                       (p = s^2 + pGridParameter*s, with s uniform)
    %                    2: Approximately cubic increase with p 
    %                       (p = s^3 + pGridParameter*s, with s uniform)
    %                    3: Approximately quartic increase with p 
    %                       (p = s^4 + pGridParameter*s, with s uniform)
    %                    4: A grid with a tanh step in spacing, giving a 
    %                       dense grid at low p and a sparse grid at high p
    % pGridParameter -- Parameter used in pGridMode = 1-3. Default: 0.2
    % pStepParams    -- Struct of parameters for pGridMode = 4, with fields:
    %   - stepLocation   -- The value of y at which the step in spacing is
    %                       located. y=gamma v/v_th is the thermal momentum.
    %                       Default: 5   
    %   - bulkSpacing    -- Determines the spacing in the bulk (in units of 
    %                       y). Default: 0.01
    %   - Theta          -- The temperature at which the above parameters
    %                       are defined. Default: 0.01 (5.11 kev)
    %   - stepSharpness  -- Determines the rate of change of the spacing at 
    %                       the step. Default: 0.1 (arb. units)
    %
    % nXi            -- Number of points in the xi grid (xi = cos(theta)).
    % xiGridMode     -- Specifies how the nXi grid points between -1 and 1 are
    %                   chosen. Default: 1
    %                    0: Uniform (this mapping requires that nXi is odd)
    %                    1: A sigmoid, denser close to xi=1 
    %                    2: Uniform in the polar angle (arccos(\xi))  
    %
    % stencil        -- Stencil to use for finite-difference derivatives:
    %                   3,5 or 7. Default: 5
    % quadrature     -- Quadrature to use for integration on the grid(s):
    %                   'simpson' or 'trapezoid'. Default: 'simpson'
    %
    % %%%%%%%%%%%%%%%%%%%%%%%%%%%
    %   Grid properties: 
    % %%%%%%%%%%%%%%%%%%%%%%%%%%%
    % 
    % A quantity f on the grid can be represented in two ways; on a 2D grid
    % of size [nP,nXi], so that
    %   f = [f(p,xi=-1),...,f(p,xi=1)],
    % (where p denotes all p between p_0=0 and p_nP=pMax), or in vector
    % representation where 
    %   f = [f(pp,xi_1);f(pp,xi_2);...;f(pp,xi_nXi);f(p0)],
    % and pp denotes all p between p_1 and p_nP=pMax (note the special
    % treatment of the point at the origin of the coordinate system). The
    % vector has dimensions [matSize,1].
    % 
    % Below, array sizes are shown in brackets.
    %
    % matSize  -- Number of elements in the grid ((nP-1)*nXi+1). The linear
    %             system solved in NORSE has size [matSize,matSize].
    %
    % %%% p grid %%%
    % p        -- Points in the p grid. [nP,1]
	% gamma    -- Relativistic mass factor (gamma = sqrt(p^2+1)). [nP,1]
    % dp       -- p(2)-p(1). [1,1]    
    % pWeights -- Quadrature weights used for performing integrals over p.
    %             [nP,1]
    % ddp      -- Finite-difference derivative on p grid. [nP,nP]
    % d2dp2    -- Finite-difference second derivative on p grid. [nP,nP]
    % p2D      -- Values of p on the entire 2D grid. [nP,nXi]
    % pBig     -- p2D mapped to a vector. [matSize,1]
    % gammaBig -- gamma on the entire grid. [matSize,1]    
    % idsPMax  -- Indices for the location of the points p=pMax for all xi 
    %             in pBig and other vectors on the same form. [1,nXi]
    %     
    % %%%%%%%%%%%%%%%%%
    %   
    % %%% xi grid %%%
    % xi        -- Points in the xi grid. [nXi,1]
    % xiWeights -- Quadrature weights used for performing integrals over xi.
    %              [nXi,1]
    % ddxi      -- Finite-difference derivative on xi grid. [nXi,nXi]
    % d2dxi2    -- Finite-difference second derivative on xi grid. [nXi,nXi]
    % xi2D      -- Values of xi on the entire 2D grid. [nP,nXi]
    % xiBig     -- xi2D mapped to a vector. [matSize,1]
    % xi0Id     -- Index for the location of xi=0 in xi. [1,1]
    %    
    % %%%%%%%%%%%%%%%%%%
    %           
    % %%% p_para, p_perp space %%%
    % pPara2D   -- The value of p_parallel = p*xi on the 2D grid. [nP,nXi]
    % pPerp2D   -- The value of p_perpendicular = p*sqrt(1-xi^2) on the 2D 
    %              grid. [nP,nXi]
    %
    % %%%%%%%%%%%%%%%%%%
    %    
    % %%% Derivative and integral operators %%%
    % 
    % The following matrices represent finite-difference derivatives on 
    % the entire grid (in vector representation). [matSize,matSize]
    % ddpMat     
    % ddxiMat    
    % d2dp2Mat   
    % d2dxi2Mat  
    % d2dpdxiMat 
    %
    % The following vectors represent quadrature weights for performing 
    % integrals over a vector f on the 2D grid. [matsize,1]
    %
    % intdp      -- 4*pi*int_0^pMax p^2 f dp    
    % intdpdxi   -- 2*pi*int_-1^1 int_0^pMax p^2 f dp dxi 
    %
    % %%%%%%%%%%%%%%%%%%%%%%%%%%%
    %   Useful methods: 
    % %%%%%%%%%%%%%%%%%%%%%%%%%%%
    % 
    % InitializeGrid() -- Builds the grid and all the associated quantities
    %                     above based on the settings specified in the
    %                     object properties.
    %
    % Visualize()      -- Plots the grid points and their spacing. 
    %
    % v = MapGridToBigVector(f2D) -- Maps a quantity defined on the 2D grid
    %                                into vector form.
    %
    % f2D = MapBigVectorToGrid(v) -- Maps a quantity on vector form onto
    %                                the 2D grid. It is often easier to
    %                                acces the desired points in the 2D
    %                                representation.
    %
    % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %%% Settings %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    properties 
        nP
        nXi
        pMax
        pGridMode
        xiGridMode
        pGridParameter = 0.2 
        pStepParams
        xiGraDient
        stencil = 5;
        quadrature = 'simpson'; %'simpson' or 'trapezoid'
    end
    
    %%% Grid properties and interface methods %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
    properties 
            
        matSize
        
        %%%%%%%%%%%%%%%%%%
        
        %p grid
        p
        gamma
        dp        
        pWeights
        ddp
        d2dp2
        p2D
        pBig
        gammaBig
        
        
        idsPMax
        
        %%%%%%%%%%%%%%%%%%
        
        %xi grid
        xi
        xiWeights
        ddxi
        d2dxi2
        xi2D
        xiBig
        xi0Id
        
        %%%%%%%%%%%%%%%%%%
             
        %p_para, p_perp space
        pPara2D
        pPerp2D
        gamma2D
        %%%%%%%%%%%%%%%%%%
        
        %Derivative and integral operators
        ddpMat
        ddxiMat
        d2dp2Mat
        d2dxi2Mat
        d2dpdxiMat
        intdp
        intdpdxi         
        
    end
    
    methods 
        function o = Grid_ECEI(varargin)
            % Constructor.
            %
            % Usage:
            %   Grid() -- Initializes an empty object
            %
            % Also create a grid with the specified parameters:
            %   Grid(nP,nXi,pMax,pGridMode,xiGridMode)
            %   Grid(nP,nXi,pMax,pGridMode,xiGridMode,pGridParameter)            
            %                        
            
            %Initialize a struct with grid parameters
            o.pStepParams = struct('stepLocation',5,'bulkSpacing',1e-2,...
                                   'Theta',0.01,'stepSharpness',0.1);
            switch nargin
                case 0
                    %An empty object, nothing to do
                case {5,6,7}
                    o.nP = varargin{1};
                    o.nXi = varargin{2};
                    o.pMax = varargin{3};
                    o.pGridMode = varargin{4};
                    o.xiGridMode = varargin{5};
                    if nargin == 6
                        o.pGridParameter = varargin{6};
                    end
                    if o.xiGridMode ==3
                    o.xiGraDient = varargin{7};
                    end
                    o.InitializeGrid();
                otherwise
                    error('Wrong number of input arguments.');
            end            
        end
        
        function InitializeGrid(o)
            % Function that constructs the grid using the parameters and
            % settings set as object properties, and calculates all the
            % associated quantities.
            %
            % Usage:
            %   InitializeGrid()
            %
            
            nP = o.nP;
            nXi = o.nXi;
            o.matSize = nP*nXi;
           

            %%% Initialize grid in p %%%
            if o.pGridMode
                %A nonuniform grid. 
                
                %Get a uniform grid on [0,1].
                [s,sWeights,dds,d2ds2] = o.CreateUniformGrid(nP,0,1,'p');
                
                %Define the nonuniform mapping. Additional grid mappings
                %can be implemented here as long as they define the
                %quantities p, dpds and d2pds2.
                switch o.pGridMode                 
                    case 1 %A grid with p = s^2 + pGridParameter*s
                        p = s.*s+o.pGridParameter*s;
                        dpds = 2*s+o.pGridParameter;
                        d2pds2 = 2*ones(size(s));                        
                    case 2 %A grid with p = s^3 + pGridParameter*s
                        p = s.^3+o.pGridParameter*s;
                        dpds = 3*s.^2+o.pGridParameter;
                        d2pds2 = 6*s;                        
                    case 3 %A grid with p = s^4 + pGridParameter*s
                        p = s.^4+o.pGridParameter*s;
                        dpds = 4*s.^3+o.pGridParameter;
                        d2pds2 = 12*s.^2;                        
                    case 4 %A grid with a step in spacing, giving a dense 
                           %grid at low p and a sparse grid at high p                        
                        [p,dpds,d2pds2] = o.DefineStepMapping(s);                              
                    otherwise
                        error('Invalid mode for the p grid.')
                end
                
                %Remap derivatives and quadrature weights
                ddp = spdiags(1./dpds,0,nP,nP)*dds;
                d2dp2 = -spdiags(d2pds2 ./ (dpds.^3),0,nP,nP) * dds ...
                      + spdiags((1./dpds).^2,0,nP,nP)*d2ds2;
                pWeights = dpds .* sWeights;
                        
                %Rescale to get the desired pMax
                scaleFactor = o.pMax/p(end);
                o.p = scaleFactor*p;
                o.ddp = ddp / scaleFactor;
                o.d2dp2 = d2dp2 / (scaleFactor*scaleFactor);
                o.pWeights = pWeights*scaleFactor;
                o.dp = p(2)-p(1);                
            else
                %A uniform grid
                [o.p,o.pWeights,o.ddp,o.d2dp2] = ...
                                        o.CreateUniformGrid(nP,0,o.pMax,'p');
                o.dp = o.p(2)-o.p(1);                      
            end        

            %%% Initialize grid in xi %%%
            if o.xiGridMode
                %A nonuniform grid.
                %Additional grid mappings can be implemented here as long 
                %as they define the quantities needed for the remapping below.
                switch o.xiGridMode
                    case 1 
                        %Use a sigmoid -- denser grid close to xi=1 (and to
                        %a lesser extent xi=-1). Specify the grid shape
                        %wanted, then iterate to find the exact parameters
                        %that give a grid point at xi=0, which we need for
                        %the boundary conditions on p.
                        
%                         c=2.0011; d=16; h=1.001; 
                          c=2.0001; d=16; h=1.12; 
                                        %c, which should be >h+1, controls 
                                        %the amount of nonlinearity
                        [c,h] = o.FindOptimalSigmoidMapping(c,d,h,nXi);
                        
                        %Create a uniform grid
                        lowerSBound = log((h-1)/(c-h+1))/d;
                        upperSBound = log((h+1)/(c-h-1))/d;
                        [s,sWeights,dds,d2ds2] = o.CreateUniformGrid(nXi,...
                                                    lowerSBound,upperSBound,'xi');
                                                
                        %Define the mapping                        
                        o.xi = c./(1+exp(-d*s))-h ;
                        
                        %Find (and fix) the 0 point
                        [~,o.xi0Id] = min(abs(o.xi));
                        
                        if o.xi(o.xi0Id)==0
                        o.xi(o.xi0Id) = 1e-4;
                        end
                        o.xi(1)=-1;
                        o.xi(end)=1;
                        

                        %Derivatives of the mapping
                        dxids = c*d*exp(d*s)./(1+exp(d*s)).^2; 
                        d2xids2 = c*d*d*exp(d*s).*(1-exp(d*s))./(1+exp(d*s)).^3;        
                    case 2 
                        %Uniform grid in theta = arccos(xi). Improves the
                        %resolution close to xi=\pm 1. The mapping cannot
                        %be exactly uniform to avoid a vanishing derivative
                        %at the endpoints.
                        
                        c = 963/610; %Almost pi/2, but not quite, to avoid div by 0
                        almostOne = 0.995;
                        almostZero = 1e-3;
                        
                        %Get a unform grid
                        [s,sWeights,dds,d2ds2] = o.CreateUniformGrid(nXi,...
                                                      -almostOne,almostOne,'xi');
                                                  
                        %Define the mapping and fix the 0 point
                        o.xi = sin(c*s);
                        o.xi0Id = find(o.xi==0,1);                
                        o.xi(o.xi0Id) =  o.xi(o.xi0Id-1)/2;

                        %Derivatives
                        dxids = c*cos(c*s);
                        dxids(1) = almostZero;
                        dxids(end) = almostZero;
                        d2xids2 = -c^2*sin(c*s); 
                        d2xids2(o.xi0Id) = almostZero;
                    case 3
                        %Hyperbolic tangent function in xi = tanh(h*s). Improves the
                        %resolution close to xi=\pm 1.
                      [s,sWeights,dds,d2ds2] = o.CreateUniformGrid(o.nXi,...
                                                      -1,1,'xi');
                      xi = tanh(o.xiGraDient*s); 
                       %Rescale to get the desired pMax
                       scaleFactor = 1/xi(end); 
                       o.xi=xi*scaleFactor;
                       dxids=o.xiGraDient*cosh(o.xiGraDient*s).^(-2)*scaleFactor;
                       d2xids2=-2*o.xiGraDient^2*cosh(o.xiGraDient*s).^(-3).*scaleFactor.*sinh(o.xiGraDient*s);
                        
                    otherwise
                        error('Invalid mode for the xi grid.')
                end
                
                %Remap
                o.ddxi = spdiags(1./dxids,0,nXi,nXi)*dds;
                o.d2dxi2 = -spdiags(d2xids2 ./ (dxids.^3),0,nXi,nXi) ...
                         * dds + spdiags((1./dxids).^2,0,nXi,nXi)*d2ds2;        
                o.xiWeights = dxids .* sWeights;                             
            else
                %A uniform grid
                [o.xi,o.xiWeights,o.ddxi,o.d2dxi2] = o.CreateUniformGrid(...
                                                                  nXi,-1,1,'xi');      
                %Find the 0 point.
                o.xi0Id = find(o.xi==0,1);                
            end            
%             if isempty(o.xi0Id)
%                 error('The xi grid must have a point at \xi=0. Choose an odd value for nXi.');
%             end                
            
            %%% Calculate aggregate quantities
            o.gamma = sqrt(1+o.p.*o.p);
            
            [o.xi2D,o.p2D] = meshgrid(o.xi,o.p); % xi_i varies on rows, 
                                                 % p_i varies in columns
            o.pBig = o.MapGridToBigVector(o.p2D); 
            o.xiBig = o.MapGridToBigVector(o.xi2D);
            o.gammaBig = sqrt(1+o.pBig.*o.pBig);
            o.pPara2D = o.p2D.*o.xi2D;
            o.pPerp2D = o.p2D.*sqrt(1-o.xi2D.^2); 
            o.gamma2D = sqrt(o.p2D.^2+1);       
            o.ConstructBigDifferentiationMatrices();
        end
        
        function v = MapGridToBigVector(o,f2D)
            % Reshapes a function given on the 2D grid to a vector
            % representation. 
            v = reshape(f2D,o.matSize,1); %All points p>0
               
        end

        function f2D = MapBigVectorToGrid(o,v)
            % Reshapes a function in vector representation onto the 2D grid.
            %
            % Usage:
            %   f2D = MapBigVectorToGrid(fV)
            f2D = reshape(v,o.nP,o.nXi); %All points p>0          
        end
        
        function Visualize(o)
            % Plots the distribution of the grid points in (p,xi) and
            % (p_para,p_perp) space, as well as the grid-point spacing.
            %
            % Usage:
            %   Visualize()
            
            %Figure of spatial distribution of grid points
            hF = figure();
            clf;
            hF.Name = 'Spatial distribution of grid points';
            
            subplot(2,1,1) % (p,xi)-space
            scatter(o.xi2D(:),o.p2D(:),5,'k','filled');
            xlabel('$\xi$','Interpreter','latex')
            ylabel('$p$','Interpreter','latex')
            title('\bf($p$,$\xi$)-space','Interpreter','latex');
                        
            subplot(2,1,2) %(p_para,p_perp)-space
            scatter(o.pPara2D(:),o.pPerp2D(:),5,'k','filled');
            xlabel('$p_{||}$','Interpreter','latex')
            ylabel('$p_{\perp}$','Interpreter','latex')                        
            title('\bf($p_{||}$, $p_{\perp}$)-space','Interpreter','latex');
            axis equal
            
            
            %Figure of grid-point spacing
            hF = figure();
            clf;
            hF.Name = 'Grid-point spacing';
            
            subplot(2,1,1);
            plot(o.p,'k')
            xlabel('Grid point','Interpreter','latex')
            ylabel('$p$','Interpreter','latex')
            
            subplot(2,1,2);
            plot(o.xi,'k')
            xlabel('Grid point','Interpreter','latex')
            ylabel('$\xi$','Interpreter','latex')
        end
    end

    %%% Internal methods %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    methods 
        function [x,w,ddx,d2dx2] = CreateUniformGrid(o,n,xMin,xMax,type)
            % Generates a uniform grid, together with quadrature weights
            % and the first and second finite-diffrences. The quadrature
            % weights can be chosen according to either the trapezoid rule
            % or a composite Simpson's rule (which should be more
            % accurate). Stencils with 3,5 or 7 points (giving 2nd, 4th or
            % 6th order finite differences) are available. Central
            % differences are used, except near the endpoints where a
            % gradual transition to one-sided differences is used to
            % maintain the discretization order.
            %type:'p' or 'xi';
            % Usage:
            %   [x,weights,ddx,d2dx2] = CreateUniformGrid(nPoints,xMin,xMax)
            %
            % Dimensions:
            %   x, weights: [nPoints,1]            
            %   ddx, d2dx2: [nPoints,nPoints]
            
            % Validate input:
            if ~isfinite(n)
                error('n of points must be finite')
            end
            if ~isfinite(xMin)
                error('xMin must be finite')
            end
            if ~isfinite(xMax)
                error('xMax must be finite')
            end
            if numel(n) ~= 1
                error('n must be a single integer')
            end
            if numel(xMin) ~= 1
                error('xMin must be a single number')
            end
            if numel(xMax) ~= 1
                error('xMax must be a single number')
            end    
            if xMax < xMin
                error('xMax must be larger than xMin.')
            end
            if xMax == xMin
                error('xMax cannot equal xMin.')
            end
            if n<o.stencil
                error('n must be at least the number of points of the stencil.')
            end
            if n ~= round(n)
                error('n must be an integer.')
            end

            % Create grid
            if strcmp(type,'p')
            dx=(xMax-xMin)/(n-1);
            x0 = linspace(xMin,xMax,n)';x=x0+x0(2);
            x=x0+x0(2);
            elseif strcmp(type,'xi')
             x= linspace(xMin,xMax,n)';
            end
            dx  = x(2)-x(1);
            dx2 = dx*dx;

            % Create integration weights
            switch lower(o.quadrature)
                case 'trapezoid'
                    w      = ones(size(x));    
                    w(1)   = 0.5;
                    w(end) = 0.5;    
                    w      = w*dx;
                case 'simpson'
                    %Use a composite Simpson's rule. Use simpler rules in
                    %the (unlikely) case that we have fewer than 8 points.
                    switch n            
                        case 3
                            w = [1,4,1]'/6;     %Simpson's rule
                        case 4
                            w = 3/8*[1,3,3,1]'; %Simpson's 3/8 rule
                        case 5
                            w = [1,4,2,4,1]'/3; %Composite Simpson's rule
                        case 6
                            w = 5/288*[19,75,50,50,75,19]'; %6-point Newton-Coates rule
                        case 7
                            w = [1,4,2,4,2,4,1]'/3; %Composite Simpson's rule
                        otherwise
                            w = 1/48*[17,59,43,49,48*ones(1,(n-8)),49,43,59,17]';
                    end            
                    w = w*dx;            
                otherwise
                    error('Invalid quadrature.');
            end

            % Create differentiation matrices
            switch o.stencil
                case 3  
                    %%% ddx
                    % Set the interior points of the differentiation matrix
                    % using a central finite difference:                    
                    ddx = sparse( (  diag(ones(n-1,1),1) ...
                                   - diag(ones(n-1,1),-1) )...
                                 /(2*dx) );

                    %Handle endpoints (one-sided differences):
                    ddx(1,1) = -1.5/dx;
                    ddx(1,2) = 2/dx;
                    ddx(1,3) = -0.5/dx;

                    ddx(end,end)   = 1.5/dx;
                    ddx(end,end-1) = -2/dx;
                    ddx(end,end-2) = 0.5/dx;


                    %%% d2dx2
                    %Interior points
                    d2dx2 = sparse( ( - 2*diag(ones(n,1),0) ...
                                      + diag(ones(n-1,1),1)...
                                      + diag(ones(n-1,1),-1) )...
                                    /dx2 );

                    %Endpoints
                    d2dx2(1,1) = 1/dx2;
                    d2dx2(1,2) = -2/dx2;
                    d2dx2(1,3) = 1/dx2;

                    d2dx2(end,end)   = 1/dx2;
                    d2dx2(end,end-1) = -2/dx2;
                    d2dx2(end,end-2) = 1/dx2;            
                case 5  
                    %%% ddx
                    %Interior points
                    v1  = ones(n,1);
                    ddx = (  - spdiags((1/6)*v1,2,n,n)...
                             + spdiags((4/3)*v1,1,n,n)...
                             - spdiags((4/3)*v1,-1,n,n)... 
                             + spdiags((1/6)*v1,-2,n,n) )...
                           /(2*dx);

                    %Endpoints
                    ddx(1,1) = -25/(12*dx);
                    ddx(1,2) = 4/(dx);
                    ddx(1,3) = -3/dx;
                    ddx(1,4) = 4/(3*dx);
                    ddx(1,5) = -1/(4*dx);

                    ddx(2,1) = -1/(4*dx);
                    ddx(2,2) = -5/(6*dx);
                    ddx(2,3) = 3/(2*dx);
                    ddx(2,4) = -1/(2*dx);
                    ddx(2,5) = 1/(12*dx);

                    ddx(end,end)   = 25/(12*dx);
                    ddx(end,end-1) = -4/(dx);
                    ddx(end,end-2) = 3/dx;
                    ddx(end,end-3) = -4/(3*dx);
                    ddx(end,end-4) = 1/(4*dx);

                    ddx(end-1,end)   = 1/(4*dx);
                    ddx(end-1,end-1) = 5/(6*dx);
                    ddx(end-1,end-2) = -3/(2*dx);
                    ddx(end-1,end-3) = 1/(2*dx);
                    ddx(end-1,end-4) = -1/(12*dx);


                    %%% d2dx2
                    %Interior points
                    d2dx2 = (   - spdiags((1/12)*v1,2,n,n)...
                                + spdiags((4/3)*v1,1,n,n)...
                                + spdiags((-5/2)*v1,0,n,n)...
                                + spdiags((4/3)*v1,-1,n,n) ...
                                - spdiags((1/12)*v1,-2,n,n) )...
                              /(dx2);

                    %Endpoints
                    d2dx2(1,1) = 35/(12*dx2);
                    d2dx2(1,2) = -26/(3*dx2);
                    d2dx2(1,3) = 19/(2*dx2);
                    d2dx2(1,4) = -14/(3*dx2);
                    d2dx2(1,5) = 11/(12*dx2);

                    d2dx2(2,1) = 11/(12*dx2);
                    d2dx2(2,2) = -5/(3*dx2);
                    d2dx2(2,3) = 1/(2*dx2);
                    d2dx2(2,4) = 1/(3*dx2);
                    d2dx2(2,5) = -1/(12*dx2);

                    d2dx2(end,end)   = 35/(12*dx2);
                    d2dx2(end,end-1) = -26/(3*dx2);
                    d2dx2(end,end-2) = 19/(2*dx2);
                    d2dx2(end,end-3) = -14/(3*dx2);
                    d2dx2(end,end-4) = 11/(12*dx2);

                    d2dx2(end-1,end-0) = 11/(12*dx2);
                    d2dx2(end-1,end-1) = -5/(3*dx2);
                    d2dx2(end-1,end-2) = 1/(2*dx2);
                    d2dx2(end-1,end-3) = 1/(3*dx2);
                    d2dx2(end-1,end-4) = -1/(12*dx2);            
                case 7  
                    v1 = ones(n,1);

                    %%% ddx
                    %Interior points
                    ddx = (    spdiags((1/60)*v1,3,n,n)...
                             + spdiags((-3/20)*v1,2,n,n) ...
                             + spdiags((3/4)*v1,1,n,n)...
                             + spdiags((-3/4)*v1,-1,n,n)...
                             + spdiags((3/20)*v1,-2,n,n)...
                             + spdiags((-1/60)*v1,-3,n,n) )...
                           /dx;


                    %Endpoints
                    ddx(1,1) = -49/(20*dx);
                    ddx(1,2) = 6/dx;
                    ddx(1,3) = -15/(2*dx);
                    ddx(1,4) = 20/(3*dx);
                    ddx(1,5) = -15/(4*dx);
                    ddx(1,6) = 6/(5*dx);
                    ddx(1,7) = -1/(6*dx);

                    ddx(2,1) = -1/(6*dx);
                    ddx(2,2) = -77/(60*dx);
                    ddx(2,3) = 5/(2*dx);
                    ddx(2,4) = -5/(3*dx);
                    ddx(2,5) = 5/(6*dx);
                    ddx(2,6) = -1/(4*dx);
                    ddx(2,7) = 1/(30*dx);

                    ddx(3,1) = 1/(30*dx);
                    ddx(3,2) = -2/(5*dx);
                    ddx(3,3) = -7/(12*dx);
                    ddx(3,4) = 4/(3*dx);
                    ddx(3,5) = -1/(2*dx);
                    ddx(3,6) = 2/(15*dx);
                    ddx(3,7) = -1/(60*dx);

                    

                    ddx(end,end)   = 49/(20*dx);
                    ddx(end,end-1) = -6/dx;
                    ddx(end,end-2) = 15/(2*dx);
                    ddx(end,end-3) = -20/(3*dx);
                    ddx(end,end-4) = 15/(4*dx);
                    ddx(end,end-5) = -6/(5*dx);
                    ddx(end,end-6) = 1/(6*dx);

                    ddx(end-1,end)   = 1/(6*dx);
                    ddx(end-1,end-1) = 77/(60*dx);
                    ddx(end-1,end-2) = -5/(2*dx);
                    ddx(end-1,end-3) = 5/(3*dx);
                    ddx(end-1,end-4) = -5/(6*dx);
                    ddx(end-1,end-5) = 1/(4*dx);
                    ddx(end-1,end-6) = -1/(30*dx);

                    ddx(end-2,end)   = -1/(30*dx);
                    ddx(end-2,end-1) = 2/(5*dx);
                    ddx(end-2,end-2) = 7/(12*dx);
                    ddx(end-2,end-3) = -4/(3*dx);
                    ddx(end-2,end-4) = 1/(2*dx);
                    ddx(end-2,end-5) = -2/(15*dx);
                    ddx(end-2,end-6) = 1/(60*dx);





                    %%% d2dx2
                    %Interior points
                    d2dx2 = (     spdiags((1/90)*v1,3,n,n)...
                                + spdiags((-3/20)*v1,2,n,n)...
                                + spdiags((3/2)*v1,1,n,n)...
                                + spdiags((-49/18)*v1,0,n,n)...
                                + spdiags((3/2)*v1,-1,n,n)...
                                + spdiags((-3/20)*v1,-2,n,n)...
                                + spdiags((1/90)*v1,-3,n,n)  )...
                             /dx2;
                                                                   
                                                                       
                    %Endpoints     
                    d2dx2(1,1) = 203/(45*dx2);
                    d2dx2(1,2) = -87/(5*dx2);
                    d2dx2(1,3) = 117/(4*dx2);
                    d2dx2(1,4) = -254/(9*dx2);
                    d2dx2(1,5) = 33/(2*dx2);
                    d2dx2(1,6) = -27/(5*dx2);
                    d2dx2(1,7) = 137/(180*dx2);
                    
                    d2dx2(2,1) = 137/(180*dx2);
                    d2dx2(2,2) = -49/(60*dx2);
                    d2dx2(2,3) = -17/(12*dx2);
                    d2dx2(2,4) = 47/(18*dx2);
                    d2dx2(2,5) = -19/(12*dx2);
                    d2dx2(2,6) = 31/(60*dx2);
                    d2dx2(2,7) = -13/(180*dx2);

                    d2dx2(3,1) = -13/(180*dx2);
                    d2dx2(3,2) = 19/(15*dx2);
                    d2dx2(3,3) = -7/(3*dx2);
                    d2dx2(3,4) = 10/(9*dx2);
                    d2dx2(3,5) = 1/(12*dx2);
                    d2dx2(3,6) = -1/(15*dx2);
                    d2dx2(3,7) = 1/(90*dx2);



                    d2dx2(end,end)   = 203/(45*dx2);
                    d2dx2(end,end-1) = -87/(5*dx2);
                    d2dx2(end,end-2) = 117/(4*dx2);
                    d2dx2(end,end-3) = -254/(9*dx2);
                    d2dx2(end,end-4) = 33/(2*dx2);
                    d2dx2(end,end-5) = -27/(5*dx2);
                    d2dx2(end,end-6) = 137/(180*dx2);

                    d2dx2(end-1,end)   = 137/(180*dx2);
                    d2dx2(end-1,end-1) = -49/(60*dx2);
                    d2dx2(end-1,end-2) = -17/(12*dx2);
                    d2dx2(end-1,end-3) = 47/(18*dx2);
                    d2dx2(end-1,end-4) = -19/(12*dx2);
                    d2dx2(end-1,end-5) = 31/(60*dx2);
                    d2dx2(end-1,end-6) = -13/(180*dx2);

                    d2dx2(end-2,end)   = -13/(180*dx2);
                    d2dx2(end-2,end-1) = 19/(15*dx2);
                    d2dx2(end-2,end-2) = -7/(3*dx2);
                    d2dx2(end-2,end-3) = 10/(9*dx2);
                    d2dx2(end-2,end-4) = 1/(12*dx2);
                    d2dx2(end-2,end-5) = -1/(15*dx2);
                    d2dx2(end-2,end-6) = 1/(90*dx2);            
                otherwise
                    error('Invalid stencil.');
            end    
        end 
        
        function [p,dpds,d2pds2] = DefineStepMapping(o,s)
            % Defines a non-uniform grid mapping with a tanh step in
            % spacing. With this mapping, the spacing is kept small for low
            % p to accurately resolve the bulk, but can be much larger for
            % large p to reduce the computational expense. 
            %
            % The grid spacing has the form
            %   dpds = a*tanh((s-sp)/kappa) + b,
            % which can be integrated to get the expression for p(s). The
            % exact shape of the resulting grid is governed by the settings
            % in the struct pStepParams. kappa is given by the struct field
            % stepSharpness, whereas sp is calculated from a combination of
            % stepSharpness, stepLocation, bulkSpacing and Theta. a and b
            % are determined by solving a system of constraint equations,
            % given kappa, sp, s, nP, pMax and stepLocation.
            %
            % Usage:
            %   [p,dpds,d2pds2] = DefineStepMapping(s)
            %
            % s should be a uniform grid on [0,1].
            
            % Obtain settings from the pStepParams struct                        
            yToP = sqrt(2*o.pStepParams.Theta); %Conversion between y and p
            pStep = yToP*o.pStepParams.stepLocation; 
            deltaP0 = yToP*o.pStepParams.bulkSpacing;
            kappa = o.pStepParams.stepSharpness; 

            % Determine derived quantities
            maxFractionOfPoints = 0.6; %to use for the bulk
            N0 = round(min(pStep/deltaP0,maxFractionOfPoints*o.nP)); %points in bulk
            Np = round(N0 + 2.5*kappa*o.nP); %points in bulk and step regions
            sp = s(Np);                        
            sN0 = s(N0);

            if sN0 == 0
                error('Unsuitable grid parameters.');
            end

            %%% Solve for suitable grid parameters a and b 
            % These expressions follow from the constraints 
            %   p(s=1) = pMax
            %   p(N0)  = pStep
            K11 = kappa * ( log(cosh((1-sp)/kappa)) - log(cosh(sp/kappa)) );
            K12 = 1;
            K21 = kappa * ( log(cosh((sN0-sp)/kappa)) - log(cosh(sp/kappa)) );
            K22 = sN0;
            K = [K11,K12;K21,K22];
            if any(isinf(K(:))) || any(isnan(K(:)))
                error('Unsuitable grid parameters.');
            end

            ab = K\[o.pMax;pStep];
            a = ab(1);
            b = ab(2);                        
            if b<a
                %This is required to guarantee positivity of dpds (tanh ->
                %-1 as the argument -> 0)
                b=a+eps;
            end

            %%% Define the grid                                                
            p = a*kappa*( log(cosh((s-sp)/kappa)) - log(cosh((sp)/kappa)) ) + b*s;
            dpds = a*tanh((s-sp)/kappa) + b;
            d2pds2 = (a/kappa)./cosh((s-sp)/kappa).^2;

            if (p(end)-p(end-1)) < (p(2)-p(1))
                error('The grid will not have the desired properties for the chosen settings. Decrease nP or bulkSpacing!' );
            end
            if any(dpds<=0)
                error('The grid-point slope is not strictly positive! The p grid mapping parameters are invalid.');
            end                   
        end
        
        function ConstructBigDifferentiationMatrices(o)
            % Construct differentiation matrices and quadrature weights for
            % the whole grid in vector form.
            %
            % Usage:
            %   ConstructBigDifferentiationMatrices()
            
            %Differentiation matrices
            o.ddpMat = o.BuildBigMatrix(speye(o.nXi),o.ddp)    ;
            o.ddxiMat = o.BuildBigMatrix(o.ddxi,speye(o.nP))    ;
            o.d2dp2Mat = o.BuildBigMatrix(speye(o.nXi),o.d2dp2) ;
            o.d2dxi2Mat = o.BuildBigMatrix(o.d2dxi2,speye(o.nP));
            o.d2dpdxiMat = o.BuildBigMatrix(o.ddxi,o.ddp);    
            
            %Integrals over the grid (including Jacobian)   
            o.intdp = o.BuildBigVector(ones(size(o.xi))',4*pi*o.p'.^2.*o.pWeights'); 
            o.intdpdxi = o.BuildBigVector(o.xiWeights',2*pi*o.p'.^2.*o.pWeights');
        end 
                        
        function m = BuildBigMatrix(O,fOfXi,fOfP)
            % Construct a matrix that can be used for operating on a
            % function on the grid (in its vector representation). Gives a
            % vector when multiplying a function on the grid.
            %
            % Usage:
            %   m = BuildBigMatrix(fOfXi,fOfP,doP0Dependence)
            % fOfXi describes the xi dependence and is a matrix with
            % dimenstion [nXi,nXi]. Similarly, fOfP describes the p
            % dependence and is [nP,nP]. The final argument determines
            % whether to perform the operations necessary to get the
            % correct beahvior at the special point p=0. If there is no
            % p dependence (i.e. fOfP = speye(nP,nP)), 0 can be passed here.                       
            m = kron(fOfXi,fOfP); 
        end

        function v = BuildBigVector(o,fOfXi,fOfP)
            % Construct a vector that describes a function on the grid (in
            % its vector representation). Gives a scalar when multiplied by
            % a function on the grid.
            %
            % Usage:
            %   v = BuildBigVector(fOfXi,fOfP)
            %
            % fOfXi describes the xi dependence and has dimension [1,nXi].
            % Similarly, fOfP describes the p dependence and is [1,nP].            
            v = kron(fOfXi,fOfP); 
        end 
        
        function GetSize(o) 
            % Calculates the size in memory of the GRID object by looping
            % through the fields and summing up the variable sizes, and
            % prints it to the console. 
            %
            % Usage: 
            %   GetSize()
            
            props = properties(o); 
            totSize = 0; 
            for i = 1:length(props) 
                currentProperty = getfield(o, char(props(i))); 
                s = whos('currentProperty'); 
                totSize = totSize + s.bytes;	
            end
            fprintf(1, 'Grid: %.1f MB\n', totSize/(1024*1024));	
        end
    end
    
    methods (Static) 
        function [c,h] = FindOptimalSigmoidMapping(c,d,h,nXi)
            %Finds a grid mapping with a point at xi=0 and endpoints at
            %xi=-1,1, given an initial guess for the parameters c,d and h
            %in the sigmoid mapping for the xi grid. Returns the
            %corresponding values for c and h.
            %
            % Usage:
            %   [c,h] = FindOptimalGridMapping(c,d,h,nXi)
            
            %Create a uniform grid with endpoints appropriate for the
            %sigmoid mapping
            lowerSBound = log((h-1)/(c-h+1))/d;
            upperSBound = log((h+1)/(c-h-1))/d;            
            s = linspace(lowerSBound,upperSBound,nXi);
            
            %Find the grid point closest to 0. This is the point in the
            %grid we will use for the optimization of c and h.
            [~,id] = min(abs(c./(1+exp(-d*s))-h)); 

            fToMinimize = @(v) Grid_ECEI.Residual(v,d,nXi,id);
            op = optimset('TolFun',1e-14); 
            
            v = fminsearch(fToMinimize,[c,h],op);
            
            c = v(1);
            h = v(2);
        end
        
        function r = Residual(v,d,nXi,id)
            %Returns the residual for the optimization to find a sigmoid
            %grid mapping with a point at xi=0.
            %
            % Usage:
            %   r = Residual(v,d,nXi,id)
            %
            % r is the distance of the closest grid point id (established
            % in FindOptimalSigmoidMapping) to 0. v = [c,h], with c,d and
            % h parameters in the sigmoid mapping.
            
            c = v(1); 
            h = v(2);
            
            %Generate a uniform grid with the given c and h values
            lowerSBound = log((h-1)/(c-h+1))/d;
            upperSBound = log((h+1)/(c-h-1))/d;            
            s = linspace(lowerSBound,upperSBound,nXi);
            
            %Do the sigmoid mapping. The residual is the distance to 0 of
            %the closest point.
            r = c./(1+exp(-d*s(id)))-h;
            if isreal(r)
                r = abs(r);
            else
                r=Inf;
            end
        end
    end      
end
