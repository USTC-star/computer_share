classdef CalculateLegendefficient4<handle
    properties
        nL
        nA
        nXi
        gradient
        grid
        Qnm
        Unm
        Rnm
        Onm
        Mnm
        Cnm1
        Cnm2
        Cnm3
        Dnm
        Anm_xixi_11
        Anm_xixi_12
        Anm_xixi_21
        Anm_xixi_22
        Pnmcheck
        
    end
    methods
        function o=CalculateLegendefficient4(nL,nA,nXi,gradient)
            o.nL=nL;%Legende number of f(p,xi)
            o.nA=nA;%Legende number of ADE coefficient
            o.nXi=nXi;
            grid=Grid_ECEI(o.nA,o.nXi,1,1,3,0.2,gradient);
            o.grid = grid;
            xi=grid.xi;ddxi=grid.ddxi;d2dxi2=grid.d2dxi2;
            C1=zeros(1,nL.^2);Qnm=zeros(nL,nL);
            C2=zeros(1,nL.^2);Unm=zeros(nL,nL);
            C3=zeros(1,nL.^2);
            C4=zeros(1,nL.^2);Cnm3=zeros(nL,nL);
            C5=zeros(1,nL.^2);Onm=zeros(nL,nL);
            C6=zeros(1,nL.^2);Mnm=zeros(nL,nL);
            Dnm=zeros(nL,nL);
            Rnm=zeros(nL,nL);
            
            parfor k=1:nL^2
                mk=ceil(k/nL);
                nk=k-(mk-1)*nL;
                m=mk-1;
                n=nk-1;
                if m==0
                    fm=1 ;
                else
                    fm=o.Legendre_test_num(m,xi)';
                end
                if n==0
                    fn=1 ;
                    diff_fn=realmin;
                    diff2_fn=realmin;
                else
                    
                    fn=o.Legendre_test_num(n,xi)';
                    %         diff_fn=dss004(xi(1),xi(end),length(xi),fn);
                    %         diff2_fn=dss004(xi(1),xi(end),length(xi),diff_fn);
                    %                     diff_fn=dss004_nolinear_new(xi,fn,1,linear_t,gradient);
                    %                     diff2_fn=dss004_nolinear_new(xi,diff_fn,1,linear_t,gradient);
                    diff_fn=ddxi*fn;
                    diff2_fn=d2dxi2*fn;
                end
                g1=(fm.*xi.*fn);            %Q
                g2=(fm.*(1-xi.^2).*diff_fn);%U
                gc3=(fm.*(1-xi.^2).*diff2_fn-2*xi.*fm.*diff_fn);%Cnm3
                g3=(fm.*(1-xi.^2).*fn)  ;   %R
                g4=(fm.*(1-3*xi.^2).*fn);   %O
                g5=(fm.*xi.*(1-xi.^2).*diff_fn);%M
                g6=(fm.*abs(xi).*fn);
                F1=trapz(xi,g1)*(2*m+1)/2;
                F2=trapz(xi,g2)*(2*m+1)/2;
                F3=trapz(xi,g3)*(2*m+1)/2;
                Fc3=trapz(xi,gc3)*(2*m+1)/2;
                F4=trapz(xi,g4)*(2*m+1)/2;
                F5=trapz(xi,g5)*(2*m+1)/2;
                F6=trapz(xi,g6)*(2*m+1)/2;
                C1(k)=F1;
                C2(k)=F2;
                C3(k)=F3;
                Cc3(k)=Fc3;
                C4(k)=F4;
                C5(k)=F5;
                C6(k)=F6;
                
            end
            for k=1:nL^2
                m=ceil(k/nL) ;
                n=k-(m-1)*nL ;
                Qnm(n,m)=C1(k);
                Unm(n,m)=C2(k);
                Cnm3(n,m)=Cc3(k);
                Rnm(n,m)=C3(k);
                Onm(n,m)=C4(k);
                Mnm(n,m)=C5(k);
                Dnm(n,m)=C6(k);
            end
            tol=1e-4;
            Qnm(abs(Qnm)<tol)=0;
            Unm(abs(Unm)<tol)=0;
            Rnm(abs(Rnm)<tol)=0;
            Onm(abs(Onm)<tol)=0;
            Mnm(abs(Mnm)<tol)=0;
            Cnm3(abs(Cnm3)<tol)=0;
            Dnm(abs(Dnm)<tol)=0  ;
            Cnm1=eye(nL)         ;
            %%
            Qnms=zeros(o.nL+1);
            Unms=zeros(o.nL+1);
            
            for m=1:o.nL
                Qnms(m+1,m)=(m)./(2*m+1);
                Qnms(m,m+1)=(m)./(2*m-1);
                Unms(m+1,m)=(m+1)*(m)/(2*m+1);
                Unms(m,m+1)=-(m-1)*m/(2*m-1);
                Cnm3(m,m)  =-(m-1)*m;
            end
            % Qnm_t=Qnms(1:o.nL, 1:o.nL)          ;
            % Unm_t=Unms(1:o.nL, 1:o.nL)          ;
            %             Qnm=Qnms(1:o.nL, 1:o.nL);
            %             Unm=Unms(1:o.nL, 1:o.nL);
            
            %%
            %             o=Calculate_Cade_coefficient(o)
            o.Qnm=Qnm;
            o.Unm=Unm;
            %             o.Unm=o.Anm_xixi_21{14};
            o.Rnm=Rnm;
            %             o.Rnm=o.Anm_xixi_12{2} ;
            o.Onm=Onm;
            %             o.Onm=o.Anm_xixi_12{2} ;
            o.Mnm=Mnm;
            %             o.Mnm=o.Anm_xixi_11{1} ;
            o.Cnm1=Cnm1;
            o.Cnm2=Cnm1;
            o.Cnm3=Cnm3;
            o.Dnm=Dnm  ;
        end
        %计算ADE勒让德系数，现设置一个计算程序，然后利用这个程序分别对每一项求解系数
        function o=Calculate_Cade_coefficient(o)
            
            grid=o.grid;
            nL=o.nL;
            Pls=o.LegendrePolynomials(o.nA-1,grid.xi');
            xi2D=kron(ones(o.nA,1),grid.xi');
            xiBig=grid.MapGridToBigVector(xi2D);
            PlsBig=grid.MapGridToBigVector(Pls);
            
            xiWeights=grid.xiWeights';
            xiWeights2D = kron(ones(o.nA,1),xiWeights);
            Cade_xixi_11 = zeros(o.nA,o.nL^2);
            Cade_xixi_12 = zeros(o.nA,o.nL^2);
            Cade_xixi_21 = zeros(o.nA,o.nL^2);
            Cade_xixi_22 = zeros(o.nA,o.nL^2);
            tic
            parfor k=1:nL^2
                disp(k)
                mk=ceil(k/nL);
                nk=k-(mk-1)*nL;
                m=mk-1;
                n=nk-1;
                fm = Legendre_test_num(m,grid.xi');
                fn = Legendre_test_num(n,grid.xi');
                fm2D = kron(ones(o.nA,1),fm);
                fn2D = kron(ones(o.nA,1),fn);
                fms = grid.MapGridToBigVector(fm2D);
                fns = grid.MapGridToBigVector(fn2D);
                Dxixi11 = fms.*xiBig.*(grid.ddxiMat*(PlsBig.*xiBig.*(grid.ddxiMat*fns)))*(2*m+1)/2;
                Dxixi12 = fms.*xiBig.*(grid.ddxiMat*(PlsBig.*(grid.ddxiMat*fns)))*(2*m+1)/2;
                Dxixi21 = fms.*(grid.ddxiMat*(PlsBig.*xiBig.*(grid.ddxiMat*fns)))*(2*m+1)/2;
                Dxixi22 = fms.*(grid.ddxiMat*(PlsBig.*(grid.ddxiMat*fns)))*(2*m+1)/2;
                %                 g1s      = (fms.*PlsBig.*fns)*(2*m+1)/2;
                g1s      = (fms.*xiBig.*(1-xiBig.^2).*(grid.ddxiMat*fns))*(2*m+1)/2;
                Dxixi11_2D = grid.MapBigVectorToGrid(Dxixi11);
                Dxixi12_2D = grid.MapBigVectorToGrid(Dxixi12);
                Dxixi21_2D = grid.MapBigVectorToGrid(Dxixi21);
                Dxixi22_2D = grid.MapBigVectorToGrid(Dxixi22);
                g1s2D      = grid.MapBigVectorToGrid(g1s);
                
                Cade_xixi_11(:,k) = sum(Dxixi11_2D.*xiWeights2D,2);
                Cade_xixi_12(:,k) = sum(Dxixi12_2D.*xiWeights2D,2);
                Cade_xixi_21(:,k) = sum(Dxixi21_2D.*xiWeights2D,2);
                Cade_xixi_22(:,k) = sum(Dxixi22_2D.*xiWeights2D,2);
                
                Plnm(:,k) = sum(g1s2D.*xiWeights2D,2);
            end
            toc
            for k=1:nL^2
                m=ceil(k/nL) ;
                n=k-(m-1)*nL ;
                for jj=1:o.nA
                    Anm_xixi_11_raw{jj}(n,m)=Cade_xixi_11(jj,k);
                    Anm_xixi_12_raw{jj}(n,m)=Cade_xixi_12(jj,k);
                    Anm_xixi_21_raw{jj}(n,m)=Cade_xixi_21(jj,k);
                    Anm_xixi_22_raw{jj}(n,m)=Cade_xixi_22(jj,k);
                    o.Pnmcheck{jj}(n,m)   =Plnm(jj,k);
                end
            end
            
            for jj=1:o.nA
                Anm_xixi_11_raw{jj}(Anm_xixi_11_raw{jj}<1e-1)=0;
                Anm_xixi_12_raw{jj}(Anm_xixi_12_raw{jj}<1e-1)=0;
                Anm_xixi_21_raw{jj}(Anm_xixi_21_raw{jj}<1e-1)=0;
                Anm_xixi_22_raw{jj}(Anm_xixi_22_raw{jj}<1e-1)=0;
            end
            
            
            o.Anm_xixi_11=Anm_xixi_11_raw;
            o.Anm_xixi_21=Anm_xixi_21_raw;
            o.Anm_xixi_12=Anm_xixi_12_raw;
            o.Anm_xixi_22=Anm_xixi_22_raw;
            
            
            
            
            
            
            
        end
    end
    methods (Static)
        function outPls = LegendrePolynomials(l,x)
            % Calculates the legendre polynomials P_i(x) for i=0,1,...,l
            % using Bonnet's recursion formula:
            %   (n+1)*P_{n+1}(x) = (2n+1)*x*P_n(x) - n*P_{n-1}(x),
            % where P_0(x) = 1 and P_1(x) = x.
            %
            % Usage:
            %   pls = LegendrePolynomials(l,x)
            %
            % l is the (highest) mode number and x is the coordinate, which
            % must be a row vector (not a matrix). pls has the structure
            %   [ P_0(x) ]
            %   [ P_1(x) ]
            %   [   ...  ]
            %   [ P_l(x) ]
            %
            
            %Check input
            if ~(isscalar(l) && isnumeric(l) && isreal(l) && l>=0)
                error('Invalid mode number.');
            end
            if size(x,1) > 1
                error('The argument must be presented as a row vector.');
            end
            if any(x<(-1-eps)) || any(x>(1+eps))
                error('The argument is out of the range [-1,1].');
            end
            
            %Initialize the output and include the first two modes.
            outPls(l+1,numel(x)) = 0   ;
            outPls(1,:) = ones(size(x));
            if l>=1
                outPls(2,:) = x;
            end
            
            for n = 1:l-1
                %The index n reflects the n in Bonnet's formula, but the
                %corresponding row in the array is n+1. We start from n=1, since we
                %want to use the formula to compute n+1=2 (which goes on row n+2=3)
                outPls(n+2,:) = (2*n+1)/(n+1) * x.*outPls(n+1,:) ...
                    - n/(n+1) * outPls(n,:);
            end
            
        end
        
        function P=Legendre_test_num(n,x)
            %caculate legendre function %xuxh,20220819           
            P=zeros(length(n),length(x));
            for jj=1:length(n)
                Q=legendre( n(jj),x);
                P(jj,:)=Q(1,:);
            end
        end
        
    end
end
