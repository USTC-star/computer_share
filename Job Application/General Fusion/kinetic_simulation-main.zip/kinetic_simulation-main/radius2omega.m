%writed by xuxh 2022/10/26
function wce=radius2omega(x,B0)
%calculate  cycltron frequency fce[Ghz] from min-radius x[m] and longtitude
%magnetic field B0[T];
Rc=1.85;R=x+Rc ;
wce=28*B0*Rc./R*1e9*2*pi;
end
