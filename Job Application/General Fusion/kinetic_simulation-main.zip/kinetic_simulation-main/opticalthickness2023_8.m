function opticalthickness2023_8(ne0,te0,B0,p,x)
%calculate optical thickness of ece,ne0,Te0 refers to central 
%parameters;ne0[1e19/m^3],Te0[/kev],IT[A]represents longitudinal current
%reference:
%(1)Bornatici, M. "Theory of electron cyclotron absorption of 
%magnetized plasmas." Plasma Physics 24.6 (1982): 629.
%(2)Janicki, C. "Electron temperature measurement from the ECE 
%diagnostics in tokamak plasmas under transient conditions." Nuclear fusion 33.3 (1993): 513.
%Ordinary mode refer to  page 637 ,table 4,Bornatici
%Extraordinary mode refer to page 637 ,table 4,Bornatici
%2023/08/07 ,Xu Xinhang
%eg:opticalthickness2020_2(3,1,10000)
if ~exist('p','var')
    p=253
end
a=0.45;    %the unit is m,min radius
R0=1.85;   %the unit is m,major radius
r=linspace(-a,a,500);
R=R0+r;
nr=r/a;
if length(ne0)==1 & length(te0)==1
ner=ne0*(1-nr.^2).^2*1e19;   % the unit of ne0 is 1e19/m3
ter=te0*(1-nr.^2).^2*1.6e-16; % the unit of te0 is Kev

elseif exist('x')
  ner = interp1(x,ne0*1e19,r,'pchip');  
  ter = interp1(x,te0*1.6e-16,r,'pchip'); 
end
c=3e8;
me=9.1e-31;
n=2; % X2 mode
m=1; % O1 mode
fce=28*B0*R0./(r+R0);             %GHz             
fpe=8.98e-9.*sqrt(ner);           %GHz
Q=(fpe./fce).^2;
thick1=thick(n,Q);
thick2=fce*2*pi.*R0/c*1e9;
thick3=ter./(me*c^2);
Nx2=1-Q/n^2.*2.*(n^2-Q)./[2*(n^2-Q)-2];
% No2=1-Q/n^2*2.*(n^2-Q)./[2*(n^2-Q)];
mux=Nx2.^(n-1.5).*[1+Q./[n*[n^2-1-Q]].^2];
thickx2_Bornatici=mux.*thick1.*thick2.*(thick3.^(n-1));
thickx2_Janicki=3.7*1e-19*R.^2/R0/B0.*ner.*ter/1.6e-16;
thickx1_Bornatici=5/sqrt(2)*pi*Q.*thick2.*thick3.^2;
thickom_Bornatici=thick(m,Q).*[1-Q/m^2].^(n-0.5).*thick3.^m.*thick2;
% figure
if p==254
    
plot(r,thickx2_Bornatici)
xlabel('Radial Location(m)')
ylabel('Optics Thickness')
else
     plot(nr,thickx2_Bornatici)

%     plot(nr,thickx2_Bornatici,nr,thickx2_Janicki,nr,thickx1_Bornatici,'--',nr,thickom_Bornatici,'--')
xlabel('Normalized radius')
ylabel('Optics Thickness')
end
% b=legend([int2str(n),'x','-Bornatici'],[int2str(n),'x','-Janicki'],['1x','-Bornatici']...
%     ,[int2str(m),'o-Bornatici'])
% figure
% plot(R,thickx2_Bornatici)
% legend([int2str(n),'x','-Bornatici']);
% xlabel('Radial Location(m)')
% ylabel('Optics Thickness')
% text(2.2,1/2*max(thickx2_Bornatici),{['n_e_0=',num2str(ne0),'*1e19/m^3'];...
%     ['t_e_0=',num2str(te0),'Kev'];['IT=',num2str(IT),'A']})
end

function thick1=thick(n,Q);
thick1=pi/2^n*n^(2*n-2)/factorial(n-1).*Q;
end







