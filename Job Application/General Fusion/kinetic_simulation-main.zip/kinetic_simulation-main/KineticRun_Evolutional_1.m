clear    
clc      
close all
%%  parameters of time-dependent
time=[5.0 5.5]                           ;%时间计算区间
%input E evolution 输入环向电场时序，时间点可以是任意时刻，不限点数，但需要从小到大，
%并且一一对应。可通过Vloop读取实验数据，除以2piR得到环向电场
E=[-0.0842   -0.0819   -0.073    -0.0670]*2;
tE=[4.0300    7.8180    8.000     8.4263];
%input ne evolution  输入密度数据ne[/m^3],可以直接把point芯部数据拿来用
tne=[4.1129, 8.3710]      ;
ne =[5.777,  3.3542]*1e18 ;
%input Btub evolution 输入磁扰动数据(Btub=delta{B}/B)，量级大概为10^{-4}
tB=[5.0847    5.6492    6.1653    6.6653    7.0605    7.3427    7.5444    7.6895    7.7621    7.7782 ...
    7.7863    7.8105    7.8347    7.8589    7.8831    7.9395    8.0282    8.1008    8.1815    8.3427  8.4556];
Btub=[0.0082    0.0085    0.0087    0.0087    0.0085    0.0082    0.0078    0.0078    0.0077    0.0074 ...
    0.0070    0.0066    0.0060    0.0056    0.0051    0.0047    0.0044    0.0042    0.0041    0.0038  0.0038]*0.2e-1;
%% 温度及网格常数设置
Z     = 1                                ;   %Z_eff
B    =1.73                             ;%[T]
Te     = 1E3     ;     %[eV]程序目前还不能处理动态温度演化过程
nP    =680       ;
nXi   =300       ;
nL    =35        ;
pMax  =13        ;     %mc
dt    =1e-2      ;
m     =2         ;     %共振阶数
wavetype= 'X'    ;     %'X'or'O'
%% 主程序
p= KINETIC_CODE_Time(nP,pMax,nXi,nL,dt,time,Z,B,tne,ne,tE,E,tB,Btub,Te);
%% 展示结果
p.plot_fpz_distripution([5.1  5.4])
p.plot_distribution_movie
%% space distribution
x=linspace(-0.44,0.44,23)  ;%/m 空间采样位置
tpick=0                    ;%/s 选择时间点                   
omegas=2*radius2omega(x,B)   ;%rad/s计算对应位置的冷等离子电子回旋角频率
o=Nothermal_Radiation_Space_New(omegas,m,wavetype,p,tpick);
o.plot_Teff_distribution

%% time evolution
x=0.1                  ;%[m]. 选择某一个位置对应的冷等离子电子回旋频率辐射演化，注意x必须大于零。attention：x must be great than -3
omegas=2*radius2omega(x,B)   ;
q=Nothermal_Radiation_Timeslice_second3(omegas,m,wavetype,p);
q.plot_Teff_envolution

















