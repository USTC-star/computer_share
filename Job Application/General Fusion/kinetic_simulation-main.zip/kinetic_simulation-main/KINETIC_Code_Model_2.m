classdef KINETIC_Code_Model_2 < matlab.mixin.Copyable & handle
    %本对象主要用于处理背景温度密度不随时间变化的分布函数演化过程；
    %20230810   
    properties
        %grid setup
        grid
        nP
        nL
        L
        nS=35
        nXi
        pMax
        pGridMode=3;
        pGridParameter=0.2
        xiGridMode=1;
        legendgrid
        %plasma parameters setup
        ne
        B
        E
        Te
        Z
        avalanche_switch='on'%off or on
        avalanche
        navs
        %initial type of distribution
        Te0
        initialftype='isotropy' %'isotropy'or 'anisotropy'
        f0=[]
        %Source coefficient
        alpha=0.01;
        particleSource
       
        %time stepsize and total time
        dt
        tMax
        totalsteps
        pcutoff
        t
        %define whether display the setup information
        silent=0
        %anomalous doppler effect object
        ADE
        nA=35
        collisionalfunction='Landreman'%'Landreman'or 'Helander'
        %diffusion coefficient
        Rtau
        Btub=0e-4
        %k、theta energy
        Energy
    end
    properties
        %Conner electric field
        Ec
        %drecier electric field
        ED
        %collisional frequency
        nuee%thermal collsional frequency e-e
        nuei%thermal collsional frequency e-i
        nucc%relaticity collisional frequency
        kec  %ratio of nuee/nucc
        
        lnLambda%Coulomb logarithm
        %some normalized parameters
        %ve/c
        delta
        %ve: theraml electron velocity ,unit[m/s]
        ve
        %Te*e/(mec^2)
        THETA
        %normalized thermal moment
        pTe
        wa     %wp0/wc0

        wc0    %electron cycltron frequency
        %numbers of interping grid
        Nc   =80;
        xi
    end
    properties(Dependent)
        %normalized to Conner electric field
        EHat
        taur% synchrotron radiation time
        %relativity collisional time normalized to synchrotron radiation
        %time
        Sigma
        
        
    end
    methods
        function Ehat=get.EHat(o)
            Ehat  =o.E/o.Ec;
        end
        function taur=get.taur(o)
            eps0=o.constants.eps0;
            e   = o.constants.e;
            me  = o.constants.m;
            c   = o.constants.c;
            taur=6*pi*eps0*(me*c)^3./(e^4*o.B^2);
        end
        
        function Sigma=get.Sigma(o)
            
            Sigma=1./(o.taur*o.nucc);
            %Sigma2=2/3*o.B.^2*o.constants.eps0/(me*o.ne*o.lnLambda)
        end
    end
    
    properties (Constant) %%% Physical constants %%%
        constants = struct('c',   2.997925e8,...
            'e',   1.602176e-19,...
            'm',   9.109380e-31,...
            'eps0',8.854188e-12);
    end
    
    methods
        function o=KINETIC_Code_Model_2(varargin)%(nP,pMax,nXi,nL,dt,tMax,Z,B,ne,E,Te);
            switch nargin
                case 0
                    o.grid=Grid_ECEI();
                case {11}
                    o.SetParameters(varargin{5:end});
                    o.PerformCalculation(varargin{1:4});
                otherwise
                    error('Wrong number of input arguments');
            end
        end
        
        function SetParameters(o,dt,tMax,Z,B,ne,E,Te)
            o.dt   = dt;
            o.tMax = tMax;
            
            o.Te    = Te;
            o.ne    = ne;
            o.Z    = Z;
            o.E    = E;
            o.B    = B;
            o.totalsteps=floor(o.tMax/o.dt);
            o.t=linspace(0,o.tMax,o.totalsteps);
            o.lnLambda = o.CalculateLnLambda();
            o.Ec = o.CalculateEc();
            
            %             o.Ec = o.CalculateEc();
            o.nucc=CalculateRelativisticCollFreq(o);
            o.nuee=CalculateThermalelectronCollFreq(o);
            o.kec =  o.nuee/ o.nucc    ;
            o.delta=o.ve/o.constants.c ;
            o.THETA=o.Te*o.constants.e/(o.constants.m*o.constants.c^2);
            o.pTe=sqrt(2*o.THETA)  ;
            wc0  = 28*o.B*1e9*2*pi ;
            wp0  =5.641*10*sqrt(o.ne);
            o.wa=wp0/wc0;
            o.wc0=wc0   ;

        end
        
        
        function PerformCalculation(o,nP,pMax,nXi,nL)
            o.nP     = nP;
            o.pMax   = pMax;
            o.nXi    = nXi;
            o.nL   = nL;
            
            o.L    = 0:nL-1;
            
            o.grid   = Grid_ECEI(nP,nXi,pMax,o.pGridMode,o.xiGridMode,o.pGridParameter);
            linear_t=linspace(-1,1,5000) ;
            gradient=4;
            s=tanh(linear_t*gradient)  ;
            o.xi=s*1./s(end);
            o.PLxi=o.LegendrePolynomials(o.nL-1,o.xi);
            o.legendgrid=LegendGrid(nP,o.nL,pMax,o.pGridMode,o.pGridParameter);
            o.Initialize()   ;
            o.AdvanceInTime();
        end
        
        
        function nuee=CalculateThermalelectronCollFreq(o)
            e = o.constants.e;
            me = o.constants.m;
            c = o.constants.c;
            eps0=o.constants.eps0;
            o.ve=sqrt(2*o.Te*e/me);
%              nuee=o.ne*e^4*o.lnLambda/(4*pi*eps0^2*me^2*o.ve^3)  ;
%              nuee=o.ne*e^4*o.lnLambda/(3*sqrt(meG)*(o.Te*e).^(3/2))  ;
            nuee=  2.906*1e-6*o.lnLambda*o.ne/1e6*(o.Te)^(-3/2) ;
            o.nuei=  2.906*1e-6*o.Z^2*o.lnLambda*o.ne/o.Z/1e6*(o.Te)^(-3/2);%electron-ion collision frequency,ni(/m^3),Te(eV);
            o.ED=o.ne*e^3*o.lnLambda/(4*pi*eps0^2*me*o.ve^2)    ;
        end
        
        function nucc=CalculateRelativisticCollFreq(o)
            e = o.constants.e ;
            me = o.constants.m;
            c = o.constants.c ;
            eps0=o.constants.eps0;
            %  nuee=o.ne*e^4*o.lnLambda/(4*pi*eps0^2*me^2*o.ve^3);
            nucc= o.ne*e^4*o.lnLambda/(4*pi*eps0^2*me^2*c^3);
        end
        
        function Ec=CalculateEc(o)
            e3 = o.constants.e^3;
            eps02 = o.constants.eps0^2;
            m = o.constants.m;
            c2 = (o.constants.c)^2;
            Ec =  o.ne*o.lnLambda*e3 / (4*pi*eps02*m*c2);
        end
        
        
        function lnLambda = CalculateLnLambda(o)
            lnLambda = 22.36+3/2*log(o.Te)-1/2*log(o.ne/1e6) ;%Te(eV),ne(cm^-3)
            %                         T = o.Te;
            %                         n = o.ne;
            %                         lnLambda = 23.5-log(sqrt(1e-6*n)./(T).^(5/4))...
            %                             - sqrt(1e-5 + (log(T)-2).^2/16);
        end
        
    end
    
    properties
        LegendCoeff
        PLxi
        
        %CollisionalCoeff
        collisional_parameters
        %RadiationCoeff
        %         coeff_Rnm0
        %         coeff_Rnm1
        %         coeff_Mnm0
        RadiationCoeff
        %PML coefficient
        c1=10.1;%c1*y^(−2)(∂/∂y)y^2*exp(−[y−ymax]/c2)∂/∂yF
        c2=1.1  ;
        PMLCoeff
        
    end
    
    methods
        
        function Initialize(o)
            % Initializes variables and sets up parameters and flags.
            % Usage:
            %   Initialize()
            %Print some info
            if ~o.silent
                fprintf('\n*********************************************************************\n');
                fprintf('                    Starting KINETIC_CODE calculation\n');
                fprintf('*********************************************************************\n');
                fprintf(' Numerical parameters:\n');
                fprintf('       nP: %d, nXi: %d, nL: %d, pMax: %.2f, dt: %.3g, tMax: %.3g.\n',...
                    o.grid.nP,o.grid.nXi,o.nL,o.grid.pMax,o.dt,o.tMax);
                if o.pGridMode
                    pType = 'nonuniform';
                else
                    pType = 'uniform';
                end
                if o.xiGridMode
                    xiType = 'nonuniform';
                else
                    xiType = 'uniform';
                end
                fprintf('   Using a %s grid in p and a %s grid in xi.\n',pType,xiType);
                
%                 fprintf('   Using a %s MODE in excited wave.\n',o.wavemode);
            end
            fprintf('   CaculateLegendefficient...\n')
            %                         o.LegendCoeff=CaculateLegendefficient(o.nL,o.legendgrid.xi,o.legendgrid.t,o.legendgrid.gradient);
            %CalculateLegendefficient4(nL,nA,nXi,gradient)
            o.LegendCoeff=CalculateLegendefficient4(o.nL,14,5000,o.legendgrid.gradient);
            fprintf('   Anomalous_Instability_Calculating...\n')
            %
            o.Energy(1,:)=o.Te*o.constants.e/(o.constants.m*o.constants.c.^2);
            %             o.ADE  =Anomalous_Instability_Calculation7(o);
            o.Caculate_synchrotron_radiation_parameters();
            
            o.Caculate_PML_parameters();
            o.initialdistribution();
            o.AssembleEfield_Kinetic();
            o.AssembleDiffusion_Kinetic();
            switch o.collisionalfunction
                case 'Helander'
                    o.collisional_parameters=Caculate_collisional_parameters_kinetic_Helander(o.Z,o.THETA,o.lnLambda,o.legendgrid.p,o.legendgrid.s,o.nL,o.pGridMode,o.pGridParameter);
                    o.Assemble_Collisional_Helander();
                case 'Landreman'
                    o.collisional_parameters=Caculate_collisional_parameters_kinetic_Landreman(o);
%                     o.collisional_parameters=Caculate_collisional_parameters_kinetic_Liu(o);
                    o.Assemble_Collisional_Landreman();
                otherwise
                    error('Wrong number of input arguments.');
            end
            
            o.Assemble_PML_Kinetic();
            o.Assemble_Synchrotron_Kinetic();
            o.BuildMappingMatrices();
        end
        
        function Caculate_synchrotron_radiation_parameters(o)
            
            [o.RadiationCoeff.coeff_Rnm0,o.RadiationCoeff.coeff_Rnm1,o.RadiationCoeff.coeff_Mnm0]=o.Coeff_Synchrotron();
        end
        
        
        function Caculate_Avalanche_Source(o,nIternation)
            %             nIternation=30
            if abs(o.EHat)<1.1||strcmp(o.avalanche_switch,'off')
                o.particleSource.avalance=zeros(o.nL*o.nP,1);
            elseif strcmp(o.avalanche_switch,'on')         
                f2D=o.legendgrid.MapVectorToGrid(o.f(:,nIternation))   ;
                
                S=1:o.nS                        ;
                o.pcutoff = 1/sqrt(abs(o.EHat)-1);
                %             o.pcutoff=0.34
                pm=o.pcutoff                    ;
                %             pm=0.1
                pmax=o.pMax                     ;
                gammam =sqrt(1+pm.^2)           ;
                gmax=sqrt(pmax.^2+1)*7/8        ;
                Ctest2 =zeros(o.nL,o.nP)        ;
                Cfield2=zeros(o.nL,o.nP)        ;
                CL1 =zeros(o.nL,o.nP )          ; %Cfield1+Ctest1
                for jj=1:o.nP
                    p=o.grid.p(jj);
                    gamma=sqrt(1+p.^2);
                    gamma0=gammam+gamma-1;
                    if gamma>gammam&&gamma0<gmax
                        
                        [gamma1 ,gWeight] =o.nolinear_grid(gamma0,gmax,o.Nc);
                        p1=sqrt(gamma1.^2-1);
                        Fl=interp1(o.grid.p,f2D(S,:)',p1)';
                        sig=o.Sigma_Avalanche(gamma,gamma1);
                        xi_spark=sqrt((gamma1+1).*(gamma-1)./((gamma1-1).*(gamma+1)));
                        %                             PLxi_spark=Legendre_test_num(o.L,xi_spark);
                        %                             PLxi_spark=interp1(o.xi',o.PLxi(S,:)',xi_spark')';
                        %                             sigBig=kron(ones(o.nS,1),sig);
                        %                             p1Big=kron(ones(o.nS,1),p1)  ;
                        %                             gWeights=kron(ones(o.nS,1),gWeight)  ;
                        %                             CL_in=p1Big.^3./gamma1.*sigBig.*PLxi_spark.*Fl/2/o.lnLambda/gamma/p;
                        %                             CL1(S,jj)=sum(CL_in.*gWeights,2)'; %trapz(gamma1,CL_in')';
                        PLxi_spark=o.LegendrePolynomials(o.nS-1,xi_spark);
                        CL_in_pre=sig.*p1.^3.*gWeight./gamma1/2/gamma/p/o.lnLambda;
                        CL_in_pres=kron(ones(o.nS,1),CL_in_pre);
                        CL_in=CL_in_pres.*PLxi_spark.*Fl;
                        CL1(1:o.nS,jj)=sum(CL_in,2)' ;
                        if gamma>(2*gammam-1)
                            intsig=o.IntSigma(gamma,gammam);
                            vc=p./gamma;
                            Ctest2(S,jj)=-1./4./o.lnLambda.*vc.*f2D(S,jj).*intsig;
                        end
                        
                        
                    end
                end
                
                %%  caculate the second part of field-test operator  Cfield2
                fav=(Ctest2(1,:)+ CL1(1,:));
%                             nav=trapz(o.grid.p,4*pi*fav.*o.grid.p.^2');
                           nav=sum(4*pi*fav'.*o.grid.p.^2.*o.grid.pWeights);
                            normalized_initial_distribution=o.finitial;
%                           sum(4*pi*o.finitial.*o.grid.p.^2.*o.grid.pWeights)
                         
                Cfield2(1,:)=normalized_initial_distribution.*nav*(-1);
                CL=Ctest2+CL1;%+Cfield2      ;      %
                o.particleSource.avalance=o.legendgrid.MapGridToBigVector(CL');
                o.navs(nIternation)=sum(4*pi*CL(1,:)'.*o.grid.p.^2.*o.grid.pWeights);
                else
                error('check the type of avalanche_switch')
            end
        end
        
        
        function [coeff_Rnm0,coeff_Rnm1,coeff_Mnm0]=Coeff_Synchrotron(o)
            %coefficient of Fn and dFndy for synchrotron radiation
            pBig=o.legendgrid.pBig;tau=o.taur;
            if o.B==0
                coeff_Rnm0=sparse(zeros(size(pBig)));
                coeff_Rnm1=sparse(zeros(size(pBig)));
                coeff_Mnm0=sparse(zeros(size(pBig)));
            else
                x=sym('x');
                gamma=sqrt(1+x.^2);
                fx0=x.^3.*gamma./(tau*o.nucc);
                dfx0dx=diff(fx0);
                Fx0=inline(dfx0dx./x.^2);
                Fx1=inline(gamma.*x./(tau*o.nucc));
                Mx0=inline(1./(gamma.*tau*o.nucc));
                coeff_Rnm0=Fx0(pBig)*(-1);
                coeff_Rnm1=Fx1(pBig)*(-1);
                coeff_Mnm0=Mx0(pBig);
            end
        end
        
        function Caculate_PML_parameters(o)
            coeff1=o.c1;
            coeff2=o.c2;
            Pmax=o.legendgrid.pMax;
            %diffusion term c1*y^(-2)(d/dy)y^2exp(-[y-ymax]/c2)d/dy
            %default constants:c1=0.01,c2=0.1
            x=sym('x');
            f1=coeff1*x.^2.*exp(-1*(x-Pmax).^2/coeff2);
            % f1=x.^2.*exp(-1*(x-3).^2);
            fad1x=inline(diff(f1)*1./x.^2);
            o.PMLCoeff.Coeff_PML1=fad1x(o.legendgrid.pBig)*(-1);
            f2=@(y)coeff1*exp(-1*(y-Pmax).^2/coeff2);
            o.PMLCoeff.Coeff_PML2 =f2(o.legendgrid.pBig)*(-1);
        end
    end
    
    properties
        %storage of the distribution
        f
        finitial
        %Storage step size
        dstep=4
        Pinitial;
        %total steps of calculation
        stepsize;
    end
    
    methods
        function initialdistribution(o)
            %             o.stepsize=floor(o.tMax/(o.dt*o.dstep));
            o.stepsize=floor(o.tMax/o.dt)  ;
            o.f=zeros(o.nP*o.nL,o.stepsize);
            e = o.constants.e;
            me = o.constants.m;
            c = o.constants.c;
            if isempty(o.f0)
                if strcmp(o.initialftype,'isotropy')
                    if isempty(o.Te0)
                        o.Te0=o.Te;
                    end
                    o.Pinitial=sqrt(2*e*o.Te0/me/c^2);
                    f0=@(p)(pi*o.Pinitial^2).^(-3/2)*exp(-p.^2/o.Pinitial^2);
                    o.finitial=f0(o.grid.p);
                    fls=zeros(1,o.nL*o.nP);
                    fls(1:o.nP)=f0(o.legendgrid.p);
                    o.f(:,1)=fls;
                elseif strcmp(o.initialftype,'anisotropy')
                    %                 if isempty(o.inputdistribution)
                    
                    nl=o.nL;
                    PLx=o.LegendrePolynomials(nl-1,o.grid.xi');
                    pz0=0.5,py0=2;dp=0.5;
                    f0= @(p,xi)exp(-((p.*xi-pz0).^2 +(p.*sqrt(1-xi.^2)-py0).^2)./4/dp.^2);
                    f2d=f0(o.grid.p2D,o.grid.xi2D);
                    
                    intxi=trapz(o.grid.xi,(2*pi*o.grid.p2D.^2.*f2d)');
                    n0 =trapz(o.grid.p,intxi);
                    f2dnorm=f2d/n0;
                    o.finitial=f2dnorm;
                    for jj=1:nl
                        l=jj-1;
                        P=PLx(jj,:);
                        P2=kron(P,ones(size(o.grid.p)));
                        F(jj,:)=trapz(o.grid.xi,(P2.*f2dnorm)')*(2*l+1)/2;
                    end
                    o.f(:,1)=reshape(F',[],1);
                    
                else
                    error('wrong defination of the type of initial distrubtion')
                end
            else
                o.f(:,1)=o.f0;
            end
        end
        
        
        
        function FLs = MapLegModeVectorToGrid(o,ys)
            % Maps a quantity defined on the the finite-difference--Legendre-mode space
            %to 2D grid (L,P)
            % Usage:
            %   fls = MapBigVectorToLegModes(f)
            FLs=reshape(ys,[],o.nL);
            %             FLs= FLs';
        end
        
        function fls = MapLegModeGridToVector(o,FLs)
            % Maps a quantity defined on the the finite-difference--Legendre-mode space
            %to 2D grid (L,P)
            % Usage:
            %   fls = MapBigVectorToLegModes(f)
            fls=reshape(FLs,[],o.nL*o.nP);
        end
        
        
    end
    
    properties
        %electric field matrix
        Emat
        %collisional matrix
        Cmat
        %PML boundary condition matrix
        Pmat
        %synchrotron radiation matrix
        Smat
        %operator matrix
        Kmat
        %anomalous doppler diffusion matrix
        Cxx
        Cxp
        Cpp
        Cpx
        
        
        %setup boundary matrix
        boundarymatrix
        %Assemble all marix
        matrix
        %right side
        rhs
        %scattering
        
        p_scattering
        xi_scattering_max
        xi_scattering_min
        %diffusion matrix
        Dmat
        %runaway parameters
        Runawayrate
        Runawayratio
       
        
        
    end
    methods
        function AssembleEfield_Kinetic(o)
            p=o.LegendCoeff;
            q=o.legendgrid;
            sz=q.matSize;
            eP=ones(q.nP);
            Umat =q.BuildBigMatrix(eP,sparse(p.Unm'),0);
            Qmat =q.BuildBigMatrix(eP,sparse(p.Qnm'),0);
            Emat1=Qmat.*q.ddpBigmat*o.EHat ;
%             Emat2=Umat.*q.IBigmat*o.EHat   ;
            o.Emat=(Emat1+spdiags(q.pBig.^-1,0,sz,sz)*Umat.*q.IBigmat*o.EHat )*(-1);
        end
        
        function AssembleDiffusion_Kinetic(o)
            %Physics of Plasmas 7, 4590 (2000);R. W. Harvey,V. S. Chan, S. C. Chiu
            %Runaway electron production in DIII-D killer pellet experiments, calculated
            %with the CQL3DÕKPRAD model
            R=1.85;a=0.45;qsaft=1.5;
            rho=0;
            p=o.LegendCoeff;
            q=o.legendgrid ;
            sz=q.matSize   ;
            eP=ones(q.nP)   ;
            Qmat =q.BuildBigMatrix(eP,sparse(p.Dnm'),0);
            Reff=pi*qsaft*R        ;
            Dst=pi*Reff*o.Btub.^2  ;
            o.Rtau=4*o.constants.c.*Dst.*q.pBig./(1+q.pBig.^2).^3./(rho-a).^2/o.nucc;
            o.Dmat=spdiags(o.Rtau,0,sz,sz)*Qmat.*q.IBigmat;%Dmatpre
        end
        
        function Assemble_Collisional_Helander(o)
            p=o.LegendCoeff;
            q=o.legendgrid;
            sz=q.matSize;
            h=o.collisional_parameters;
            eL=ones(q.nL);eP=ones(q.nP);
            Cmat1  =q.BuildBigMatrix(eP,sparse(p.Cnm1'),0);
            Cmat2 =q.BuildBigMatrix(eP,sparse(p.Cnm2'),0) ;
            Cmat3  =q.BuildBigMatrix(eP,sparse(p.Cnm3'),0);
            dia=@(v)spdiags(v,0,sz,sz);
            coeff_cnm1=dia(h.coeff_cnm1);
            coeff_cnm21=dia(h.coeff_cnm21);
            coeff_cnm22=dia(h.coeff_cnm22);
            coeff_cnm3=dia(h.coeff_cnm3);
            % Cmat=coeff_cnm1*Cmat1.*o.ddpBigmat+coeff_cnm21*Cmat2.*o.IBigmat+coeff_cnm22*Cmat2.*o.d2dp2Bigmat ...
            %      +coeff_cnm3*Cmat3.*o.IBigmat;
            o.Cmat=coeff_cnm1*Cmat1.*q.d2dp2Bigmat+coeff_cnm21*Cmat2.*q.IBigmat+coeff_cnm22*Cmat2.*q.ddpBigmat ...
                +coeff_cnm3*Cmat3.*q.IBigmat;
        end
        
        
        function Assemble_Collisional_Landreman(o)
            coeff=o.LegendCoeff;
            q=o.legendgrid;
            p=q.p;
            sz=q.matSize;
            h=o.collisional_parameters;
            eP=ones(q.nP);
            Cmat1  = q.BuildBigMatrix(eP,sparse(coeff.Cnm1'),0);
            Cmat2  = q.BuildBigMatrix(eP,sparse(coeff.Cnm2'),0);
            Cmat3  = q.BuildBigMatrix(eP,sparse(coeff.Cnm3'),0);
            f11=1./p.^2.*(q.ddp*(p.^2.*h.coeff_cnm1));
            f12=h.coeff_cnm1;
            f20=1./p.^2.*(q.ddp*(p.^2.*h.coeff_cnm2));
            f21=h.coeff_cnm2;
            
            dia=@(v)spdiags(v,0,sz,sz)  ;
            coeff_cnm11=dia(kron(ones(o.nL,1),f11));
            coeff_cnm12=dia(kron(ones(o.nL,1),f12));
            coeff_cnm20=dia(kron(ones(o.nL,1),f20));
            coeff_cnm21=dia(kron(ones(o.nL,1),f21));
            coeff_cnm3 =dia(kron(ones(o.nL,1),h.coeff_cnm3));
            o.Cmat=coeff_cnm11*Cmat1.*q.ddpBigmat+coeff_cnm12*Cmat1.*q.d2dp2Bigmat+...
                coeff_cnm20*Cmat2.*q.IBigmat+coeff_cnm21*Cmat2.*q.ddpBigmat+coeff_cnm3*Cmat3.*q.IBigmat;
            %             o.Cmat=coeff_cnm3*Cmat3.*q.IBigmat;
        end
        
        function Assemble_Anomalous_Doppler_Matrix(o)
            q=o.legendgrid;
            p=o.legendgrid.p;
            gamma=sqrt(1+p.^2);
            sz=q.matSize;
            Axx11=o.ADE.LegendCoeff.Anm_xixi_11;
            Axx12=o.ADE.LegendCoeff.Anm_xixi_12;
            Axx21=o.ADE.LegendCoeff.Anm_xixi_21;
            Axx22=o.ADE.LegendCoeff.Anm_xixi_22;
            Dxx11=o.ADE.F{1};
            Dxx12=o.ADE.F{2};
            Dxx21=o.ADE.F{2};
            Dxx22=o.ADE.F{3};
            dia=@(v)spdiags(v,0,sz,sz)  ;
            Cxx=[];
            for jj=1:o.nA
                fxx11= 1./p.^4.*Dxx11(:,jj);
                fxx12=1./(p.^3.*gamma).*Dxx12(:,jj);
                fxx21=1./(p.^3.*gamma).*Dxx21(:,jj);
                fxx22=1./(p.^2.*gamma.^2).*Dxx22(:,jj);
                
                coeff_xx11=dia(kron(ones(o.nL,1),fxx11));
                coeff_xx12=dia(kron(ones(o.nL,1),fxx12));
                coeff_xx21=dia(kron(ones(o.nL,1),fxx21));
                coeff_xx22=dia(kron(ones(o.nL,1),fxx22));
                Cxx=Cxx+coeff_xx11*Axx11.*q.IBigmat+coeff_xx12*Axx12.*q.IBigmat+coeff_xx21*Axx21.*q.IBigmat+coeff_xx22*Axx22.*q.IBigmat;
            end
            o.Cxx=Cxx;
        end
        
        
        function  Assemble_PML_Kinetic(o)
            p=o.PMLCoeff;
            q=o.legendgrid;
            sz=q.matSize;
            dia=@(v)spdiags(v,0,sz,sz);
            Coeff_PML1=dia(p.Coeff_PML1);
            Coeff_PML2=dia(p.Coeff_PML2);
            eL=eye(q.nL);eP=ones(q.nP);
            PMLmn  =kron(sparse(eL),eP);
            o.Pmat=Coeff_PML1*PMLmn.*q.ddpBigmat+Coeff_PML2*PMLmn.*q.d2dp2Bigmat;
        end
        
        function Assemble_Synchrotron_Kinetic(o)
            % synchrotron radiation operator
            %reference:10.1103/PhysRevLett.114.115002
            %1.Effective Critical Electric Field for Runaway-Electron Generation
            %2.动理学模拟笔记
            %xxh,20220813
            p=o.RadiationCoeff;
            q=o.legendgrid;
            h=o.LegendCoeff;
            sz= q.matSize;
            eP=ones(o.nP);
            Omat =q.BuildBigMatrix(eP,sparse(h.Onm'),0);
            Mmat =q.BuildBigMatrix(eP,sparse(h.Mnm'),0);
            Rmat =q.BuildBigMatrix(eP,sparse(h.Rnm'),0);
            dia=@(v)spdiags(v,0,sz,sz);
            coeff_Rnm0=dia(p.coeff_Rnm0);
            coeff_Rnm1=dia(p.coeff_Rnm1);
            coeff_Mnm0=dia(p.coeff_Mnm0);
            o.Smat=(coeff_Rnm0*Rmat.*q.IBigmat+coeff_Rnm1*Rmat.*q.ddpBigmat+...
                coeff_Mnm0*(Omat+Mmat).*q.IBigmat);
        end
        
        function Calculate_Particle_Source(o,nIteration)
            fnorm=@(p)(pi*o.pTe^2).^(-3/2)*exp(-p.^2/o.pTe^2);
            fnow=o.f(:,nIteration);
            o.particleSource.compensate=zeros(size(fnow));
            if o.alpha>0
                 o.particleSource.source=o.alpha*fnorm(o.legendgrid.pBig);
            else
            flsnow=o.MapLegModeVectorToGrid(fnow);
            delta_ne=1-trapz(o.legendgrid.p,flsnow(:,1).*o.legendgrid.p.^2)*4*pi;           
            o.particleSource.compensate(1:o.grid.nP)=delta_ne*fnorm(o.legendgrid.p);
            end
          
        end
        
        function Calculate_EMW_diffusion(o,nIteration)
            %get the energy in (k,θ) space ,than we will use the energy to
            %calculate the qusi-linear diffusion ,which will cause much
            %attuation on it ,for qusi-linear equation,the main part
            %refer to the work of POKOL G I, KóMáR A, BUDAI A, et al.
            %Quasi-linear analysis of the extraordinary electron wave destabilized by runaway electrons [J].
            %Physics of Plasmas, 2014, 21(10): 102503
            o.ADE.Get_growth_Rate(o.f(:,nIteration));
            o.Energy(nIteration+1,:)=o.Energy(nIteration,:).*o.ADE.Tau.*o.dt+o.Energy(nIteration,:);
            
            
            %compile the function of qusilinear diffusion?
            %             dfdt=?
            
            
        end
        
    end
    methods
        
        function AdvanceInTime(o)
            q=o.legendgrid;
            o.boundarymatrix=speye(q.matSize);
            Idpmax=o.nP*o.L+o.nP;
            y0=o.f(:,1) ;
            y0(Idpmax)=0;
            o.Kmat=o.Emat+o.Cmat+o.Smat+o.Pmat+o.Dmat;
%           o.Kmat=o.Dmat;
            o.Kmat(Idpmax,:)=0;
            o.rhs=y0 ;
            f0ld =y0 ;
            o.matrix=o.boundarymatrix+o.dt*(o.Kmat)*o.nucc;
            q=Gmres(o.matrix,o.rhs);
            for nt=1:o.totalsteps
                disp(nt)
                tol = 1e-13;
                maxit = 20 ;
                [f0ld,fl1,rr1,it1,rv1]  = gmres(o.matrix,o.rhs,[],tol,maxit,...
                    @q.PreconditionerFunc ,[],f0ld);

                o.f(:,nt+1)=f0ld            ;                  
                o.Caculate_Avalanche_Source(nt+1);
                o.Calculate_Particle_Source(nt);
                %  Calculate_EMW_diffusion(o,nt)
                o.rhs=f0ld+o.dt*o.particleSource.avalance*o.nucc+o.particleSource.compensate+o.dt.*o.particleSource.source;%
                o.avalanche(nt,:)=o.particleSource.avalance;
                o.rhs(Idpmax)=0;
            end
        end
        
        function Caculate_scattering_curve(o)
            %Kinetic modelling of runaway electrons in dynamic scenarios
            o.pcutoff = 1/sqrt(abs(o.EHat)-1);
            pm=o.pcutoff                    ;
            pmax=o.pMax                     ;
%             gammam =sqrt(1+pm.^2)           ;
            gammain_max=sqrt(1+pmax.^2);
            gamma=sqrt(1+o.grid.p.^2);
            id=find(o.grid.p>pm&o.grid.p<pmax/2);
            gamma_scattering=gamma(id);
            o.p_scattering=o.grid.p(id);
            o.xi_scattering_max=sqrt(gamma_scattering./(gamma_scattering+1));
            o.xi_scattering_min=sqrt((gammain_max+1)*(gamma_scattering-1)./((gammain_max-1).*(gamma_scattering+1)));
            plot(o.p_scattering.*o.xi_scattering_min,o.p_scattering.*sqrt(1-o.xi_scattering_min.^2),'k--')
%             hold on
%             plot(o.p_scattering.*o.xi_scattering_max,o.p_scattering.*sqrt(1-o.xi_scattering_max.^2),'k--')
%             hold off
%             axis equal
%             xlim([0,o.pMax/3])
        end
        
        
        function plot_distribution_movie(o)
            o.define_whether_makemov('no');
            for nt=1:10:o.totalsteps
                fs=o.MapLegModesToBigVector(o.f(:,nt));
                f2D=o.MapVectorToGrid(fs);
                f2D(f2D<1e-86)=1e-86 ;
                surf(o.grid.pPara2D,o.grid.pPerp2D,log10(abs(f2D)),'EdgeColor','none');
                %                 surf(o.grid.pPara2D,o.grid.pPerp2D,(f2D),'EdgeColor','none');
                %                  caxis([-0  30])
                %                 shading interp
                view(0,90)
                xlabel('p_{||}')
                ylabel('p_{\perp}')
                title([num2str(o.t(nt),3),'s'])
                cb = colorbar();
                %                 cb.Ruler.Exponent = -3;
                colormap( 'jet')
                %                                 caxis([0  7e-3])
                %                                 caxis([-1e-23  1e-23])
                caxis([-8  -4])
                axis equal
                axis tight
                %                 view(0,90)
                %                 xlim([0,o.pMax])
                %                                 ylim([0 o.pMax/2]);
                %                 zlim([-inf inf])
                grid off
                drawnow
                o.generate_mov_movie;
            end
            if strcmp(o.makemov,'yes')
                close(o.myvideo)
            end
        end
        
        
        
        function plot_avalanche_distribution_movie(o)
                ID1=o.grid.xi2D<0.8;%&o.grid.p2D>o.pMax*3/4;
                ID2=o.grid.p2D>2*o.pcutoff;
                ID12=find(ID1.*ID2);
                
%                 ID2=o.grid.p2D>o.pMax*3/4;
%                 ID3=o.grid.p2D<o.pcutoff;
%                 ID23=union(ID2,ID3);
%                 ID123=intersect(ID23,ID1);
            for nt=1:10:o.totalsteps
                fs=o.MapLegModesToBigVector(o.avalanche(nt(1),:)');
                f2D=o.MapVectorToGrid(fs)  ;
                f2D_Zero=f2D;
%                 ID=find(o.grid.pPara2D<o.pcutoff&o.grid.pPerp2D>o.pMax/2);

                
                f2D_Zero(ID12)=nan;
%               f2D=abs(f2D)               ;
                surf(o.grid.pPara2D,o.grid.pPerp2D,log10(abs(f2D)),'EdgeColor','none');
                hold on
                contour(o.grid.pPara2D,o.grid.pPerp2D,(f2D_Zero),[0 0],'w--','LineWidth',1);
                hold off
%               shading interp
                view(0,90)
                xlabel('p_{||}')
                ylabel('p_{\perp}')
                title([num2str(o.t(nt)),'s'])
                colorbar
                colormap( 'jet')
                caxis([-10  -7])
                axis equal
                xlim([-1,o.pMax*2/3]);
                ylim([0 ,o.pMax/2] ) ;                
                zlim([-inf inf]) ;
                drawnow
            end
        end
        
        
 function plot_avalanche_distribution_slice(o,tp)
                     nt=find(abs(o.t-tp)==min(abs(o.t-tp)));
                ID1=o.grid.xi2D<0.8;%&o.grid.p2D>o.pMax*3/4;
                ID2=o.grid.p2D>2*o.pcutoff;
                ID12=find(ID1.*ID2);
                
%                 ID2=o.grid.p2D>o.pMax*3/4;
%                 ID3=o.grid.p2D<o.pcutoff;
%                 ID23=union(ID2,ID3);
%                 ID123=intersect(ID23,ID1);
           
                fs=o.MapLegModesToBigVector(o.avalanche(nt(1),:)');
                f2D=o.MapVectorToGrid(fs)  ;
                f2D_Zero=f2D;
%                 ID=find(o.grid.pPara2D<o.pcutoff&o.grid.pPerp2D>o.pMax/2);

                
                f2D_Zero(ID12)=nan;
%               f2D=abs(f2D)               ;
                surf(o.grid.pPara2D,o.grid.pPerp2D,log10(abs(f2D)),'EdgeColor','none');
                hold on
                contour(o.grid.pPara2D,o.grid.pPerp2D,(f2D_Zero),[0 0],'w--','LineWidth',2);
%                 o.Caculate_scattering_curve
                hold off
%               shading interp
                view(0,90)
                xlabel('p_{||}')
                ylabel('p_{\perp}')
%                 title([num2str(o.t(nt)),'s'])
                c=colorbar
                colormap( 'jet')
                set(c,'tickdir','out') 
                caxis([-15  -7])
                axis equal
                xlim([-1,o.pMax*2/3]);
%                 ylim([0 ,o.pMax/2] ) ;        
                ylim([0 ,3.9] ) ;     
                zlim([-inf inf]) ;
                drawnow
     
        end
        
        
        function plot_distribution_slice(o,tp)
            idt=find(abs(o.t-tp)==min(abs(o.t-tp)));
            fs=o.MapLegModesToBigVector(o.f(:,idt(1)));
            f2D=o.MapVectorToGrid(fs);
            f2D(f2D<1E-17)=1E-17;
            %             surf(o.grid.pPara2D,o.grid.pPerp2D,log10(f2D),'EdgeColor','none');
            surf(o.grid.pPara2D,o.grid.pPerp2D,(f2D),'EdgeColor','none');
            caxis([-0  0.1])
            %             shading interp
            view(0,90)
            xlabel('p_{||}')
            ylabel('p_{\perp}')
            title([num2str(tp),'s'])
            colorbar
            colormap( 'jet')
            %             caxis([-6  -0])
            axis equal
            %             xlim([-1,o.pMax])
            %             ylim([0 o.pMax]);
            zlim([-inf inf])
            xlim([0,12])
            ylim([0 6]);
            drawnow
        end
        
        function plot_ne_evolution(o)
            for nt=1:1:o.totalsteps
                fls2D=o.MapLegModeVectorToGrid(o.f(:,nt));
                rho=fls2D(:,1).*o.grid.p.^2;
                ne(nt)= trapz(o.grid.p,rho')*4*pi;
            end
                        plot(o.t,ne)
%             plot(o.t*o.nuee,(ne-ne(1))/ne(1),'k')
            xlabel('\tau_{ee}')
            ylabel('\deltan/n_0')
        end
        
        
        function plot_ne_contour(o,tp)
            nt=find(abs(o.t-tp)==min(abs(o.t-tp)));
            fs=o.MapLegModesToBigVector(o.f(:,nt));
            f2D=o.MapVectorToGrid(fs);
            f2D(f2D<1E-10)=1E-10;
            [C,~]=contour(o.grid.pPara2D,o.grid.pPerp2D,log10(f2D),[-8:0.1:0]);%,'k'
            axis equal
            colormap jet
            caxis([-10 -2])
            xlim([-0.5 5])
            ylim( [-0.0 3])
            axis on
        end
        
        function fit__numrical_temperature(o)
            f2D_initial=o.MapLegModeVectorToGrid(o.f(:,1));
            f2D_end=o.MapLegModeVectorToGrid(o.f(:,end));
            fth=(pi*o.pTe^2).^(-3/2)*exp(-o.grid.p.^2/o.pTe^2);
            plot(o.grid.p,log10(f2D_initial(:,1)),'.','MarkerSize',12)
            
            hold on
            plot(o.grid.p,log10(f2D_end(:,1)),'.','MarkerSize',12)
            plot(o.grid.p,log10(fth),'k')
            
            hold off
            
            xlabel('p')
            ylabel('log_{10}f(p)')
            legend(['Kinetic,t=',num2str(o.t(1),2),'\tau_{ee}'],['Kinetic,t=',num2str(o.tMax*o.nuee,2),'\tau_{ee}'],['Maxwell-fp,Te=',num2str(o.Te/1e3),'Kev '])
            % title(['stable state for Te= ',num2str(o.Te/1e3),'Kev '])
            xlim([0 1])
            ylim([-20 4])
            
        end
        
        
        function plot_p_fp_distripution(o,tps)
            for jj=1:length(tps)
                
                tp=tps(jj);
                idt=find(abs(o.t-tp)==min(abs(o.t-tp)));
                fs=o.MapLegModesToBigVector(o.f(:,idt));
                f2D=o.MapVectorToGrid(fs);
                %                      S1=trapz(o.grid.xi,(f2D.*p2D.^2)');
                %                      S2=trapz(o.grid.p,S1*2*pi);
                %                      n(jj)=S2;
                %                      jj=jj+1;
                S=trapz(o.grid.xi,(f2D)');
                %                      yy=ones(1,length(o.grid.p))*o.t(idt);
                plot(o.grid.p,log10(S))
                %                       xlim([0 1])
                %                     plot3(o.grid.p,yy,log10(S))
                ylim([-40 2])
                %                     xlim([0.69 0.7])
                hold on
                %                 str{jj}=[num2str(o.t(idt),'%14.4f'),'s'];
                str{jj}=[num2str(tps(jj)),'s'];
            end
            %             plot(n)
            hold off
            h=legend(str)
            set(h,'box','off')
            xlabel('p')
            ylabel('$log_{10}f_p$','interpreter','latex','Fontsize',18)
        end
        
        
        function plot_Temperature_fit(o)
            me=o.constants.m;
            c =o.constants.c;
            e =o.constants.e;
            %           eps=sqrt(o.grid.p.^2+1 )-1  ;
            eps=o.grid.p.^2/2;
            for nt=1:o.totalsteps
                disp(nt)
                fl2D=o.legendgrid.MapVectorToGrid(o.f(:,nt));
                f=fl2D(1,:)                                 ;
                id=find(o.grid.p<2.7);
                gfit = fit(o.grid.p(id),f(id)','gauss1');
                pT=gfit.c1;
                Tcurv(nt)=pT.^2*o.constants.m*o.constants.c^2/o.constants.e/2/1e3;
                eps_mean = trapz(o.grid.p,(eps'.*f.*4*pi.*o.grid.p'.^2)');
                Tfit(nt)=eps_mean/3*2*(me*c^2)/1e3/e    ;
            end
            plot(o.t*o.nuee,Tfit,'s-')
            hold on
            plot(o.t*o.nuee,Tcurv,'^-')
            hold off
            xlabel('\tau_{ee}')
            ylabel('T (Kev)')
        end
        
        
        function plot_F1_distibution(o,tps)
            
            for jj=1:length(tps)
                jj
                tp=tps(jj);
                idt=find(abs(o.t-tp)==min(abs(o.t-tp)));
                fl2D=o.legendgrid.MapVectorToGrid(o.f(:,idt(1)));
                f=fl2D(1,:);
                
                plot(o.grid.p,f)
                hold on
                if jj<length(tps)
                    str{jj}=[num2str(tp*o.nuee,2),'\tau_{ee}'];
                else
                    str{jj}=['\infty \tau_{ee}'];
                end
            end
            hold off
            xlabel('p')
            ylabel('f')
            legend(str)
            xlim([0 0.2])
            ylim([0 800])
        end
        
        function plot_Temperature_theory(o)
            ts=linspace(0,o.tMax,1000);
            %         [t,y] = ode45(@(t,y)o.Temperature_differencial_function(t,y), ts, o.Te0);
            [t,y] = ode23s(@(t,y)o.Temperature_differencial_function(t,y),ts,o.Te0);
            plot(t*o.nuee,y/1e3,'k')
            xlabel('\tau_{ee}')
            ylabel('T (Kev)')
        end
        
        function f=Calculate_Perturbation_Diffusion(o,t)
            R=1.85;   a=0.45;   qsaft=1.5;
            rho=0;
            Reff=pi*qsaft*R ;
            Dst=pi*Reff*o.Btub.^2 ;
            p=o.grid.p2D;xi=o.grid.xi2D;
            D=4*o.constants.c.*Dst.*abs(xi).*p./(1+p.^2).^3./(rho-a).^2;
            f=o.finitial.*exp(-D*t);
        end
        
        function plot_perturbation_theory_vs_numerical(o)
            f2d    = o.Calculate_Perturbation_Diffusion(o.tMax);%o.tMax
            fs=o.MapLegModesToBigVector(o.f(:,end));
            f2dnum =o.MapVectorToGrid(fs);
            f2dnum(f2dnum<1e-86)=1e-86 ;
            fs1=o.MapLegModesToBigVector(o.f(:,1));
            f2dnum1 =o.MapVectorToGrid(fs1);
            t=o.t(end);
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            figure
            surf(o.grid.pPara2D,o.grid.pPerp2D,100*(f2dnum-f2d)./max(max(f2d)),'EdgeColor','non')
            xlabel('p_{//}')
            ylabel('p_\perp')
            title(['t=',num2str(t,2),'s'])
            colormap jet
            cb = colorbar();
            %             cb.Ruler.Exponent = -2;
            grid off
            ylabel(cb,'Relative Error(%)','FontSize',14,'FontName','Times New Roman','FontWeight','bold')
            axis equal
            view(0,90)
%             caxis([0 2])
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            figure
            surf(o.grid.pPara2D,o.grid.pPerp2D,f2d,'EdgeColor','non')
            title(['t=',num2str(t,2),'s'])
            xlabel('p_{//}')
            ylabel('p_\perp')
            zlabel('Exact Solution')
            colormap jet
            cb = colorbar();
            cb.Ruler.Exponent = -2;
            axis equal
            caxis([2 10]*1e-3)
            view(0,90)
            ylabel(cb,'Exact Solution','FontSize',14,'FontName','Times New Roman','FontWeight','bold')
            grid off
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            figure
            surf(o.grid.pPara2D,o.grid.pPerp2D,(f2dnum),'EdgeColor','non')
            title(['t=',num2str(t,2),'s'])
            xlabel('p_{//}')
            ylabel('p_\perp')
            zlabel('Exact Solution')
            colormap jet
            cb = colorbar();
            cb.Ruler.Exponent = -2;
            axis equal
            caxis([2 10]*1e-3)
            view(0,90)
            ylabel(cb,'Numerical Solution','FontSize',14,'FontName','Times New Roman','FontWeight','bold')
            grid off
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            figure
            surf(o.grid.pPara2D,o.grid.pPerp2D,f2dnum1,'EdgeColor','non')
            xlabel('p_{//}')
            ylabel('p_\perp')
            title(['t=',num2str(o.t(1),2),'s'])
            colormap jet
            grid off
            cb = colorbar();
            cb.Ruler.Exponent = -2;
            caxis([2 10]*1e-3)
            ylabel(cb,'Initial Distribution','FontSize',14,'FontName','Times New Roman','FontWeight','bold')
            axis equal
            view(0,90)
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            figure
            surf(o.grid.pPara2D,o.grid.pPerp2D,f2dnum1-f2dnum,'EdgeColor','non')
            xlabel('p_{//}')
            ylabel('p_\perp')
            title(['t=',num2str(o.t(1),2),'s'])
            colormap jet
            grid off
            cb = colorbar();
            %             cb.Ruler.Exponent = -2;
            %             caxis([2 10]*1e-3)
            ylabel(cb,'\DeltaDistribution','FontSize',14,'FontName','Times New Roman','FontWeight','bold')
            axis equal
            view(0,90)
            
        end
        
        
        
        function plot_legend_distribution(o)
            [p2D,L2D]=meshgrid(o.grid.p,o.L);
            for nt=1:10:o.totalsteps
                f2D=o.MapLegModeVectorToGrid(o.f(:,nt));
                surf( log10(abs(f2D)),'EdgeColor','none');
                shading interp
                view(0,90)
                xlabel('L')
                ylabel('P')
                title([num2str(nt*o.dt/o.nucc),'s'])
                colorbar
                colormap( 'jet')
                caxis([-20  -10])
                axis tight                
                %             xlim([-1,o.pMax])
                %             ylim([0 6.5]);
                %             zlim([-inf inf])
                drawnow
            end
        end
        
         function Calculate_runaway_growthRate(o)
                Runaway_rate=zeros(size(o.t));
                net=zeros(size(o.t));ner=zeros(size(o.t));
                for jj= 1:length(o.t)
                    time=o.t(jj);
                    pc = 1/sqrt(abs(o.EHat)-1);
                    ps=o.grid.p;
                    ps(ps<1*pc)=0;
                   
                    idt=find(abs(o.t-time)==min(abs(o.t-time)));
                    ava=o.avalanche(idt,:);
%                     o.Kmat=o.Emat+o.Cmat+o.Smat+o.Pmat+o.Dmat;
                    o.Kmat=o.Emat+o.Cmat+o.Smat+o.Pmat+o.Dmat;
%                     dF0dt=ava(1:o.grid.nP)';
                    dF0dt=-1*o.Kmat(1:o.grid.nP,:)*o.f(:,idt)+ava(1:o.grid.nP)';
                    dF0dt(ps>(o.pMax*14/15))=0;
                    Runaway_rate(jj)=trapz(ps,dF0dt*4*pi.*ps.^2)*o.nucc;%
                    f1=o.f(1:o.grid.nP,idt);
                    net(jj)=sum(o.grid.pWeights.*f1*4*pi.*o.grid.p.^2);              
                    ner(jj)=trapz(ps,f1*4*pi.*ps.^2);
                end
                o.Runawayratio=ner;
                o.Runawayrate=Runaway_rate./net;
                plot(o.t,log10(o.Runawayrate))
%                 plot(o.t,(o.Runawayrate/o.nuee./ner))
%                plot(o.t,(ner./ne))
%                 plot(o.t,ne)
%                 ylim([-5 40])
                  xlabel('s')
%                 ylabel('log_{10}\gamma')
            end
            
            function Calculate_runaway_Ratio(o)
                Runaway_ratio=zeros(size(o.t));
                ne=zeros(size(o.t));
                for jj= 1:length(o.t)
                    time=o.t(jj);
                    pc = 1/sqrt(abs(o.EHat)-1);
                    ps=o.grid.p;
                    ps(ps<2/3*pc)=0;
                    idt=find(abs(o.t-time)==min(abs(o.t-time)));
                    fnl=o.f(:,idt);
                    fnL2D=o.legendgrid.MapVectorToGrid(fnl);
                    f1=fnL2D(1,:);
                    Runaway_ratio(jj)=trapz(ps,f1'*4*pi.*ps.^2)/o.nucc;
                    ne(jj)=trapz(o.grid.p,f1'*4*pi.*o.grid.p.^2);
                    
                end
                o.Runawayratio=Runaway_ratio./ne;
                %             plot(o.t,log10(o.Runawayratio) )
                %             plot(o.t,(Runaway_ratio) )
                            plot(o.t,(o.Runawayratio) )
                dndt=dss004_nolinear_new(o.t,o.Runawayratio);
%                 plot(o.t,dndt )                
                xlabel('s')
            end
            
            function Calculate_RunawayRate_Theory(o)
              % P Helander et al 2002 Plasma Phys. Control. Fusion 44 B247 
              
        %%%%%calculate nr0%%%%%%%%%%%%%%%
         pc = 1/sqrt(abs(o.EHat)-1);
                    ps=o.grid.p;
                    ps(ps<pc)=0;
                    fnl=o.f(:,1);
                    fnL2D=o.legendgrid.MapVectorToGrid(fnl);
                    f1=fnL2D(1,:);
                    nr0=trapz(ps,f1'*4*pi.*ps.^2);
         %%%%%calculate nr0%%%%%%%%%%%%%%%    
            ts=linspace(0,o.tMax,1000);
           
            [t,y] = ode23s(@(t,y)o.Runaway_differencial_function(t,y),ts,nr0);
%             plot(t,y,'k')
%             xlabel('t (s)')
%             ylabel('n_r')
               dndt=dss004_nolinear_new(t,y);
               tr=t(2:end);dndtr=dndt(2:end);
                plot(t(2:end),dndtr./y(2:end)' )  
               xlabel('s')
               ylim([0 1])
                
            end
            
            
            
    end
    
    properties
        legModesToBigVectorMap
        bigVectorToLegModeMap
        makemov
        myvideo
    end
    
    methods %%% Mapping to Legendre modes %%%
        function BuildMappingMatrices(o)
            % Constructs matrices for mapping between the 2D
            % finite-difference grid and finite-difference--Legendre-mode
            % representations.
            %
            % Usage:
            %   BuildMappingMatrices()
            %
            
            nP  = o.grid.nP ;
            nXi = o.grid.nXi;
            
            %%%Build a matrix describing the mapping from a Legendre-mode
            %%%vector to a vector on the 2D finite-difference grid
            mapMat = sparse(nP*nXi, nP*o.nL);
            cellOfRowBlocks = cell(nXi,1);
            
            %Make a (nP-1)x(nP) block with ones on the first upper
            %diagonal, which we will then duplicate horizontally, weighted
            %by P_l, to form a "row block". Row block i gives the mapping
            %to f(p,xi_i).
            identityBlock = speye(nP);
            
            Pls = o.LegendrePolynomials(o.nL-1,o.grid.xi');
            
            for iXi = 1:nXi
                PlsAtXi = Pls(:,iXi)';
                cellOfRowBlocks{iXi} = kron(PlsAtXi,identityBlock);
            end
            
            mapMat = cell2mat(cellOfRowBlocks);
            o.legModesToBigVectorMap = mapMat;
            
            
            %%%Invert the matrix to get the inverse mapping from the
            %%%2D finite-difference grid
            %%%vector to Legendre modes
            %This should give accuracy to machine precision. The matrix is
            %rectangular, so we need to use the pseudo inverse. The
            %following is equivalent to pinv(full(mapMat)), but works for
            %sparse matrices (and the result is pretty sparse, so storing
            %is not an issue):
            r = qr(mapMat,0) ;
            o.bigVectorToLegModeMap = r\(r'\mapMat');
        end
        
        function fls = MapBigVectorToLegModes(o,f)
            % Maps a quantity defined on the 2D finite-difference grid to
            % the finite-difference--Legendre-mode space
            %
            % Usage:
            %   fls = MapBigVectorToLegModes(f)
            
            fls = o.bigVectorToLegModeMap*f;
        end
        
        function dTdt=Temperature_differencial_function(o,t,T)
            me=o.constants.m;
            c=o.constants.c;
            e=o.constants.e;
            Theta=T*e/me/c^2;
            gamma=sqrt(T/o.Te);
            nueps=gamma^5./(1+gamma.^2).^(3/2).*2*o.nuee.*(o.Te/T).^(3/2).*o.Te;
            %             nueps=8/(3*sqrt(pi))*o.nucc./(Theta/2*(1+o.Te./T)).^(3/2);
            dTdt=-nueps.*(T-o.Te)./T;
        end
        
         function dnrdt=Runaway_differencial_function(o,t,nr)
             %P Helander et al 2002 Plasma Phys. Control. Fusion 44 B247
              k=0.21+0.11*o.Z; epsD=abs(o.E/o.ED);
              phi=sqrt(pi/(3*(o.Z+5))).*sqrt(1./(1-o.EHat.^-1))
%               coeff2=exp(-o.THETA.*(1/8*epsD.^(-2)+2/3*(1+o.Z).^(0.5).*epsD.^(-3/2)));
              gamma_Dreicer=1*o.nuee*epsD^(-3*(1+o.Z)/16).*exp(-(1/4/epsD)-sqrt((1+o.Z)/epsD));%.*coeff2;
%               gamma_Rosenbluth=sqrt(pi/2)*(abs(o.EHat)-1)/3/o.lnLambda.*o.nucc;
              gamma_Rosenbluth=(abs(o.EHat)-1)/o.lnLambda/2.*o.nucc;
%               (abs(p.EHat)-1)/p.lnLambda/2
 gamma_Rosenbluth=sqrt(pi/2)*(abs(p.EHat)-1)/3/p.lnLambda
              dnrdt=gamma_Dreicer;%+gamma_Rosenbluth*nr;
        end
        
        function f = MapLegModesToBigVector(o,fls)
            % Maps a quantity in the finite-difference--Legendre-mode space
            % to the 2D finite-difference grid.
            %
            % Usage:
            %   f = MapLegModesToBigVector(fls)
            
            f = o.legModesToBigVectorMap*fls;
        end
        
        function f2D=MapVectorToGrid(o,f)
            f2D=reshape(f,[],o.grid.nXi);
        end
        
        function f=MapGridToVector(o,f2D)
            f=reshape(f2D,[],1);
        end
        
        function define_whether_makemov(o,input)
            file='H:\movie\';
            mkdir(file);
            MovDir=[file];
            o.makemov=input;
            if strcmp(o.makemov,'yes')
                %  cd(MovDir)
                o.myvideo=VideoWriter([MovDir,'envolution,Bz=',num2str(o.B)]);
                o.myvideo.FrameRate=26;
                open(o.myvideo);
            end
        end
        
        function generate_mov_movie(o)
            if strcmp(o.makemov,'yes')
                gotfig=getframe(gcf);
                frame=gotfig.cdata;
                writeVideo(o.myvideo,frame)
            end
        end
    end
    methods (Static) %   ...   %%%
        function outPls = LegendrePolynomials(l,x)
            % Calculates the legendre polynomials P_i(x) for i=0,1,...,l
            % using Bonnet's recursion formula:
            %   (n+1)*P_{n+1}(x) = (2n+1)*x*P_n(x) - n*P_{n-1}(x),
            % where P_0(x) = 1 and P_1(x) = x.
            %
            % Usage:
            %   pls = LegendrePolynomials(l,x)
            %
            % l is the (highest) mode number and x is the coordinate, which
            % must be a row vector (not a matrix). pls has the structure
            %   [ P_0(x) ]
            %   [ P_1(x) ]
            %   [   ...  ]
            %   [ P_l(x) ]
            %
            
            %Check input
            if ~(isscalar(l) && isnumeric(l) && isreal(l) && l>=0)
                error('Invalid mode number.');
            end
            if size(x,1) > 1
                error('The argument must be presented as a row vector.');
            end
            if any(x<(-1-eps)) || any(x>(1+eps))
                error('The argument is out of the range [-1,1].');
            end
            
            %Initialize the output and include the first two modes.
            outPls(l+1,numel(x)) = 0   ;
            outPls(1,:) = ones(size(x));
            if l>=1
                outPls(2,:) = x;
            end
            
            for n = 1:l-1
                %The index n reflects the n in Bonnet's formula, but the
                %corresponding row in the array is n+1. We start from n=1, since we
                %want to use the formula to compute n+1=2 (which goes on row n+2=3)
                outPls(n+2,:) = (2*n+1)/(n+1) * x.*outPls(n+1,:) ...
                    - n/(n+1) * outPls(n,:);
            end
            
        end
        function sig=Sigma_Avalanche(gamma,gamma1)
            f1=gamma-1;
            f2=gamma1-1;
            f3=gamma1-gamma;
            f4=gamma1.^2-1;
            g1=f2.^2-f1.*f3./gamma1.^2.*(2*gamma1.^2+2*gamma1-1-f1.*f3);
            g2=f4.*f1.^2.*f3.^2;
            sig=gamma1.^2.*g1./g2;
        end
        
        function intsig=IntSigma(gamma,gammam)
            %intergation of Σ(γ1,γ) from γm to γ+1-γm
            f1=gamma.^2-1;
            f2=gamma+1;
            f3=gamma-gammam;
            f4=gammam-1;
            intsig=2./f1.*((f2/2-gammam).*(1+2*gamma.^2./(f3.*f4))-(2*gamma-1)./(gamma-1).*log(f3./f4));
        end
        
        function [p,pWeight] =nolinear_grid(pMin,pMax,N)
            s=linspace(0,1,N);
            ds=s(2)-s(1);
            pGridParameter=0.01;
            pGridMode=4;
            switch pGridMode
                case 1 %A linear grid with p = s
                    p = s;
                    dpds = ones(size(s));
                    d2pds2 = 0;
                case 2 %A grid with p = s^2 + pGridParameter*s
                    p = s.*s+pGridParameter*s;
                    dpds = 2*s+pGridParameter;
                    d2pds2 = 2*ones(size(s));
                case 3 %A grid with p = s^3 + pGridParameter*s
                    p = s.^3+pGridParameter*s;
                    dpds = 3*s.^2+pGridParameter;
                    d2pds2 = 6*s;
                case 4 %A grid with p = s^4 + pGridParameter*s
                    p = s.^4+pGridParameter*s;
                    dpds = 4*s.^3+pGridParameter;
                    d2pds2 = 12*s.^2;
            end
            scaleFactor = (pMax-pMin)/p(end);
            p = scaleFactor*p+pMin;
            dpds=dpds*scaleFactor ;
            pWeight= 1/48*[17,59,43,49,48*ones(1,(N-8)),49,43,59,17]*ds.*dpds;
            
        end
        
    end
end