classdef Nothermal_Radiation_Timeslice_second3 < matlab.mixin.Copyable & handle
    properties
        %plasma parameters
        ne0
        netimedependent
        t
        B0
        Te0
        Trad
        wavetype     % X/O or Bernstein
        f            %momentum distribution where p is normalized to mec
        m            %resonant number
        m0=2         %veiw number
        omega
        xs
        %Grid setup
        nP
        nXi
        nL
        pMax
        pGridMode
        xiGridMode
        pGridParameter
        grid
        a=0.45;%min radius
        Ns=190 % numbers of  coordinate
        theta=90 %receive angle between vector k and B direction [degree]
        direction='L'
        xkinetic=0.45/2
    end
    
    properties (Constant) %%%   Physical constants    %%%
        constants = struct('c',   2.997925e8,...
            'e',   1.602176e-19,...
            'm',   9.109380e-31,...
            'eps0',8.854188e-12);
    end
    
    methods
        function o=Nothermal_Radiation_Timeslice_second3(varargin)
            switch nargin
                case 0
                    o.grid=Grid_ECEI();
                case {4}
%                     if isa(varargin{4},'KINETIC_ANOMALOUS_CODE_Time')
                        o.SetParameters(varargin{1:end});
                        o.PerformCalculation();
                        o.Caculate_I_envolution();
%                     else
%                         error('The fourth argument must be KINETIC_ANOMALOUS_CODE_Time object.');
%                     end
%                     
%                 otherwise
%                     error('Wrong number of input arguments');
            end
        end
        
        function SetParameters(o,omega,m,wavetype,p)
            
            
            o.B0 =p.B;
            o.omega=omega;
            
            o.netimedependent=p.ne;
            o.f=p.f;
            o.Te0=p.Te;
            o.nP=p.grid.nP;
            o.nXi=p.grid.nXi;
            o.pMax=p.grid.pMax;
            o.m=m;
            o.nL=p.nL;
            o.wavetype=wavetype;
            o.pGridMode=p.pGridMode;
            o.xiGridMode=p.xiGridMode;
            o.pGridParameter=p.pGridParameter;
            o.t=p.t;
            
            o.grid = Grid_ECEI(o.nP,o.nXi,o.pMax,o.pGridMode,o.xiGridMode,o.pGridParameter);
            o.BuildMappingMatrices();
        end
        
        function PerformCalculation(o)
            o.Calculate_Common_Parameters();
            o.Calculate_Resonant_Parameters();
            o.Calculate_emission_absorption();
        end
        
        function Calculate_emission_absorption(o)
            fs=o.f;
            o.Js=zeros(o.Ns,(min(size(fs))));
            o.alphas=zeros(o.Ns,(min(size(fs))));
            e=o.constants.e ;
                me=o.constants.m;
                eps0=o.constants.eps0;
                c=o.constants.c;
                
                wce0=e*o.B0/me;w=o.omega/wce0;
                pc=sqrt((o.m/w).^2-1);
                xickin=o.grid.xi';
                pckin=ones(size(xickin))*pc;
            for jj=1:(min(size(fs))-1)
                tnow=o.t(jj);
                o.ne0=o.netimedependent(tnow);
                f=fs(:,jj);
                fl1=f(1:o.grid.nP);
                ne_mean=sum(fl1.*o.grid.p.^2*4*pi.*o.grid.pWeights);
%                  ne_mean=1;
                fpxiBig=o.MapLegModesToBigVector(f);
                f2DK=o.MapVectorToGrid(fpxiBig)    ;
                f2DK(f2DK<realmin)=0;
                dfdxiBig=o.grid.ddxiMat* fpxiBig   ;
                dfdxi2DK =o.MapVectorToGrid(dfdxiBig);
                dfdpBig=o.grid.ddpMat* fpxiBig       ;
                dfdp2DK =o.MapVectorToGrid(dfdpBig)  ;
                p2D=o.grid.p2D      ;
                xi2D=o.grid.xi2D    ;
                %%%  calcauate  dfdxi and dfdp %%%%
                f_resonant_K=interp2( xi2D,p2D,f2DK,xickin,pckin);
                dfdp_resonant_K=interp2(xi2D,p2D,dfdp2DK,xickin,pckin);
                dfdxi_resonant_K=interp2(xi2D,p2D,dfdxi2DK,xickin,pckin);
                flag=0;%time recorder
                m=o.m;
                
                for kk=1:length(o.xs)
                   
                    ne=o.ne_profile(o.xs(kk));
                    pc=o.pcs(flag+1:flag+o.nps(kk));
                    xic=o.xics(flag+1:flag+o.nps(kk));
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    if abs(o.xs(kk))>o.xkinetic
                        dfdxi_resonant=o.dfdxi_resonant_T{kk};
                        f_resonant=o.f_resonant_T{kk};
                        dfdp_resonant=o.dfdp_resonant_T{kk};
                    else
                        dfdxi_resonant=dfdxi_resonant_K;
                        f_resonant=f_resonant_K;
                        dfdp_resonant=dfdp_resonant_K;
                    end
                    flag=flag+o.nps(kk);
                    %%%    calculate resonant parameterms    %%%%%%
                                        theta=o.theta ;
                    ddeltadp=o.dfdp_delta(pc);
                    B =o.B_profile(o.xs(kk))  ;
                    wce0=e*B/me;
                    %%% calculate Jm_resonant %%%%%%
                     w=o.omega/wce0;
                    pc=sqrt((o.m/w).^2-1)*ones(1,length(o.grid.xi));
                    xic=o.grid.xi';
                    gammac=sqrt(1+pc.^2);
                    betac_perp =pc./gammac.*sqrt(1-xic.^2);
                    xi_spark=o.omega/wce0.*gammac.*betac_perp.*sind(o.theta);
                    xi_spark(xi_spark==0)=realmin;
                    Jm_xi_spark=o.Jm(xi_spark);
                    dJmdxi_spark=o.dJmdx(xi_spark);
                    %%% o.Calculate_emission_absorption_coefficient()%%%%
                    Common_part=1./pc.*dfdxi_resonant.*cosd(theta)...
                        +sqrt(1+pc.^2)./pc.*dfdp_resonant...
                        -xic.*sqrt(1+pc.^2)./pc.^2.*dfdxi_resonant;
                    switch o.wavetype
                        case 'X'
                            Ay=betac_perp.*dJmdxi_spark;
                            etay_resonant=o.coeff_emission(kk)*Ay.^2;
                            Jy_xi=etay_resonant.*2*pi.*pc.^2*ne./abs(ddeltadp);
                            alpha_xi=o.coeff_absorption*Jy_xi.*Common_part;
                            J(kk)=trapz(xic,Jy_xi.*f_resonant)/ne_mean;
                            alpha(kk)=trapz(xic,alpha_xi)/ne_mean;
                        case 'O'
                            betac_para =pc./gammac.*xic;
                            Az=(cosd(o.theta)-betac_para).*Jm_xi_spark;
                            etaz_resonant=o.coeff_emission(kk)*Az.^2;
                            Jz_xi=etaz_resonant.*2*pi.*pc.^2*ne./abs(ddeltadp);
                            alpha_xi=o.coeff_absorption*Jz_xi.*Common_part;
                            J(kk)=trapz(xic,Jz_xi.*f_resonant)/ne_mean;
                            alpha(kk)=trapz(xic,alpha_xi)/ne_mean;
                        case 'Bernstein'
                            betac_para =pc./gammac.*xic;
                            Ax=cosd(o.theta)/sind(o.theta).*(cosd(o.theta)-betac_para).*Jm_xi_spark;
                            etax_resonant=o.coeff_emission(kk)*Ax.^2;
                            Jx_xi=etax_resonant.*2*pi.*pc.^2*ne./abs(ddeltadp);
                            alpha_xi=o.coeff_absorption*Jx_xi.*Common_part;
                            J(kk)=trapz(xic,Jx_xi.*f_resonant)/ne_mean;
                            alpha(kk)=trapz(xic,alpha_xi)/ne_mean;
                        otherwise
                            error('Wrong wavetype ,please check whether wavetpye is X / O or Bernstein');
                    end
                end
                o.Js(:,jj)=J;
                o.alphas(:,jj)=alpha;
            end
        end
    end
    
    
    properties %Commonly used variables
        dfdp_delta
        beta
        Jm
        dJmdx
        I_ece
        
        tau
        
    end
    
    
    properties     %Special parameters
        Js
        alphas
        Pinitial
        xics
        pcs
        nps
        f_resonant_T
        dfdp_resonant_T
        dfdxi_resonant_T
        coeff_absorption
        coeff_emission
    end
    
    
    methods %%%prepare some necessary parameters
        function Calculate_Common_Parameters(o)
            gamma2D=o.grid.gamma2D;
            o.beta.abso2D=sqrt(gamma2D.^2-1)./gamma2D;
            o.beta.Para2D=o.beta.abso2D.*o.grid.xi2D;
            o.beta.Perp2D=o.beta.abso2D.*sqrt(1-o.grid.xi2D.^2);
            %%%  calculate the dJmdxi and Jm  %%%
            syms x
            Jmf=besselj(o.m,x);
            o.Jm=matlabFunction(Jmf);
            dJmdxf=(besselj(o.m-1,x)-besselj(o.m+1,x))/2;
            o.dJmdx=matlabFunction(dJmdxf);
            syms p xi  wn
            gam=sqrt(1+p.^2);
            deltaf=(1-p./gam.*xi*cosd(o.theta))*wn-o.m./gam;
            dfdpf=diff(deltaf,p);
            o.dfdp_delta =matlabFunction(dfdpf);
        end
        
        function Calculate_Resonant_Parameters(o)
            m=o.m  ;
            s=linspace(0,1,o.Ns);
            omega=o.omega;
            e=o.constants.e;
            eps0=o.constants.eps0;
            me=o.constants.m;
            c=o.constants.c ;
            p2D=o.grid.p2D  ;
            xi2D=o.grid.xi2D;
            o.coeff_absorption=-8*pi^3*c^2/(me*c^2*omega^2);
            x_start=o.omegatoradius(omega/o.m0);x_end=-o.a ;
            if x_start>o.a
                x_start=o.a;
                o.xs=(x_end-x_start)*s+x_start;
            elseif x_start<o.a&&x_start>-o.a
                o.xs=(x_end-x_start)*s.^3+x_start;
            else
                o.xs=nan(1,o.Ns);
                o.Js=nan(1,o.Ns);
                o.alphas=nan(1,o.Ns);
                error(['Too high frequency,the resonant position is outside of tokamak! ','x_start=',num2str(x_start)])
            end
            
            for kk=1:length(o.xs)                
                %                     ne=o.ne_profile(o.xs(kk)) ;
                B =o.B_profile(o.xs(kk))  ;
                Te=o.Te_profile(o.xs(kk)) ;
                
%                 fT=o.Theraml_Legmode_distribution(Te) ;
%                 fpxiBig=o.MapLegModesToBigVector(fT)  ;
%                 f2D=o.MapVectorToGrid(fpxiBig)        ;
%                 dfdxiBig=o.grid.ddxiMat* fpxiBig      ;
%                 dfdxi2DT =o.MapVectorToGrid(dfdxiBig) ;
%                 dfdpBig=o.grid.ddpMat* fpxiBig        ;
%                 dfdp2DT =o.MapVectorToGrid(dfdpBig)   ;
                %%%%%
                wce0=e*B/me;
                o.coeff_emission(kk)=e^2*omega.^2/8/pi.^2/eps0/c/wce0;
                w=omega/wce0;
                if w<m
                   
                    p=sqrt((m/w).^2-1);
                    xic=o.grid.xi';
                    pc=ones(1,length(xic))*p;
                    o.nps(kk)=length(pc);
                    o.xics=[o.xics,xic];
                    o.pcs =[o.pcs,pc]  ;
                    o.f_resonant_T{kk}=o.Theraml_f_distribution(Te,pc);%interp2( xi2D,p2D,f2D,xic,pc);
                    o.dfdp_resonant_T{kk}=o.Theraml_dfdp_distribution(Te,pc);%interp2(xi2D,p2D,dfdp2DT,xic,pc);
                    o.dfdxi_resonant_T{kk}=zeros(size(pc));
                else
                    npc=length(o.grid.xi);
                    xic=nan(1,npc);pc=nan(1,npc);
                    o.nps(kk)=npc;
                    o.xics=[o.xics,xic];
                    o.pcs=[o.pcs,pc];
                    o.f_resonant_T{kk}=nan(1,npc);
                    o.dfdp_resonant_T{kk}=nan(1,npc);
                    o.dfdxi_resonant_T{kk}=nan(1,npc);
                end
            end
        end
        
        function ne=ne_profile(o,x)
            
            nr=x/o.a;
            if x<o.a&&x>-o.a
                if abs(x)<o.xkinetic
                    ne=o.ne0;
                else
                    ne=o.ne0*(1-nr.^2).^2;
                    ne=max(1,ne);
                end
            else
                ne=0;
            end
        end
        
        function B=B_profile(o,x)
            
            Rc=1.85;R=x+Rc;
            if abs(x)<o.xkinetic
                B=o.B0;
            else
                B=o.B0*Rc./R;
            end
        end
        
        function te=Te_profile(o,x)
            
            nr=x/o.a;
            if x<o.a&&x>-o.a
                if abs(x)<o.xkinetic
                    te=o.Te0;
                else
                    te=o.Te0*(1-nr.^2).^2;
                    te=max(1e1,te);
                end
            else
                te=realmin;
            end
            
        end
        
        
        function x=omegatoradius(o,omega)
            e=o.constants.e;
            me=o.constants.m;
            Rc=1.85;
            B=omega*me/e;
            x=o.B0*Rc/B-Rc;
        end
        
        
        
        function f=Theraml_Legmode_distribution(o,Te)
            %thermal distribution in legendre mode
            e=o.constants.e;
            me=o.constants.m;
            c=o.constants.c;
            o.Pinitial=sqrt(2*e*Te/me/c^2);
            f0=@(y)(pi*o.Pinitial^2).^(-3/2)*exp(-y.^2/o.Pinitial^2);
            fls=zeros(1,o.nL*o.nP);
            fls(1:o.nP)=f0(o.grid.p);
            f(:,1)=fls;
        end
        
         function f=Theraml_f_distribution(o,Te,pc)
            %thermal distribution in legendre mode
            e=o.constants.e;
            me=o.constants.m;
            c=o.constants.c ;
            o.Pinitial=sqrt(2*e*Te/me/c^2);
            f0=@(y)(pi*o.Pinitial^2).^(-3/2)*exp(-y.^2/o.Pinitial^2);
            f=f0(pc);              
         end
        
        function f=Theraml_dfdp_distribution(o,Te,pc)
            %thermal distribution in legendre mode
            e=o.constants.e;
            me=o.constants.m;
            c=o.constants.c;
            o.Pinitial=sqrt(2*e*Te/me/c^2);
            f0=@(y)(pi*o.Pinitial^2).^(-3/2)*exp(-y.^2/o.Pinitial^2).*(-2.*y./o.Pinitial^2);
            f=f0(pc);         
        end
        
        
        
    end
    
    
    properties
        legModesToBigVectorMap
        bigVectorToLegModeMap
    end
    
    methods %%% Mapping to Legendre modes %%%
        function BuildMappingMatrices(o)
            % Constructs matrices for mapping between the 2D
            % finite-difference grid and finite-difference--Legendre-mode
            % representations.
            %
            % Usage:
            %   BuildMappingMatrices()
            %
            
            nP  = o.grid.nP ;
            nXi = o.grid.nXi;
            
            %%%Build a matrix describing the mapping from a Legendre-mode
            %%%vector to a vector on the 2D finite-difference grid
            mapMat = sparse(nP*nXi, nP*o.nL);
            cellOfRowBlocks = cell(nXi,1);
            
            %Make a (nP-1)x(nP) block with ones on the first upper
            %diagonal, which we will then duplicate horizontally, weighted
            %by P_l, to form a "row block". Row block i gives the mapping
            %to f(p,xi_i).
            identityBlock = speye(nP);
            
            Pls = o.LegendrePolynomials(o.nL-1,o.grid.xi');
            for iXi = 1:nXi
                PlsAtXi = Pls(:,iXi)';
                cellOfRowBlocks{iXi} = kron(PlsAtXi,identityBlock);
            end
            
            mapMat = cell2mat(cellOfRowBlocks);
            o.legModesToBigVectorMap = mapMat;
            
            
            %%%Invert the matrix to get the inverse mapping from the
            %%%2D finite-difference grid
            %%%vector to Legendre modes
            %This should give accuracy to machine precision. The matrix is
            %rectangular, so we need to use the pseudo inverse. The
            %following is equivalent to pinv(full(mapMat)), but works for
            %sparse matrices (and the result is pretty sparse, so storing
            %is not an issue):
            r = qr(mapMat,0);
            o.bigVectorToLegModeMap = r\(r'\mapMat');
        end
        
        function fls = MapBigVectorToLegModes(o,f)
            % Maps a quantity defined on the 2D finite-difference grid to
            % the finite-difference--Legendre-mode space
            %
            % Usage:
            %   fls = MapBigVectorToLegModes(f)
            
            fls = o.bigVectorToLegModeMap*f;
        end
        
        function f = MapLegModesToBigVector(o,fls)
            % Maps a quantity in the finite-difference--Legendre-mode space
            % to the 2D finite-difference grid.
            %
            % Usage:
            %   f = MapLegModesToBigVector(fls)
            
            f = o.legModesToBigVectorMap*fls;
        end
        
        function f2D=MapVectorToGrid(o,f)
            f2D=reshape(f,[],o.grid.nXi);
        end
        
        function f=MapGridToVector(o,f2D)
            f=reshape(f2D,[],1);
        end
        
        function plot_alphas_distribution(o,tp)
            Id=find(abs(o.t-tp)==min(abs(o.t-tp)));
            plot(o.xs,o.alphas(:,Id))
%             plot(o.xs,log10(o.alphas(:,Id)))
%             xlim([-o.a,o.a])
%             ylim([-10 10])
            xlabel('r/m')
            ylabel('\alpha')
        end
        
        function plot_Js_distribution(o,tp)
            Id=find(abs(o.t-tp)==min(abs(o.t-tp)));
            plot(o.xs,o.Js(:,Id))
            xlim([-o.a,o.a])
            xlabel('r/m')
            ylabel('Js')
        end
        
          function plot_Js_envolution(o,x)
             Id=find(abs(x-o.xs)==min(abs(x-o.xs)));
            plot(o.t,o.Js(Id,1:end-1))
%             xlim([-o.a,o.a])
            xlabel('s')
            ylabel('Js')
        end
        
        function plot_tau_envolution(o)
            
            plot(o.t,o.tau(1:end),'-')
            xlabel('t')
            ylabel('\tau')
        end
        
        function plot_I_envolution(o)
            plot(o.t,o.I_ece(1:end-1),'-')
            xlabel('t')
            ylabel('I')
        end
        function plot_Teff_envolution(o)

            plot(o.t,o.Trad,'ks-')
            xlabel('t')
            ylabel('Kev')
            b=legend('Radiation Teff');
            set(b,'box','off')
            axis tight
            text((max(o.t)+min(o.t))/2,(max(o.Trad)+min(o.Trad))/2,['kinetic radius<',num2str(o.xkinetic*100,'%0.2f'),'cm'],'fontsize',12)
%             grid on;set(gca,'GridLineStyle',':','GridColor','k','GridAlpha',1);
        end
        
        
        function Caculate_I_envolution(o)
            switch o.direction
                case 'L'
                    for jj=1:length(o.t)                 
                        J=o.Js(:,jj);
                        alpha=o.alphas(:,jj);
                        s=o.xs;
                        [s,I]=sort(s);
                        J=J(I);alpha=alpha(I);
                        J(isnan(J))=0;
                        alpha(isnan(alpha))=0;
                        ds=diff(s);
                        Is(1)=0;                        
                        for kk=1:length(o.xs)-1
                            Is(kk+1)=Is(kk)+(J(kk)-alpha(kk)*Is(kk))*ds(kk);
                        end
                        
                        o.tau(jj)=trapz(s,alpha);
                        o.I_ece(jj)=Is(end);     
                       
                    end
                                c=o.constants.c;
                               e=o.constants.e;
                              coeff=o.omega.^2/(8*pi^3*c^2)*e;
                              o.Trad=o.I_ece./coeff/1E3;
                case  'H'
                    for jj=1:length(o.t)  
                        J=o.Js(:,jj);
                        alpha=o.alphas(:,jj);
                        s=o.xs;
                        J(isnan(J))=0;
                        alpha(isnan(alpha))=0;
                        ds=abs(diff(s));
                        Is(1)=0;
                        for kk=1:length(o.xs)
                            Is(kk+1)=Is(kk)+(J(kk)-alpha(kk)*Is(kk))*ds(kk);
                        end
                        o.tau(jj)=trapz(s,alpha);
                        o.I_ece(jj)=Is(end);
                        
                    end
                     c=o.constants.c;
                               e=o.constants.e;
                              coeff=o.omega.^2/(8*pi^3*c^2)*e;
                              o.Trad=o.I_ece./coeff/1E3;
                otherwise
                    error('unable to solve,please check whether the direction is L or H')
            end
        end
        
    end
    
    
    
    
    
    methods (Static) %   ...   %%%
        function outPls = LegendrePolynomials(l,x)
            % Calculates the legendre polynomials P_i(x) for i=0,1,...,l
            % using Bonnet's recursion formula:
            %   (n+1)*P_{n+1}(x) = (2n+1)*x*P_n(x) - n*P_{n-1}(x),
            % where P_0(x) = 1 and P_1(x) = x.
            %
            % Usage:
            %   pls = LegendrePolynomials(l,x)
            %
            % l is the (highest) mode number and x is the coordinate, which
            % must be a row vector (not a matrix). pls has the structure
            %   [ P_0(x) ]
            %   [ P_1(x) ]
            %   [   ...  ]
            %   [ P_l(x) ]
            %
            
            %Check input
            if ~(isscalar(l) && isnumeric(l) && isreal(l) && l>=0)
                error('Invalid mode number.');
            end
            if size(x,1) > 1
                error('The argument must be presented as a row vector.');
            end
            if any(x<(-1-eps)) || any(x>(1+eps))
                error('The argument is out of the range [-1,1].');
            end
            
            %Initialize the output and include the first two modes.
            outPls(l+1,numel(x)) = 0;
            outPls(1,:) = ones(size(x));
            if l>=1
                outPls(2,:) = x;
            end
            
            for n = 1:l-1
                %The index n reflects the n in Bonnet's formula, but the
                %corresponding row in the array is n+1. We start from n=1, since we
                %want to use the formula to compute n+1=2 (which goes on row n+2=3)
                outPls(n+2,:) = (2*n+1)/(n+1) * x.*outPls(n+1,:) ...
                    - n/(n+1) * outPls(n,:);
            end
            
        end
        
    end
end